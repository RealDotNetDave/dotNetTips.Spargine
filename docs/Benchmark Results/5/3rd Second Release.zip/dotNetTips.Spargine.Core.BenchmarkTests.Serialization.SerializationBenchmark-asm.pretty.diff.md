## dotNetTips.Spargine.Core.BenchmarkTests.Serialization.SerializationBenchmark-20210420-173640
