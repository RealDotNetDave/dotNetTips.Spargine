## dotNetTips.Spargine.Extensions.BenchmarkTests.ArrayExtensionsCollectionBenchmark-20210420-180200
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddIfNotExists01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Clone02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddFirst01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AddLast01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AreEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ArrayHashCode01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for BytesToString method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ContainsAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveFirst method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for RemoveLast method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
