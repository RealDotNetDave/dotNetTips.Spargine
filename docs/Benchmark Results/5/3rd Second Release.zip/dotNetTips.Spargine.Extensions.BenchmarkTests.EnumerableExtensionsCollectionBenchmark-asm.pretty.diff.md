## dotNetTips.Spargine.Extensions.BenchmarkTests.EnumerableExtensionsCollectionBenchmark-20210420-185335
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrDefaultAlternate02 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToImmutableList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for Count01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastAny01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FastCount01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for FirstOrNull01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StartsWith01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for StructuralSequenceEqual01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToBlockingCollection01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDelimitedString01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToDictionary01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for ToLinkedList01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
