
    BenchmarkDotNet=v0.12.1, OS=Windows 10.0.19042
    Unknown processor
    .NET Core SDK=5.0.300-preview.21180.15
      [Host]     : .NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
      Job-CJSTKQ : .NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT

    EvaluateOverhead=True  Server=True  Toolchain=.NET Core 5.0  
    Namespace=dotNetTips.Spargine.Extensions.BenchmarkTests  Categories=ExceptionExtensions  

             Method |     Mean |   Error |  StdDev |  StdErr |      Min |       Q1 |   Median |       Q3 |      Max |        Op/s | CI99.9% Margin | Iterations | Kurtosis | MValue | Skewness | Rank | LogicalGroup | Baseline | Code Size |  Gen 0 | Gen 1 | Gen 2 | Allocated |
    --------------- |---------:|--------:|--------:|--------:|---------:|---------:|---------:|---------:|---------:|------------:|---------------:|-----------:|---------:|-------:|---------:|-----:|------------- |--------- |----------:|-------:|------:|------:|----------:|
     GetAllMessages | 200.9 ns | 1.13 ns | 1.00 ns | 0.27 ns | 198.8 ns | 200.4 ns | 200.8 ns | 201.5 ns | 202.7 ns | 4,976,808.3 |       1.126 ns |      14.00 |    2.624 |  2.000 |  -0.1479 |    1 |            * |       No |     384 B | 0.0308 |     - |     - |     280 B |
