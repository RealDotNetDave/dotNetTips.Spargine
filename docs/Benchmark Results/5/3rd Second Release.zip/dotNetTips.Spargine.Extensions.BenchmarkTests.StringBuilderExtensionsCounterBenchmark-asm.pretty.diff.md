## dotNetTips.Spargine.Extensions.BenchmarkTests.StringBuilderExtensionsCounterBenchmark-20210420-201820
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendKeyValue0 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendValues01 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
**Diff for AppendBytes03 method between:**
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
.NET Core 5.0.5 (CoreCLR 5.0.521.16609, CoreFX 5.0.521.16609), X64 RyuJIT
```diff
An exception occurred during run Git. Please check if you have Git installed on your system and Git is added to PATH.
Exception: The system cannot find the file specified.
```
