## dotNetTips.Spargine.Core.BenchmarkTests.Security.EncryptionHelperBenchmark-20210828-142248
