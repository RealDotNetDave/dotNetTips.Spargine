{noformat}

BenchmarkDotNet=v0.13.1, OS=Windows 10.0.19042.1165 (20H2/October2020Update)
Unknown processor
.NET SDK=6.0.100-preview.7.21379.14
  [Host]     : .NET 5.0.9 (5.0.921.35908), X64 RyuJIT
  Job-YNYGDE : .NET 5.0.9 (5.0.921.35908), X64 RyuJIT

EvaluateOverhead=True  Server=True  Toolchain=.NET 5.0  
Namespace=dotNetTips.Spargine.Core.BenchmarkTests.Security  Categories=**NEW**,Encryption  

{noformat}
||       Method ||    Mean ||    Error ||   StdDev ||   StdErr ||     Min ||      Q1 ||  Median ||      Q3 ||     Max ||     Op/s ||CI99.9% Margin ||Iterations ||Kurtosis ||MValue ||Skewness ||Rank ||LogicalGroup ||Baseline || Gen 0 ||Code Size || Gen 1 ||Allocated ||
|    *AesDecrypt* | *5.998 μs* | *0.0193 μs* | *0.0171 μs* | *0.0046 μs* | *5.978 μs* | *5.982 μs* | *5.993 μs* | *6.014 μs* | *6.025 μs* | *166,734.1* |      *0.0193 μs* |      *14.00* |    *1.395* |  *2.000* |   *0.3035* |    *2* |            *** |       *No* | *1.5411* |      *1 KB* | *0.0153* |     *14 KB* |
|    *AesEncrypt* | *4.961 μs* | *0.0222 μs* | *0.0208 μs* | *0.0054 μs* | *4.914 μs* | *4.956 μs* | *4.964 μs* | *4.971 μs* | *4.991 μs* | *201,567.4* |      *0.0222 μs* |      *15.00* |    *3.074* |  *2.000* |  *-0.7619* |    *1* |            *** |       *No* | *1.3962* |      *1 KB* | *0.0076* |     *12 KB* |
| *SimpleDecrypt* | *7.628 μs* | *0.0292 μs* | *0.0244 μs* | *0.0068 μs* | *7.548 μs* | *7.631 μs* | *7.633 μs* | *7.636 μs* | *7.644 μs* | *131,096.8* |      *0.0292 μs* |      *13.00* |    *8.709* |  *2.000* |  *-2.6128* |    *4* |            *** |       *No* | *1.0681* |      *1 KB* |      *-* |     *10 KB* |
| *SimpleEncrypt* | *6.413 μs* | *0.0693 μs* | *0.0649 μs* | *0.0167 μs* | *6.316 μs* | *6.342 μs* | *6.453 μs* | *6.463 μs* | *6.475 μs* | *155,923.5* |      *0.0693 μs* |      *15.00* |    *1.246* |  *2.000* |  *-0.4651* |    *3* |            *** |       *No* | *1.4648* |      *1 KB* | *0.0153* |     *13 KB* |
