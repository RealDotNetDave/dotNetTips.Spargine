## dotNetTips.Spargine.Core.BenchmarkTests.Serialization.SerializationBenchmark-20210828-142357
