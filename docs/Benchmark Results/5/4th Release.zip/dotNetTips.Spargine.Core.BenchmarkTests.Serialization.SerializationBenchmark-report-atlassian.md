{noformat}

BenchmarkDotNet=v0.13.1, OS=Windows 10.0.19042.1165 (20H2/October2020Update)
Unknown processor
.NET SDK=6.0.100-preview.7.21379.14
  [Host]     : .NET 5.0.9 (5.0.921.35908), X64 RyuJIT
  Job-YNYGDE : .NET 5.0.9 (5.0.921.35908), X64 RyuJIT

EvaluateOverhead=True  Server=True  Toolchain=.NET 5.0  
Namespace=dotNetTips.Spargine.Core.BenchmarkTests.Serialization  

{noformat}
||                         Method ||        Categories ||     Mean ||    Error ||   StdDev ||   StdErr ||      Min ||       Q1 ||   Median ||       Q3 ||      Max ||     Op/s ||CI99.9% Margin ||Iterations ||Kurtosis ||MValue ||Skewness ||Rank ||LogicalGroup ||Baseline || Gen 0 ||Code Size || Gen 1 ||Allocated ||
| *'Deserialize: XML=PersonProper'* |  *XML,Serialization* | *19.444 μs* | *0.0575 μs* | *0.0480 μs* | *0.0133 μs* | *19.387 μs* | *19.400 μs* | *19.440 μs* | *19.467 μs* | *19.530 μs* |  *51,430.8* |      *0.0575 μs* |      *13.00* |    *1.884* |  *2.000* |   *0.5165* |    *6* |            *** |       *No* | *2.0142* |      *0 KB* | *0.0305* |     *18 KB* |
| *'Deserialize: XML=PersonRecord'* |  *XML,Serialization* | *18.924 μs* | *0.0601 μs* | *0.0533 μs* | *0.0142 μs* | *18.821 μs* | *18.892 μs* | *18.926 μs* | *18.949 μs* | *19.032 μs* |  *52,842.2* |      *0.0601 μs* |      *14.00* |    *2.554* |  *2.000* |   *0.1110* |    *5* |            *** |       *No* | *2.0142* |      *0 KB* |      *-* |     *18 KB* |
|  *'Serialize: JSON=PersonProper'* | *JSON,Serialization* |  *3.935 μs* | *0.0159 μs* | *0.0141 μs* | *0.0038 μs* |  *3.901 μs* |  *3.932 μs* |  *3.935 μs* |  *3.942 μs* |  *3.958 μs* | *254,148.5* |      *0.0159 μs* |      *14.00* |    *3.197* |  *2.000* |  *-0.7621* |    *2* |            *** |       *No* | *0.2060* |      *0 KB* |      *-* |      *2 KB* |
|  *'Serialize: JSON=PersonRecord'* | *JSON,Serialization* |  *3.526 μs* | *0.0103 μs* | *0.0096 μs* | *0.0025 μs* |  *3.506 μs* |  *3.522 μs* |  *3.526 μs* |  *3.532 μs* |  *3.541 μs* | *283,625.3* |      *0.0103 μs* |      *15.00* |    *2.239* |  *2.000* |  *-0.3693* |    *1* |            *** |       *No* | *0.2594* |      *0 KB* |      *-* |      *2 KB* |
|   *'Serialize: XML=PersonProper'* |  *XML,Serialization* | *12.491 μs* | *0.0204 μs* | *0.0181 μs* | *0.0048 μs* | *12.447 μs* | *12.485 μs* | *12.494 μs* | *12.502 μs* | *12.516 μs* |  *80,055.7* |      *0.0204 μs* |      *14.00* |    *3.127* |  *2.000* |  *-0.7555* |    *4* |            *** |       *No* | *2.2736* |      *0 KB* | *0.0458* |     *20 KB* |
|               *StringToXDocument* |  *XML,Serialization* |  *9.782 μs* | *0.0345 μs* | *0.0288 μs* | *0.0080 μs* |  *9.720 μs* |  *9.783 μs* |  *9.793 μs* |  *9.795 μs* |  *9.818 μs* | *102,224.6* |      *0.0345 μs* |      *13.00* |    *3.221* |  *2.000* |  *-1.2107* |    *3* |            *** |       *No* | *1.7090* |      *0 KB* | *0.0305* |     *16 KB* |
