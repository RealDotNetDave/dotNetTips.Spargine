{noformat}

BenchmarkDotNet=v0.13.1, OS=Windows 10.0.19042.1165 (20H2/October2020Update)
Unknown processor
.NET SDK=6.0.100-preview.7.21379.14
  [Host]     : .NET 5.0.9 (5.0.921.35908), X64 RyuJIT
  Job-YNYGDE : .NET 5.0.9 (5.0.921.35908), X64 RyuJIT

EvaluateOverhead=True  Server=True  Toolchain=.NET 5.0  
Namespace=dotNetTips.Spargine.Core.BenchmarkTests  Categories=**NEW**,Work in Progress  

{noformat}
||                            Method ||      Mean ||    Error ||   StdDev ||   StdErr ||    Median ||       Min ||        Q1 ||        Q3 ||       Max ||             Op/s ||CI99.9% Margin ||Iterations ||Kurtosis ||MValue ||Skewness ||Ratio ||RatioSD ||Welch(10%)/p-values ||Rank ||                                                      LogicalGroup ||Baseline ||Code Size ||Allocated ||
| *MethodImplOptions:AggressiveInline* |  *0.0292 ns* | *0.0032 ns* | *0.0030 ns* | *0.0008 ns* |  *0.0284 ns* |  *0.0238 ns* |  *0.0275 ns* |  *0.0312 ns* |  *0.0343 ns* |  *34,275,065,246.8* |      *0.0032 ns* |      *15.00* |    *1.962* |  *3.429* |   *0.1004* |     *?* |       *?* |                   *?* |    *2* | *Job-YNYGDE(EvaluateOverhead=True, Server=True, Toolchain=.NET 5.0)* |       *No* |      *24 B* |         *-* |
|         *MethodImplOptions:Baseline* |  *0.0000 ns* | *0.0000 ns* | *0.0000 ns* | *0.0000 ns* |  *0.0000 ns* |  *0.0000 ns* |  *0.0000 ns* |  *0.0000 ns* |  *0.0000 ns* |          *Infinity* |      *0.0000 ns* |      *15.00* |       *NA* |  *2.000* |       *NA* |     *?* |       *?* |                   *?* |    *1* | *Job-YNYGDE(EvaluateOverhead=True, Server=True, Toolchain=.NET 5.0)* |      *Yes* |      *24 B* |         *-* |
|         *MethodImplOptions:NoInline* |  *1.3700 ns* | *0.0063 ns* | *0.0059 ns* | *0.0015 ns* |  *1.3696 ns* |  *1.3596 ns* |  *1.3665 ns* |  *1.3743 ns* |  *1.3787 ns* |     *729,926,480.8* |      *0.0063 ns* |      *15.00* |    *1.801* |  *2.000* |   *0.0248* |     *?* |       *?* |                   *?* |    *3* | *Job-YNYGDE(EvaluateOverhead=True, Server=True, Toolchain=.NET 5.0)* |       *No* |      *97 B* |         *-* |
|   *MethodImplOptions:NoOptimization* |  *0.0053 ns* | *0.0079 ns* | *0.0074 ns* | *0.0019 ns* |  *0.0017 ns* |  *0.0000 ns* |  *0.0000 ns* |  *0.0079 ns* |  *0.0252 ns* | *188,016,877,258.8* |      *0.0079 ns* |      *15.00* |    *3.864* |  *2.222* |   *1.3397* |     *?* |       *?* |                   *?* |    *1* | *Job-YNYGDE(EvaluateOverhead=True, Server=True, Toolchain=.NET 5.0)* |       *No* |      *24 B* |         *-* |
|      *MethodImplOptions:PreserveSig* |  *0.0000 ns* | *0.0000 ns* | *0.0000 ns* | *0.0000 ns* |  *0.0000 ns* |  *0.0000 ns* |  *0.0000 ns* |  *0.0000 ns* |  *0.0000 ns* |          *Infinity* |      *0.0000 ns* |      *14.00* |       *NA* |  *2.000* |       *NA* |     *?* |       *?* |                   *?* |    *1* | *Job-YNYGDE(EvaluateOverhead=True, Server=True, Toolchain=.NET 5.0)* |       *No* |      *24 B* |         *-* |
|     *MethodImplOptions:Synchronized* | *15.2596 ns* | *0.1473 ns* | *0.1377 ns* | *0.0356 ns* | *15.1871 ns* | *15.1287 ns* | *15.1634 ns* | *15.3325 ns* | *15.5211 ns* |      *65,532,669.6* |      *0.1473 ns* |      *15.00* |    *1.959* |  *2.000* |   *0.7965* |     *?* |       *?* |                   *?* |    *4* | *Job-YNYGDE(EvaluateOverhead=True, Server=True, Toolchain=.NET 5.0)* |       *No* |     *213 B* |         *-* |
