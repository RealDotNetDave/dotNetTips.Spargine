``` ini

BenchmarkDotNet=v0.13.1, OS=Windows 10.0.19042.1165 (20H2/October2020Update)
Unknown processor
.NET SDK=6.0.100-preview.7.21379.14
  [Host]     : .NET 5.0.9 (5.0.921.35908), X64 RyuJIT
  Job-YNYGDE : .NET 5.0.9 (5.0.921.35908), X64 RyuJIT

EvaluateOverhead=True  Server=True  Toolchain=.NET 5.0  
Namespace=dotNetTips.Spargine.Core.BenchmarkTests  

```
|                                     Method | Categories |      Mean |     Error |    StdDev |    StdErr |       Min |        Q1 |    Median |        Q3 |       Max |      Op/s | CI99.9% Margin | Iterations | Kurtosis | MValue | Skewness | Rank | LogicalGroup | Baseline |  Gen 0 | Code Size |  Gen 1 | Allocated |
|------------------------------------------- |----------- |----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|---------------:|-----------:|---------:|-------:|---------:|-----:|------------- |--------- |-------:|----------:|-------:|----------:|
| **&#39;Looping Collection: Normal StringBuilder&#39;** |    **Strings** |  **5.096 μs** | **0.0247 μs** | **0.0206 μs** | **0.0057 μs** |  **5.075 μs** |  **5.082 μs** |  **5.090 μs** |  **5.104 μs** |  **5.144 μs** | **196,219.2** |      **0.0247 μs** |      **13.00** |    **2.957** |  **2.000** |   **1.0984** |    **1** |            ***** |       **No** | **1.4648** |      **3 KB** | **0.0153** |     **13 KB** |
|                          **GetPropertyValues** | **Reflection** | **16.294 μs** | **0.0875 μs** | **0.0731 μs** | **0.0203 μs** | **16.157 μs** | **16.269 μs** | **16.303 μs** | **16.314 μs** | **16.446 μs** |  **61,371.7** |      **0.0875 μs** |      **13.00** |    **2.786** |  **2.000** |   **0.1374** |    **2** |            ***** |       **No** | **0.6714** |      **2 KB** |      **-** |      **6 KB** |
