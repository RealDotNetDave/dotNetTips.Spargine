{noformat}

BenchmarkDotNet=v0.13.1, OS=Windows 10.0.19044.1706 (21H2)
Intel Core i7-7660U CPU 2.50GHz (Kaby Lake), 1 CPU, 4 logical and 2 physical cores
.NET SDK=6.0.300
  [Host]     : .NET 6.0.5 (6.0.522.21309), X64 RyuJIT
  Job-XJCAYH : .NET 6.0.5 (6.0.522.21309), X64 RyuJIT

EvaluateOverhead=True  Server=True  Toolchain=.NET 6.0  
Namespace=DotNetTips.Spargine.Core.BenchmarkTests.Security  Categories=Encryption  

{noformat}
||             Method ||    Mean ||    Error ||   StdDev ||   StdErr ||     Min ||      Q1 ||  Median ||      Q3 ||     Max ||     Op/s ||CI99.9% Margin ||Iterations ||Kurtosis ||MValue ||Skewness ||Rank ||LogicalGroup ||Baseline || Gen 0 ||Code Size || Gen 1 ||Allocated ||
|          *AesDecrypt* | *7.024 μs* | *0.1340 μs* | *0.1377 μs* | *0.0334 μs* | *6.822 μs* | *6.920 μs* | *6.985 μs* | *7.111 μs* | *7.333 μs* | *142,367.2* |      *0.1340 μs* |      *17.00* |    *2.474* |  *2.000* |   *0.7402* |    *2* |            *** |       *No* | *1.5717* |      *1 KB* | *0.0229* |     *14 KB* |
|          *AesEncrypt* | *5.455 μs* | *0.0904 μs* | *0.0755 μs* | *0.0209 μs* | *5.298 μs* | *5.441 μs* | *5.470 μs* | *5.503 μs* | *5.553 μs* | *183,312.5* |      *0.0904 μs* |      *13.00* |    *2.643* |  *2.000* |  *-0.8955* |    *1* |            *** |       *No* | *1.3657* |      *1 KB* | *0.0153* |     *13 KB* |
| *SimpleSHA256Decrypt* | *7.426 μs* | *0.0783 μs* | *0.0733 μs* | *0.0189 μs* | *7.322 μs* | *7.368 μs* | *7.412 μs* | *7.486 μs* | *7.545 μs* | *134,659.9* |      *0.0783 μs* |      *15.00* |    *1.581* |  *2.000* |   *0.2526* |    *3* |            *** |       *No* | *1.2436* |      *0 KB* | *0.0076* |     *11 KB* |
| *SimpleSHA256Encrypt* | *7.944 μs* | *0.1534 μs* | *0.2389 μs* | *0.0422 μs* | *7.402 μs* | *7.836 μs* | *8.000 μs* | *8.122 μs* | *8.260 μs* | *125,888.9* |      *0.1534 μs* |      *32.00* |    *2.767* |  *2.267* |  *-0.9224* |    *4* |            *** |       *No* | *1.4038* |      *0 KB* |      *-* |     *13 KB* |
