## DotNetTips.Spargine.Extensions.BenchmarkTests.CollectionExtensionsCollectionBenchmark-20220530-143717
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3F06B8]
+       mov       r11,7FFAAEE306B8
-       call      qword ptr [7FFAAF3D06B8]
-       mov       r11,7FFAAEE106B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF46CAA0
-       mov       rdx,7FFAAF44CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF466430
-       mov       rdx,7FFAAF446430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1CA8A46DD88
-       mov       r9,254BACE5D60
        mov       r8,[r8]
+       mov       r8,1CAAA463020
-       mov       r8,254BACE3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF465F60
-       mov       rdx,7FFAAF445F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/cb47b3dc-f855-4881-b341-a65f1f8b55b4-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f0dadc0f-d624-4386-9c38-73d5002d4020-diff.temp
index 5c71bec..9028454 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f0dadc0f-d624-4386-9c38-73d5002d4020-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/cb47b3dc-f855-4881-b341-a65f1f8b55b4-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3C06B8]
+       mov       r11,7FFAAEE006B8
-       call      qword ptr [7FFAAF3D06B8]
-       mov       r11,7FFAAEE106B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF43CAA0
-       mov       rdx,7FFAAF44CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF436430
-       mov       rdx,7FFAAF446430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,2CCCC3D39C0
-       mov       r9,254BACE5D60
        mov       r8,[r8]
+       mov       r8,2CCCC3C3020
-       mov       r8,254BACE3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF435F60
-       mov       rdx,7FFAAF445F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5b8df21a-6bf0-44f1-a70d-86d1260a168d-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/19b95044-9066-48a2-83bb-b678168a4192-diff.temp
index 5c71bec..8a4b58e 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/19b95044-9066-48a2-83bb-b678168a4192-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5b8df21a-6bf0-44f1-a70d-86d1260a168d-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3F06B8]
+       mov       r11,7FFAAEE306B8
-       call      qword ptr [7FFAAF3D06B8]
-       mov       r11,7FFAAEE106B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF46CAA0
-       mov       rdx,7FFAAF44CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF466430
-       mov       rdx,7FFAAF446430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1B4F76A1958
-       mov       r9,254BACE5D60
        mov       r8,[r8]
+       mov       r8,1B5176A3020
-       mov       r8,254BACE3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF465F60
-       mov       rdx,7FFAAF445F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f2508a8e-aa38-45e1-a42f-f1cdc47c54fe-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/8e33b291-4521-42e3-910d-ed0ffe3b8876-diff.temp
index 5c71bec..19e1b2d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/8e33b291-4521-42e3-910d-ed0ffe3b8876-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f2508a8e-aa38-45e1-a42f-f1cdc47c54fe-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3E06B8]
+       mov       r11,7FFAAEE206B8
-       call      qword ptr [7FFAAF3D06B8]
-       mov       r11,7FFAAEE106B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF45CAA0
-       mov       rdx,7FFAAF44CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF456430
-       mov       rdx,7FFAAF446430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,23869E009B0
-       mov       r9,254BACE5D60
        mov       r8,[r8]
+       mov       r8,23869DF1028
-       mov       r8,254BACE3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF455F60
-       mov       rdx,7FFAAF445F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7ef937a7-2777-41a5-88cb-269e0e54b9a6-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0060a683-75e6-426d-94a0-b488b3b3c465-diff.temp
index 5c71bec..ff19c94 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0060a683-75e6-426d-94a0-b488b3b3c465-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7ef937a7-2777-41a5-88cb-269e0e54b9a6-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4463E8
-       mov       rdx,7FFAAF446430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,23F58E42170
-       mov       r9,254BACE5D60
        mov       r8,[r8]
+       mov       r8,23F48E43020
-       mov       r8,254BACE3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF445F18
-       mov       rdx,7FFAAF445F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/223a24da-17bd-4892-907b-cbf4102b85f8-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9a716f3e-36d2-4e1a-ba5f-fe38b2a02540-diff.temp
index 5c71bec..b4f7204 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9a716f3e-36d2-4e1a-ba5f-fe38b2a02540-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/223a24da-17bd-4892-907b-cbf4102b85f8-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4463E8
-       mov       rdx,7FFAAF446430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,2C856E51958
-       mov       r9,254BACE5D60
        mov       r8,[r8]
+       mov       r8,2C846E53020
-       mov       r8,254BACE3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF445F18
-       mov       rdx,7FFAAF445F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3152213a-8aff-4e30-9eff-31f0cef9d7e3-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f21a249e-73ac-488c-adce-029e489b9383-diff.temp
index 5c71bec..0a4dbb8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f21a249e-73ac-488c-adce-029e489b9383-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3152213a-8aff-4e30-9eff-31f0cef9d7e3-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3F07E0]
+       mov       r11,7FFAAEE207E0
-       call      qword ptr [7FFAAF3D06B8]
-       mov       r11,7FFAAEE106B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF484C30
-       mov       rdx,7FFAAF44CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF469F20
-       mov       rdx,7FFAAF446430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1DAAED85D60
-       mov       r9,254BACE5D60
        mov       r8,[r8]
+       mov       r8,1DAAED83020
-       mov       r8,254BACE3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF469A50
-       mov       rdx,7FFAAF445F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/885f739e-c9fb-46f8-8d40-17c8be4a0b71-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d70a4ed9-f4e9-4bda-8f84-a6a471f8aa82-diff.temp
index 5c71bec..2dec7fe 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d70a4ed9-f4e9-4bda-8f84-a6a471f8aa82-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/885f739e-c9fb-46f8-8d40-17c8be4a0b71-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3C06B8]
+       mov       r11,7FFAAEE006B8
-       call      qword ptr [7FFAAF3F06B8]
-       mov       r11,7FFAAEE306B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF43CAA0
-       mov       rdx,7FFAAF46CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF436430
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,2CCCC3D39C0
-       mov       r9,1CA8A46DD88
        mov       r8,[r8]
+       mov       r8,2CCCC3C3020
-       mov       r8,1CAAA463020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF435F60
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9ce45933-a594-4c66-85ec-857eac235dc9-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4994d45c-02bd-496d-aee9-73fb5a355f06-diff.temp
index 9028454..8a4b58e 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4994d45c-02bd-496d-aee9-73fb5a355f06-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9ce45933-a594-4c66-85ec-857eac235dc9-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/629fa0a5-534b-468b-b7cb-070cbfed72a8-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c02905c2-23b8-4a0a-b28e-426c0b555c62-diff.temp
index 9028454..19e1b2d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c02905c2-23b8-4a0a-b28e-426c0b555c62-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/629fa0a5-534b-468b-b7cb-070cbfed72a8-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3E06B8]
+       mov       r11,7FFAAEE206B8
-       call      qword ptr [7FFAAF3F06B8]
-       mov       r11,7FFAAEE306B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF45CAA0
-       mov       rdx,7FFAAF46CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF456430
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,23869E009B0
-       mov       r9,1CA8A46DD88
        mov       r8,[r8]
+       mov       r8,23869DF1028
-       mov       r8,1CAAA463020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF455F60
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5226e7d6-4df1-451a-9d69-e79430b5302e-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f4f00ede-5c22-44f5-848e-9bb14c0f1c59-diff.temp
index 9028454..ff19c94 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f4f00ede-5c22-44f5-848e-9bb14c0f1c59-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5226e7d6-4df1-451a-9d69-e79430b5302e-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3D06B8]
+       mov       r11,7FFAAEE106B8
-       call      qword ptr [7FFAAF3F06B8]
-       mov       r11,7FFAAEE306B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF44CAB0
-       mov       rdx,7FFAAF46CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4463E8
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,23F58E42170
-       mov       r9,1CA8A46DD88
        mov       r8,[r8]
+       mov       r8,23F48E43020
-       mov       r8,1CAAA463020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF445F18
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7f1cc38e-9741-48f6-8966-9b8b6391cc69-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/efe04ea3-6717-4a2d-9458-5fe0222235eb-diff.temp
index 9028454..b4f7204 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/efe04ea3-6717-4a2d-9458-5fe0222235eb-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7f1cc38e-9741-48f6-8966-9b8b6391cc69-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3D06B8]
+       mov       r11,7FFAAEE106B8
-       call      qword ptr [7FFAAF3F06B8]
-       mov       r11,7FFAAEE306B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF44CA58
-       mov       rdx,7FFAAF46CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4463E8
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,2C856E51958
-       mov       r9,1CA8A46DD88
        mov       r8,[r8]
+       mov       r8,2C846E53020
-       mov       r8,1CAAA463020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF445F18
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0860663e-5c8d-454b-a3ed-63d8c610c4a2-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/db4ca23f-21ee-465d-9a8b-ec0ef7e02472-diff.temp
index 9028454..0a4dbb8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/db4ca23f-21ee-465d-9a8b-ec0ef7e02472-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0860663e-5c8d-454b-a3ed-63d8c610c4a2-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3F07E0]
+       mov       r11,7FFAAEE207E0
-       call      qword ptr [7FFAAF3F06B8]
-       mov       r11,7FFAAEE306B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF484C30
-       mov       rdx,7FFAAF46CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF469F20
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1DAAED85D60
-       mov       r9,1CA8A46DD88
        mov       r8,[r8]
+       mov       r8,1DAAED83020
-       mov       r8,1CAAA463020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF469A50
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b2033446-eeb7-466b-835b-69e576984394-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1e16ce2e-60fc-42ce-8ce9-f7fe0e5b28c2-diff.temp
index 9028454..2dec7fe 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1e16ce2e-60fc-42ce-8ce9-f7fe0e5b28c2-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b2033446-eeb7-466b-835b-69e576984394-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3F06B8]
+       mov       r11,7FFAAEE306B8
-       call      qword ptr [7FFAAF3C06B8]
-       mov       r11,7FFAAEE006B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF46CAA0
-       mov       rdx,7FFAAF43CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF466430
-       mov       rdx,7FFAAF436430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1B4F76A1958
-       mov       r9,2CCCC3D39C0
        mov       r8,[r8]
+       mov       r8,1B5176A3020
-       mov       r8,2CCCC3C3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF465F60
-       mov       rdx,7FFAAF435F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7c12c355-46e8-47a2-9e8a-068f98fd946c-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ca82e5cc-3498-4069-a888-0718630f7b8a-diff.temp
index 8a4b58e..19e1b2d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ca82e5cc-3498-4069-a888-0718630f7b8a-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7c12c355-46e8-47a2-9e8a-068f98fd946c-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3E06B8]
+       mov       r11,7FFAAEE206B8
-       call      qword ptr [7FFAAF3C06B8]
-       mov       r11,7FFAAEE006B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF45CAA0
-       mov       rdx,7FFAAF43CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF456430
-       mov       rdx,7FFAAF436430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,23869E009B0
-       mov       r9,2CCCC3D39C0
        mov       r8,[r8]
+       mov       r8,23869DF1028
-       mov       r8,2CCCC3C3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF455F60
-       mov       rdx,7FFAAF435F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3a7e95e4-2e44-4d8c-9f71-a05e3c05ea71-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/bdd3c2f7-dd38-48cb-8492-2be727706238-diff.temp
index 8a4b58e..ff19c94 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/bdd3c2f7-dd38-48cb-8492-2be727706238-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3a7e95e4-2e44-4d8c-9f71-a05e3c05ea71-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3D06B8]
+       mov       r11,7FFAAEE106B8
-       call      qword ptr [7FFAAF3C06B8]
-       mov       r11,7FFAAEE006B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF44CAB0
-       mov       rdx,7FFAAF43CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4463E8
-       mov       rdx,7FFAAF436430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,23F58E42170
-       mov       r9,2CCCC3D39C0
        mov       r8,[r8]
+       mov       r8,23F48E43020
-       mov       r8,2CCCC3C3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF445F18
-       mov       rdx,7FFAAF435F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/77b38649-31e7-46f7-ab4e-6fd49e210e8a-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2f5f6dcc-edd2-4231-8ef4-aa0ff8ee321f-diff.temp
index 8a4b58e..b4f7204 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2f5f6dcc-edd2-4231-8ef4-aa0ff8ee321f-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/77b38649-31e7-46f7-ab4e-6fd49e210e8a-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3D06B8]
+       mov       r11,7FFAAEE106B8
-       call      qword ptr [7FFAAF3C06B8]
-       mov       r11,7FFAAEE006B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF44CA58
-       mov       rdx,7FFAAF43CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4463E8
-       mov       rdx,7FFAAF436430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,2C856E51958
-       mov       r9,2CCCC3D39C0
        mov       r8,[r8]
+       mov       r8,2C846E53020
-       mov       r8,2CCCC3C3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF445F18
-       mov       rdx,7FFAAF435F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9f5b8ca0-f151-435e-ba32-4230a2d0d1a0-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/aad79fa1-1792-48de-a826-2ae2e487c95a-diff.temp
index 8a4b58e..0a4dbb8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/aad79fa1-1792-48de-a826-2ae2e487c95a-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9f5b8ca0-f151-435e-ba32-4230a2d0d1a0-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3F07E0]
+       mov       r11,7FFAAEE207E0
-       call      qword ptr [7FFAAF3C06B8]
-       mov       r11,7FFAAEE006B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF484C30
-       mov       rdx,7FFAAF43CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF469F20
-       mov       rdx,7FFAAF436430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1DAAED85D60
-       mov       r9,2CCCC3D39C0
        mov       r8,[r8]
+       mov       r8,1DAAED83020
-       mov       r8,2CCCC3C3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF469A50
-       mov       rdx,7FFAAF435F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9a3a33e1-32c5-4cd1-9e24-50f70049b2e7-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/62a7000b-e89a-448e-b006-cf02f98df8c7-diff.temp
index 8a4b58e..2dec7fe 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/62a7000b-e89a-448e-b006-cf02f98df8c7-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9a3a33e1-32c5-4cd1-9e24-50f70049b2e7-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3E06B8]
+       mov       r11,7FFAAEE206B8
-       call      qword ptr [7FFAAF3F06B8]
-       mov       r11,7FFAAEE306B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF45CAA0
-       mov       rdx,7FFAAF46CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF456430
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,23869E009B0
-       mov       r9,1B4F76A1958
        mov       r8,[r8]
+       mov       r8,23869DF1028
-       mov       r8,1B5176A3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF455F60
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7e209d46-390e-4f03-9617-6d44a17ead54-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c8b0de17-97cd-4428-aeaa-0df90a4c7e78-diff.temp
index 19e1b2d..ff19c94 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c8b0de17-97cd-4428-aeaa-0df90a4c7e78-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7e209d46-390e-4f03-9617-6d44a17ead54-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3D06B8]
+       mov       r11,7FFAAEE106B8
-       call      qword ptr [7FFAAF3F06B8]
-       mov       r11,7FFAAEE306B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF44CAB0
-       mov       rdx,7FFAAF46CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4463E8
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,23F58E42170
-       mov       r9,1B4F76A1958
        mov       r8,[r8]
+       mov       r8,23F48E43020
-       mov       r8,1B5176A3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF445F18
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/92324a01-f14f-4f37-bd7b-1b8d289c3a25-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0ca32650-94cf-45e9-bc3e-91319d8146c4-diff.temp
index 19e1b2d..b4f7204 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0ca32650-94cf-45e9-bc3e-91319d8146c4-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/92324a01-f14f-4f37-bd7b-1b8d289c3a25-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3D06B8]
+       mov       r11,7FFAAEE106B8
-       call      qword ptr [7FFAAF3F06B8]
-       mov       r11,7FFAAEE306B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF44CA58
-       mov       rdx,7FFAAF46CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4463E8
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,2C856E51958
-       mov       r9,1B4F76A1958
        mov       r8,[r8]
+       mov       r8,2C846E53020
-       mov       r8,1B5176A3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF445F18
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/86207735-a56e-4696-8e6d-ca4b7cf19e8e-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/cc769ed7-d348-46dc-b586-3deaed01e3fd-diff.temp
index 19e1b2d..0a4dbb8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/cc769ed7-d348-46dc-b586-3deaed01e3fd-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/86207735-a56e-4696-8e6d-ca4b7cf19e8e-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3F07E0]
+       mov       r11,7FFAAEE207E0
-       call      qword ptr [7FFAAF3F06B8]
-       mov       r11,7FFAAEE306B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF484C30
-       mov       rdx,7FFAAF46CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF469F20
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1DAAED85D60
-       mov       r9,1B4F76A1958
        mov       r8,[r8]
+       mov       r8,1DAAED83020
-       mov       r8,1B5176A3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF469A50
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a079fc4d-eee4-4202-aa18-abee851cdf0c-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e27f43bc-d46b-43fc-bd02-26a7c3183a5e-diff.temp
index 19e1b2d..2dec7fe 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e27f43bc-d46b-43fc-bd02-26a7c3183a5e-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a079fc4d-eee4-4202-aa18-abee851cdf0c-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3D06B8]
+       mov       r11,7FFAAEE106B8
-       call      qword ptr [7FFAAF3E06B8]
-       mov       r11,7FFAAEE206B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF44CAB0
-       mov       rdx,7FFAAF45CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4463E8
-       mov       rdx,7FFAAF456430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,23F58E42170
-       mov       r9,23869E009B0
        mov       r8,[r8]
+       mov       r8,23F48E43020
-       mov       r8,23869DF1028
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF445F18
-       mov       rdx,7FFAAF455F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/fe9e5f40-ba98-4b72-9a9c-f25fdadccad7-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/15fd4c6d-9874-44ae-97b1-8d2b50b21d16-diff.temp
index ff19c94..b4f7204 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/15fd4c6d-9874-44ae-97b1-8d2b50b21d16-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/fe9e5f40-ba98-4b72-9a9c-f25fdadccad7-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3D06B8]
+       mov       r11,7FFAAEE106B8
-       call      qword ptr [7FFAAF3E06B8]
-       mov       r11,7FFAAEE206B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF44CA58
-       mov       rdx,7FFAAF45CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4463E8
-       mov       rdx,7FFAAF456430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,2C856E51958
-       mov       r9,23869E009B0
        mov       r8,[r8]
+       mov       r8,2C846E53020
-       mov       r8,23869DF1028
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF445F18
-       mov       rdx,7FFAAF455F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/969f28f1-5365-40ec-b0cf-8051c3bb700a-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/95b31d7d-ecc7-4dc1-bd6e-cdec9b40fe89-diff.temp
index ff19c94..0a4dbb8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/95b31d7d-ecc7-4dc1-bd6e-cdec9b40fe89-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/969f28f1-5365-40ec-b0cf-8051c3bb700a-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3F07E0]
+       mov       r11,7FFAAEE207E0
-       call      qword ptr [7FFAAF3E06B8]
-       mov       r11,7FFAAEE206B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF484C30
-       mov       rdx,7FFAAF45CAA0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF469F20
-       mov       rdx,7FFAAF456430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1DAAED85D60
-       mov       r9,23869E009B0
        mov       r8,[r8]
+       mov       r8,1DAAED83020
-       mov       r8,23869DF1028
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF469A50
-       mov       rdx,7FFAAF455F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6c42f55d-fe9b-4d4e-b4fc-790abad64bc9-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1c83140e-0f51-42f9-be35-c4b14e044a92-diff.temp
index ff19c94..2dec7fe 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1c83140e-0f51-42f9-be35-c4b14e044a92-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6c42f55d-fe9b-4d4e-b4fc-790abad64bc9-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,2C856E51958
-       mov       r9,23F58E42170
        mov       r8,[r8]
+       mov       r8,2C846E53020
-       mov       r8,23F48E43020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
        mov       rdx,7FFAAF445F18
        mov       rcx,rsi
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ab0a1c31-0f53-43c3-bc1d-3e9591520e22-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/97b3b209-2802-4bac-ad76-163bd4c79b26-diff.temp
index b4f7204..0a4dbb8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/97b3b209-2802-4bac-ad76-163bd4c79b26-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ab0a1c31-0f53-43c3-bc1d-3e9591520e22-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3F07E0]
+       mov       r11,7FFAAEE207E0
-       call      qword ptr [7FFAAF3D06B8]
-       mov       r11,7FFAAEE106B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF484C30
-       mov       rdx,7FFAAF44CAB0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF469F20
-       mov       rdx,7FFAAF4463E8
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1DAAED85D60
-       mov       r9,23F58E42170
        mov       r8,[r8]
+       mov       r8,1DAAED83020
-       mov       r8,23F48E43020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF469A50
-       mov       rdx,7FFAAF445F18
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f9bd2643-8583-44f8-8d5c-6212bfef2660-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d31287a8-7575-4671-a90e-7d347a7932ba-diff.temp
index b4f7204..2dec7fe 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d31287a8-7575-4671-a90e-7d347a7932ba-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f9bd2643-8583-44f8-8d5c-6212bfef2660-diff.temp
```
**Diff for HasItems02 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3F07E0]
+       mov       r11,7FFAAEE207E0
-       call      qword ptr [7FFAAF3D06B8]
-       mov       r11,7FFAAEE106B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF484C30
-       mov       rdx,7FFAAF44CA58
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF469F20
-       mov       rdx,7FFAAF4463E8
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1DAAED85D60
-       mov       r9,2C856E51958
        mov       r8,[r8]
+       mov       r8,1DAAED83020
-       mov       r8,2C846E53020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF469A50
-       mov       rdx,7FFAAF445F18
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 85
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e3451432-c5e7-4818-adc3-ed1e3fe3328f-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3ad89785-22d3-47a6-bdd8-8de05a170364-diff.temp
index 0a4dbb8..2dec7fe 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3ad89785-22d3-47a6-bdd8-8de05a170364-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e3451432-c5e7-4818-adc3-ed1e3fe3328f-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4C3AD0
-       mov       rdx,7FFAAF4B3AE8
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4C2110
-       mov       rdx,7FFAAF4B2128
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,21E3A9E4A88
-       mov       rax,1C97BB46A80
        mov       rbx,[rax]
+       mov       rax,21E3A9E1028
-       mov       rax,1C97BB43020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,21E3A9E5040
-       mov       r9,1C97BB47038
        mov       r8,[r8]
+       mov       r8,21E3A9E1028
-       mov       r8,1C97BB43020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4C1F98
-       mov       rdx,7FFAAF4B1FB0
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,21E3A9E4A98
-       mov       rax,1C97BB46A90
        mov       rbp,[rax]
+       mov       rax,21E3A9E1028
-       mov       rax,1C97BB43020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4C1D50
-       mov       rdx,7FFAAF4B1D68
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2F0570
-       mov       rdx,7FFAAF2E0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,21E5A9E35C0
-       mov       rax,1C99BB415C8
        mov       rbx,[rax]
+       mov       rax,21E3A9E1028
-       mov       rax,1C97BB43020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF456920
-       mov       rdx,7FFAAF446920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,21E3A9E4D80
-       mov       r9,1C97BB46D78
        mov       r8,[r8]
+       mov       r8,21E3A9E1028
-       mov       r8,1C97BB43020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF456450
-       mov       rdx,7FFAAF446450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,21E6A9EA938
-       mov       rax,1C9ABB4A938
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0E4000
-       mov       rcx,7FFAAF0D4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/eb32c133-bf99-4584-acbc-623ffcf099e6-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/febbbc9f-23c7-4b5f-8cf2-d4b3a7bcdc35-diff.temp
index 5d49773..16ce7be 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/febbbc9f-23c7-4b5f-8cf2-d4b3a7bcdc35-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/eb32c133-bf99-4584-acbc-623ffcf099e6-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A3B50
-       mov       rdx,7FFAAF4B3AE8
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A2190
-       mov       rdx,7FFAAF4B2128
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1444FFCE2A8
-       mov       rax,1C97BB46A80
        mov       rbx,[rax]
+       mov       rax,1442FFC3020
-       mov       rax,1C97BB43020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1444FFCE860
-       mov       r9,1C97BB47038
        mov       r8,[r8]
+       mov       r8,1442FFC3020
-       mov       r8,1C97BB43020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A2018
-       mov       rdx,7FFAAF4B1FB0
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1444FFCE2B8
-       mov       rax,1C97BB46A90
        mov       rbp,[rax]
+       mov       rax,1442FFC3020
-       mov       rax,1C97BB43020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A1DD0
-       mov       rdx,7FFAAF4B1D68
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2D0570
-       mov       rdx,7FFAAF2E0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1444FFCD9F8
-       mov       rax,1C99BB415C8
        mov       rbx,[rax]
+       mov       rax,1442FFC3020
-       mov       rax,1C97BB43020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF436920
-       mov       rdx,7FFAAF446920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1444FFCE5A0
-       mov       r9,1C97BB46D78
        mov       r8,[r8]
+       mov       r8,1442FFC3020
-       mov       r8,1C97BB43020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF436450
-       mov       rdx,7FFAAF446450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1444FFCA938
-       mov       rax,1C9ABB4A938
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0C4000
-       mov       rcx,7FFAAF0D4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/8924e69e-f7a2-4e72-879b-461d6dc31011-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ae791ce2-d344-4328-b9e2-6c2d76d34609-diff.temp
index 5d49773..0be8b9d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ae791ce2-d344-4328-b9e2-6c2d76d34609-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/8924e69e-f7a2-4e72-879b-461d6dc31011-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4C3AE8
-       mov       rdx,7FFAAF4B3AE8
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4C2128
-       mov       rdx,7FFAAF4B2128
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,274C4F31660
-       mov       rax,1C97BB46A80
        mov       rbx,[rax]
+       mov       rax,274E4F33020
-       mov       rax,1C97BB43020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,274C4F31C18
-       mov       r9,1C97BB47038
        mov       r8,[r8]
+       mov       r8,274E4F33020
-       mov       r8,1C97BB43020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4C1FB0
-       mov       rdx,7FFAAF4B1FB0
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,274C4F31670
-       mov       rax,1C97BB46A90
        mov       rbp,[rax]
+       mov       rax,274E4F33020
-       mov       rax,1C97BB43020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4C1D68
-       mov       rdx,7FFAAF4B1D68
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2F0570
-       mov       rdx,7FFAAF2E0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,274E4F41E00
-       mov       rax,1C99BB415C8
        mov       rbx,[rax]
+       mov       rax,274E4F33020
-       mov       rax,1C97BB43020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF456920
-       mov       rdx,7FFAAF446920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,274C4F31958
-       mov       r9,1C97BB46D78
        mov       r8,[r8]
+       mov       r8,274E4F33020
-       mov       r8,1C97BB43020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF456450
-       mov       rdx,7FFAAF446450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,274E4F3ED40
-       mov       rax,1C9ABB4A938
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0E4000
-       mov       rcx,7FFAAF0D4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/eab1034e-7cca-4e5a-b18e-fe85995584bc-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/93c2074b-d84b-485c-8426-29b19e38fefd-diff.temp
index 5d49773..3f9444b 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/93c2074b-d84b-485c-8426-29b19e38fefd-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/eab1034e-7cca-4e5a-b18e-fe85995584bc-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF493B50
-       mov       rdx,7FFAAF4B3AE8
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF492190
-       mov       rdx,7FFAAF4B2128
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1E3549C1E78
-       mov       rax,1C97BB46A80
        mov       rbx,[rax]
+       mov       rax,1E3349C1028
-       mov       rax,1C97BB43020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1E3549C2430
-       mov       r9,1C97BB47038
        mov       r8,[r8]
+       mov       r8,1E3349C1028
-       mov       r8,1C97BB43020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF492018
-       mov       rdx,7FFAAF4B1FB0
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1E3549C1E88
-       mov       rax,1C97BB46A90
        mov       rbp,[rax]
+       mov       rax,1E3349C1028
-       mov       rax,1C97BB43020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF491DD0
-       mov       rdx,7FFAAF4B1D68
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2C0570
-       mov       rdx,7FFAAF2E0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1E3549C15C8
-       mov       rax,1C99BB415C8
        mov       rbx,[rax]
+       mov       rax,1E3349C1028
-       mov       rax,1C97BB43020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF426920
-       mov       rdx,7FFAAF446920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1E3549C2170
-       mov       r9,1C97BB46D78
        mov       r8,[r8]
+       mov       r8,1E3349C1028
-       mov       r8,1C97BB43020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF426450
-       mov       rdx,7FFAAF446450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1E3649CA940
-       mov       rax,1C9ABB4A938
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0B4000
-       mov       rcx,7FFAAF0D4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/177fb237-7824-40e7-a254-4493e4b995b4-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b1d845ad-0225-4745-94dd-ae66032676ca-diff.temp
index 5d49773..63b0825 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b1d845ad-0225-4745-94dd-ae66032676ca-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/177fb237-7824-40e7-a254-4493e4b995b4-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A3AE8
-       mov       rdx,7FFAAF4B3AE8
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A2128
-       mov       rdx,7FFAAF4B2128
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,21A95961660
-       mov       rax,1C97BB46A80
        mov       rbx,[rax]
+       mov       rax,21A85963020
-       mov       rax,1C97BB43020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,21A95961C18
-       mov       r9,1C97BB47038
        mov       r8,[r8]
+       mov       r8,21A85963020
-       mov       r8,1C97BB43020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A1FB0
-       mov       rdx,7FFAAF4B1FB0
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,21A95961670
-       mov       rax,1C97BB46A90
        mov       rbp,[rax]
+       mov       rax,21A85963020
-       mov       rax,1C97BB43020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A1D68
-       mov       rdx,7FFAAF4B1D68
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2D0570
-       mov       rdx,7FFAAF2E0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,21A85971E00
-       mov       rax,1C99BB415C8
        mov       rbx,[rax]
+       mov       rax,21A85963020
-       mov       rax,1C97BB43020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4368D8
-       mov       rdx,7FFAAF446920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,21A95961958
-       mov       r9,1C97BB46D78
        mov       r8,[r8]
+       mov       r8,21A85963020
-       mov       r8,1C97BB43020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF436408
-       mov       rdx,7FFAAF446450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,21A8596ED48
-       mov       rax,1C9ABB4A938
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0C4000
-       mov       rcx,7FFAAF0D4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f67f183f-1d59-4126-8edc-98f5c6ca3d8c-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/486ecc0c-28c1-4e07-b3df-52a1ec6b90d1-diff.temp
index 5d49773..14c9673 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/486ecc0c-28c1-4e07-b3df-52a1ec6b90d1-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f67f183f-1d59-4126-8edc-98f5c6ca3d8c-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B3B50
-       mov       rdx,7FFAAF4B3AE8
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2190
-       mov       rdx,7FFAAF4B2128
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1C73EBE1E98
-       mov       rax,1C97BB46A80
        mov       rbx,[rax]
+       mov       rax,1C73EBD3020
-       mov       rax,1C97BB43020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1C73EBE2450
-       mov       r9,1C97BB47038
        mov       r8,[r8]
+       mov       r8,1C73EBD3020
-       mov       r8,1C97BB43020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2018
-       mov       rdx,7FFAAF4B1FB0
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1C73EBE1EA8
-       mov       rax,1C97BB46A90
        mov       rbp,[rax]
+       mov       rax,1C73EBD3020
-       mov       rax,1C97BB43020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B1DD0
-       mov       rdx,7FFAAF4B1D68
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1C75EBD15C8
-       mov       rax,1C99BB415C8
        mov       rbx,[rax]
+       mov       rax,1C73EBD3020
-       mov       rax,1C97BB43020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4468D8
-       mov       rdx,7FFAAF446920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1C73EBE2190
-       mov       r9,1C97BB46D78
        mov       r8,[r8]
+       mov       r8,1C73EBD3020
-       mov       r8,1C97BB43020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF446408
-       mov       rdx,7FFAAF446450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1C73EBDED48
-       mov       rax,1C9ABB4A938
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
        mov       rcx,7FFAAF0D4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c4d3924c-e1b4-42a5-9cc7-377216b73fc0-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9c14e88c-70a5-4fe8-8f16-7d34ad1519f4-diff.temp
index 5d49773..e2e776a 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9c14e88c-70a5-4fe8-8f16-7d34ad1519f4-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c4d3924c-e1b4-42a5-9cc7-377216b73fc0-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B3B68
-       mov       rdx,7FFAAF4B3AE8
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B21A8
-       mov       rdx,7FFAAF4B2128
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1AAFED31E98
-       mov       rax,1C97BB46A80
        mov       rbx,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,1C97BB43020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1AAFED32450
-       mov       r9,1C97BB47038
        mov       r8,[r8]
+       mov       r8,1AAFED23020
-       mov       r8,1C97BB43020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2030
-       mov       rdx,7FFAAF4B1FB0
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1AAFED31EA8
-       mov       rax,1C97BB46A90
        mov       rbp,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,1C97BB43020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B1DE8
-       mov       rdx,7FFAAF4B1D68
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2D0570
-       mov       rdx,7FFAAF2E0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1AB0ED215C8
-       mov       rax,1C99BB415C8
        mov       rbx,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,1C97BB43020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF44A410
-       mov       rdx,7FFAAF446920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1AAFED32190
-       mov       r9,1C97BB46D78
        mov       r8,[r8]
+       mov       r8,1AAFED23020
-       mov       r8,1C97BB43020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF449F40
-       mov       rdx,7FFAAF446450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1AAFED2ED48
-       mov       rax,1C9ABB4A938
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0C4000
-       mov       rcx,7FFAAF0D4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/38020852-bef2-49a5-8008-1aa72d0313ef-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9072eaa2-c353-46b2-85ee-7a839de2e63e-diff.temp
index 5d49773..676048c 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9072eaa2-c353-46b2-85ee-7a839de2e63e-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/38020852-bef2-49a5-8008-1aa72d0313ef-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A3B50
-       mov       rdx,7FFAAF4C3AD0
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A2190
-       mov       rdx,7FFAAF4C2110
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1444FFCE2A8
-       mov       rax,21E3A9E4A88
        mov       rbx,[rax]
+       mov       rax,1442FFC3020
-       mov       rax,21E3A9E1028
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1444FFCE860
-       mov       r9,21E3A9E5040
        mov       r8,[r8]
+       mov       r8,1442FFC3020
-       mov       r8,21E3A9E1028
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A2018
-       mov       rdx,7FFAAF4C1F98
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1444FFCE2B8
-       mov       rax,21E3A9E4A98
        mov       rbp,[rax]
+       mov       rax,1442FFC3020
-       mov       rax,21E3A9E1028
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A1DD0
-       mov       rdx,7FFAAF4C1D50
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2D0570
-       mov       rdx,7FFAAF2F0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1444FFCD9F8
-       mov       rax,21E5A9E35C0
        mov       rbx,[rax]
+       mov       rax,1442FFC3020
-       mov       rax,21E3A9E1028
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF436920
-       mov       rdx,7FFAAF456920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1444FFCE5A0
-       mov       r9,21E3A9E4D80
        mov       r8,[r8]
+       mov       r8,1442FFC3020
-       mov       r8,21E3A9E1028
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF436450
-       mov       rdx,7FFAAF456450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1444FFCA938
-       mov       rax,21E6A9EA938
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0C4000
-       mov       rcx,7FFAAF0E4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ca40f0a2-6686-4b5b-b2f7-0de58614fbb9-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/40d5d8ae-d5e7-441f-a358-e54b302aab5b-diff.temp
index 16ce7be..0be8b9d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/40d5d8ae-d5e7-441f-a358-e54b302aab5b-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ca40f0a2-6686-4b5b-b2f7-0de58614fbb9-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4C3AE8
-       mov       rdx,7FFAAF4C3AD0
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4C2128
-       mov       rdx,7FFAAF4C2110
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,274C4F31660
-       mov       rax,21E3A9E4A88
        mov       rbx,[rax]
+       mov       rax,274E4F33020
-       mov       rax,21E3A9E1028
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,274C4F31C18
-       mov       r9,21E3A9E5040
        mov       r8,[r8]
+       mov       r8,274E4F33020
-       mov       r8,21E3A9E1028
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4C1FB0
-       mov       rdx,7FFAAF4C1F98
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,274C4F31670
-       mov       rax,21E3A9E4A98
        mov       rbp,[rax]
+       mov       rax,274E4F33020
-       mov       rax,21E3A9E1028
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4C1D68
-       mov       rdx,7FFAAF4C1D50
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,274E4F41E00
-       mov       rax,21E5A9E35C0
        mov       rbx,[rax]
+       mov       rax,274E4F33020
-       mov       rax,21E3A9E1028
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
        mov       rdx,7FFAAF456920
        mov       rcx,rsi
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,274C4F31958
-       mov       r9,21E3A9E4D80
        mov       r8,[r8]
+       mov       r8,274E4F33020
-       mov       r8,21E3A9E1028
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
        mov       rdx,7FFAAF456450
        mov       rcx,rsi
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,274E4F3ED40
-       mov       rax,21E6A9EA938
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
        mov       rcx,7FFAAF0E4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3b39330d-65ce-460d-a54e-23e5362ba9a6-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7028d3b9-f8e0-40de-a7ae-f8d7f2859e4b-diff.temp
index 16ce7be..3f9444b 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7028d3b9-f8e0-40de-a7ae-f8d7f2859e4b-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3b39330d-65ce-460d-a54e-23e5362ba9a6-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF493B50
-       mov       rdx,7FFAAF4C3AD0
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF492190
-       mov       rdx,7FFAAF4C2110
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1E3549C1E78
-       mov       rax,21E3A9E4A88
        mov       rbx,[rax]
+       mov       rax,1E3349C1028
-       mov       rax,21E3A9E1028
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1E3549C2430
-       mov       r9,21E3A9E5040
        mov       r8,[r8]
+       mov       r8,1E3349C1028
-       mov       r8,21E3A9E1028
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF492018
-       mov       rdx,7FFAAF4C1F98
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1E3549C1E88
-       mov       rax,21E3A9E4A98
        mov       rbp,[rax]
+       mov       rax,1E3349C1028
-       mov       rax,21E3A9E1028
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF491DD0
-       mov       rdx,7FFAAF4C1D50
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2C0570
-       mov       rdx,7FFAAF2F0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1E3549C15C8
-       mov       rax,21E5A9E35C0
        mov       rbx,[rax]
+       mov       rax,1E3349C1028
-       mov       rax,21E3A9E1028
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF426920
-       mov       rdx,7FFAAF456920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1E3549C2170
-       mov       r9,21E3A9E4D80
        mov       r8,[r8]
+       mov       r8,1E3349C1028
-       mov       r8,21E3A9E1028
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF426450
-       mov       rdx,7FFAAF456450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1E3649CA940
-       mov       rax,21E6A9EA938
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0B4000
-       mov       rcx,7FFAAF0E4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/40bbefd0-d1f8-48df-adf0-88a73a9223d7-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1ee5d327-9b81-4d38-9d2f-466b3dbb635b-diff.temp
index 16ce7be..63b0825 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1ee5d327-9b81-4d38-9d2f-466b3dbb635b-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/40bbefd0-d1f8-48df-adf0-88a73a9223d7-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A3AE8
-       mov       rdx,7FFAAF4C3AD0
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A2128
-       mov       rdx,7FFAAF4C2110
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,21A95961660
-       mov       rax,21E3A9E4A88
        mov       rbx,[rax]
+       mov       rax,21A85963020
-       mov       rax,21E3A9E1028
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,21A95961C18
-       mov       r9,21E3A9E5040
        mov       r8,[r8]
+       mov       r8,21A85963020
-       mov       r8,21E3A9E1028
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A1FB0
-       mov       rdx,7FFAAF4C1F98
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,21A95961670
-       mov       rax,21E3A9E4A98
        mov       rbp,[rax]
+       mov       rax,21A85963020
-       mov       rax,21E3A9E1028
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A1D68
-       mov       rdx,7FFAAF4C1D50
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2D0570
-       mov       rdx,7FFAAF2F0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,21A85971E00
-       mov       rax,21E5A9E35C0
        mov       rbx,[rax]
+       mov       rax,21A85963020
-       mov       rax,21E3A9E1028
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4368D8
-       mov       rdx,7FFAAF456920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,21A95961958
-       mov       r9,21E3A9E4D80
        mov       r8,[r8]
+       mov       r8,21A85963020
-       mov       r8,21E3A9E1028
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF436408
-       mov       rdx,7FFAAF456450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,21A8596ED48
-       mov       rax,21E6A9EA938
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0C4000
-       mov       rcx,7FFAAF0E4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ab8d21f0-1a95-4093-af2c-a0c92b637966-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5bebe092-b37a-4723-83bb-2172b5d0fff3-diff.temp
index 16ce7be..14c9673 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5bebe092-b37a-4723-83bb-2172b5d0fff3-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ab8d21f0-1a95-4093-af2c-a0c92b637966-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B3B50
-       mov       rdx,7FFAAF4C3AD0
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2190
-       mov       rdx,7FFAAF4C2110
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1C73EBE1E98
-       mov       rax,21E3A9E4A88
        mov       rbx,[rax]
+       mov       rax,1C73EBD3020
-       mov       rax,21E3A9E1028
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1C73EBE2450
-       mov       r9,21E3A9E5040
        mov       r8,[r8]
+       mov       r8,1C73EBD3020
-       mov       r8,21E3A9E1028
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2018
-       mov       rdx,7FFAAF4C1F98
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1C73EBE1EA8
-       mov       rax,21E3A9E4A98
        mov       rbp,[rax]
+       mov       rax,1C73EBD3020
-       mov       rax,21E3A9E1028
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B1DD0
-       mov       rdx,7FFAAF4C1D50
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2E0570
-       mov       rdx,7FFAAF2F0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1C75EBD15C8
-       mov       rax,21E5A9E35C0
        mov       rbx,[rax]
+       mov       rax,1C73EBD3020
-       mov       rax,21E3A9E1028
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4468D8
-       mov       rdx,7FFAAF456920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1C73EBE2190
-       mov       r9,21E3A9E4D80
        mov       r8,[r8]
+       mov       r8,1C73EBD3020
-       mov       r8,21E3A9E1028
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF446408
-       mov       rdx,7FFAAF456450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1C73EBDED48
-       mov       rax,21E6A9EA938
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0D4000
-       mov       rcx,7FFAAF0E4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0e01512d-9a78-464c-b052-0cfbc1a97209-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/20153fb6-dc6f-4e24-9773-a074d3c5e685-diff.temp
index 16ce7be..e2e776a 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/20153fb6-dc6f-4e24-9773-a074d3c5e685-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0e01512d-9a78-464c-b052-0cfbc1a97209-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B3B68
-       mov       rdx,7FFAAF4C3AD0
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B21A8
-       mov       rdx,7FFAAF4C2110
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1AAFED31E98
-       mov       rax,21E3A9E4A88
        mov       rbx,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,21E3A9E1028
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1AAFED32450
-       mov       r9,21E3A9E5040
        mov       r8,[r8]
+       mov       r8,1AAFED23020
-       mov       r8,21E3A9E1028
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2030
-       mov       rdx,7FFAAF4C1F98
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1AAFED31EA8
-       mov       rax,21E3A9E4A98
        mov       rbp,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,21E3A9E1028
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B1DE8
-       mov       rdx,7FFAAF4C1D50
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2D0570
-       mov       rdx,7FFAAF2F0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1AB0ED215C8
-       mov       rax,21E5A9E35C0
        mov       rbx,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,21E3A9E1028
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF44A410
-       mov       rdx,7FFAAF456920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1AAFED32190
-       mov       r9,21E3A9E4D80
        mov       r8,[r8]
+       mov       r8,1AAFED23020
-       mov       r8,21E3A9E1028
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF449F40
-       mov       rdx,7FFAAF456450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1AAFED2ED48
-       mov       rax,21E6A9EA938
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0C4000
-       mov       rcx,7FFAAF0E4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3ab9c252-266e-4b54-8477-c3b953651c7e-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a23f139a-d4d4-4aaa-847c-273be71e0ea8-diff.temp
index 16ce7be..676048c 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a23f139a-d4d4-4aaa-847c-273be71e0ea8-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3ab9c252-266e-4b54-8477-c3b953651c7e-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4C3AE8
-       mov       rdx,7FFAAF4A3B50
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4C2128
-       mov       rdx,7FFAAF4A2190
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,274C4F31660
-       mov       rax,1444FFCE2A8
        mov       rbx,[rax]
+       mov       rax,274E4F33020
-       mov       rax,1442FFC3020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,274C4F31C18
-       mov       r9,1444FFCE860
        mov       r8,[r8]
+       mov       r8,274E4F33020
-       mov       r8,1442FFC3020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4C1FB0
-       mov       rdx,7FFAAF4A2018
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,274C4F31670
-       mov       rax,1444FFCE2B8
        mov       rbp,[rax]
+       mov       rax,274E4F33020
-       mov       rax,1442FFC3020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4C1D68
-       mov       rdx,7FFAAF4A1DD0
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2F0570
-       mov       rdx,7FFAAF2D0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,274E4F41E00
-       mov       rax,1444FFCD9F8
        mov       rbx,[rax]
+       mov       rax,274E4F33020
-       mov       rax,1442FFC3020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF456920
-       mov       rdx,7FFAAF436920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,274C4F31958
-       mov       r9,1444FFCE5A0
        mov       r8,[r8]
+       mov       r8,274E4F33020
-       mov       r8,1442FFC3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF456450
-       mov       rdx,7FFAAF436450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,274E4F3ED40
-       mov       rax,1444FFCA938
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0E4000
-       mov       rcx,7FFAAF0C4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ce011002-249b-4bc0-9c3f-f857ba8e914d-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c20c8240-b01d-4450-8769-5056e90d1f36-diff.temp
index 0be8b9d..3f9444b 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c20c8240-b01d-4450-8769-5056e90d1f36-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ce011002-249b-4bc0-9c3f-f857ba8e914d-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF493B50
-       mov       rdx,7FFAAF4A3B50
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF492190
-       mov       rdx,7FFAAF4A2190
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1E3549C1E78
-       mov       rax,1444FFCE2A8
        mov       rbx,[rax]
+       mov       rax,1E3349C1028
-       mov       rax,1442FFC3020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1E3549C2430
-       mov       r9,1444FFCE860
        mov       r8,[r8]
+       mov       r8,1E3349C1028
-       mov       r8,1442FFC3020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF492018
-       mov       rdx,7FFAAF4A2018
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1E3549C1E88
-       mov       rax,1444FFCE2B8
        mov       rbp,[rax]
+       mov       rax,1E3349C1028
-       mov       rax,1442FFC3020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF491DD0
-       mov       rdx,7FFAAF4A1DD0
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2C0570
-       mov       rdx,7FFAAF2D0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1E3549C15C8
-       mov       rax,1444FFCD9F8
        mov       rbx,[rax]
+       mov       rax,1E3349C1028
-       mov       rax,1442FFC3020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF426920
-       mov       rdx,7FFAAF436920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1E3549C2170
-       mov       r9,1444FFCE5A0
        mov       r8,[r8]
+       mov       r8,1E3349C1028
-       mov       r8,1442FFC3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF426450
-       mov       rdx,7FFAAF436450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1E3649CA940
-       mov       rax,1444FFCA938
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0B4000
-       mov       rcx,7FFAAF0C4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6212b4f3-074c-4574-b369-a6e3bbeced52-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/98ed3a9b-c26a-4087-a76d-1fde335f1796-diff.temp
index 0be8b9d..63b0825 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/98ed3a9b-c26a-4087-a76d-1fde335f1796-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6212b4f3-074c-4574-b369-a6e3bbeced52-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A3AE8
-       mov       rdx,7FFAAF4A3B50
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A2128
-       mov       rdx,7FFAAF4A2190
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,21A95961660
-       mov       rax,1444FFCE2A8
        mov       rbx,[rax]
+       mov       rax,21A85963020
-       mov       rax,1442FFC3020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,21A95961C18
-       mov       r9,1444FFCE860
        mov       r8,[r8]
+       mov       r8,21A85963020
-       mov       r8,1442FFC3020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A1FB0
-       mov       rdx,7FFAAF4A2018
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,21A95961670
-       mov       rax,1444FFCE2B8
        mov       rbp,[rax]
+       mov       rax,21A85963020
-       mov       rax,1442FFC3020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A1D68
-       mov       rdx,7FFAAF4A1DD0
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,21A85971E00
-       mov       rax,1444FFCD9F8
        mov       rbx,[rax]
+       mov       rax,21A85963020
-       mov       rax,1442FFC3020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4368D8
-       mov       rdx,7FFAAF436920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,21A95961958
-       mov       r9,1444FFCE5A0
        mov       r8,[r8]
+       mov       r8,21A85963020
-       mov       r8,1442FFC3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF436408
-       mov       rdx,7FFAAF436450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,21A8596ED48
-       mov       rax,1444FFCA938
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
        mov       rcx,7FFAAF0C4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f3163f45-b4e8-4739-8131-c298120ec8c5-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c20ebc63-e25c-484e-98ab-d70ebf9f3f35-diff.temp
index 0be8b9d..14c9673 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c20ebc63-e25c-484e-98ab-d70ebf9f3f35-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f3163f45-b4e8-4739-8131-c298120ec8c5-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B3B50
-       mov       rdx,7FFAAF4A3B50
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2190
-       mov       rdx,7FFAAF4A2190
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1C73EBE1E98
-       mov       rax,1444FFCE2A8
        mov       rbx,[rax]
+       mov       rax,1C73EBD3020
-       mov       rax,1442FFC3020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1C73EBE2450
-       mov       r9,1444FFCE860
        mov       r8,[r8]
+       mov       r8,1C73EBD3020
-       mov       r8,1442FFC3020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2018
-       mov       rdx,7FFAAF4A2018
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1C73EBE1EA8
-       mov       rax,1444FFCE2B8
        mov       rbp,[rax]
+       mov       rax,1C73EBD3020
-       mov       rax,1442FFC3020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B1DD0
-       mov       rdx,7FFAAF4A1DD0
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2E0570
-       mov       rdx,7FFAAF2D0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1C75EBD15C8
-       mov       rax,1444FFCD9F8
        mov       rbx,[rax]
+       mov       rax,1C73EBD3020
-       mov       rax,1442FFC3020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4468D8
-       mov       rdx,7FFAAF436920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1C73EBE2190
-       mov       r9,1444FFCE5A0
        mov       r8,[r8]
+       mov       r8,1C73EBD3020
-       mov       r8,1442FFC3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF446408
-       mov       rdx,7FFAAF436450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1C73EBDED48
-       mov       rax,1444FFCA938
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0D4000
-       mov       rcx,7FFAAF0C4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1a274012-e8fc-475f-ad12-1915fa3e863e-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/29678fdc-fbb5-413d-8580-e6fc4e27c27b-diff.temp
index 0be8b9d..e2e776a 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/29678fdc-fbb5-413d-8580-e6fc4e27c27b-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1a274012-e8fc-475f-ad12-1915fa3e863e-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B3B68
-       mov       rdx,7FFAAF4A3B50
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B21A8
-       mov       rdx,7FFAAF4A2190
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1AAFED31E98
-       mov       rax,1444FFCE2A8
        mov       rbx,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,1442FFC3020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1AAFED32450
-       mov       r9,1444FFCE860
        mov       r8,[r8]
+       mov       r8,1AAFED23020
-       mov       r8,1442FFC3020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2030
-       mov       rdx,7FFAAF4A2018
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1AAFED31EA8
-       mov       rax,1444FFCE2B8
        mov       rbp,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,1442FFC3020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B1DE8
-       mov       rdx,7FFAAF4A1DD0
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1AB0ED215C8
-       mov       rax,1444FFCD9F8
        mov       rbx,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,1442FFC3020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF44A410
-       mov       rdx,7FFAAF436920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1AAFED32190
-       mov       r9,1444FFCE5A0
        mov       r8,[r8]
+       mov       r8,1AAFED23020
-       mov       r8,1442FFC3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF449F40
-       mov       rdx,7FFAAF436450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1AAFED2ED48
-       mov       rax,1444FFCA938
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
        mov       rcx,7FFAAF0C4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2557e5b8-a2cc-4b06-8762-a128b3dd6bcc-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/204cc8c3-8a8d-4ca4-8358-15d5aef2bb15-diff.temp
index 0be8b9d..676048c 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/204cc8c3-8a8d-4ca4-8358-15d5aef2bb15-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2557e5b8-a2cc-4b06-8762-a128b3dd6bcc-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF493B50
-       mov       rdx,7FFAAF4C3AE8
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF492190
-       mov       rdx,7FFAAF4C2128
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1E3549C1E78
-       mov       rax,274C4F31660
        mov       rbx,[rax]
+       mov       rax,1E3349C1028
-       mov       rax,274E4F33020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1E3549C2430
-       mov       r9,274C4F31C18
        mov       r8,[r8]
+       mov       r8,1E3349C1028
-       mov       r8,274E4F33020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF492018
-       mov       rdx,7FFAAF4C1FB0
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1E3549C1E88
-       mov       rax,274C4F31670
        mov       rbp,[rax]
+       mov       rax,1E3349C1028
-       mov       rax,274E4F33020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF491DD0
-       mov       rdx,7FFAAF4C1D68
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2C0570
-       mov       rdx,7FFAAF2F0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1E3549C15C8
-       mov       rax,274E4F41E00
        mov       rbx,[rax]
+       mov       rax,1E3349C1028
-       mov       rax,274E4F33020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF426920
-       mov       rdx,7FFAAF456920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1E3549C2170
-       mov       r9,274C4F31958
        mov       r8,[r8]
+       mov       r8,1E3349C1028
-       mov       r8,274E4F33020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF426450
-       mov       rdx,7FFAAF456450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1E3649CA940
-       mov       rax,274E4F3ED40
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0B4000
-       mov       rcx,7FFAAF0E4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/dcc0728a-315c-4d88-89ec-b2bc6d55f146-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4da114df-86a5-468e-bede-3818b583683b-diff.temp
index 3f9444b..63b0825 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4da114df-86a5-468e-bede-3818b583683b-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/dcc0728a-315c-4d88-89ec-b2bc6d55f146-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A3AE8
-       mov       rdx,7FFAAF4C3AE8
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A2128
-       mov       rdx,7FFAAF4C2128
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,21A95961660
-       mov       rax,274C4F31660
        mov       rbx,[rax]
+       mov       rax,21A85963020
-       mov       rax,274E4F33020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,21A95961C18
-       mov       r9,274C4F31C18
        mov       r8,[r8]
+       mov       r8,21A85963020
-       mov       r8,274E4F33020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A1FB0
-       mov       rdx,7FFAAF4C1FB0
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,21A95961670
-       mov       rax,274C4F31670
        mov       rbp,[rax]
+       mov       rax,21A85963020
-       mov       rax,274E4F33020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A1D68
-       mov       rdx,7FFAAF4C1D68
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2D0570
-       mov       rdx,7FFAAF2F0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,21A85971E00
-       mov       rax,274E4F41E00
        mov       rbx,[rax]
+       mov       rax,21A85963020
-       mov       rax,274E4F33020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4368D8
-       mov       rdx,7FFAAF456920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,21A95961958
-       mov       r9,274C4F31958
        mov       r8,[r8]
+       mov       r8,21A85963020
-       mov       r8,274E4F33020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF436408
-       mov       rdx,7FFAAF456450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,21A8596ED48
-       mov       rax,274E4F3ED40
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0C4000
-       mov       rcx,7FFAAF0E4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/8b90b539-25b2-494b-9447-3a0d06fb4c52-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2d4487cb-e4e3-468c-adae-bf9238d8b136-diff.temp
index 3f9444b..14c9673 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2d4487cb-e4e3-468c-adae-bf9238d8b136-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/8b90b539-25b2-494b-9447-3a0d06fb4c52-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B3B50
-       mov       rdx,7FFAAF4C3AE8
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2190
-       mov       rdx,7FFAAF4C2128
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1C73EBE1E98
-       mov       rax,274C4F31660
        mov       rbx,[rax]
+       mov       rax,1C73EBD3020
-       mov       rax,274E4F33020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1C73EBE2450
-       mov       r9,274C4F31C18
        mov       r8,[r8]
+       mov       r8,1C73EBD3020
-       mov       r8,274E4F33020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2018
-       mov       rdx,7FFAAF4C1FB0
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1C73EBE1EA8
-       mov       rax,274C4F31670
        mov       rbp,[rax]
+       mov       rax,1C73EBD3020
-       mov       rax,274E4F33020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B1DD0
-       mov       rdx,7FFAAF4C1D68
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2E0570
-       mov       rdx,7FFAAF2F0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1C75EBD15C8
-       mov       rax,274E4F41E00
        mov       rbx,[rax]
+       mov       rax,1C73EBD3020
-       mov       rax,274E4F33020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4468D8
-       mov       rdx,7FFAAF456920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1C73EBE2190
-       mov       r9,274C4F31958
        mov       r8,[r8]
+       mov       r8,1C73EBD3020
-       mov       r8,274E4F33020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF446408
-       mov       rdx,7FFAAF456450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1C73EBDED48
-       mov       rax,274E4F3ED40
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0D4000
-       mov       rcx,7FFAAF0E4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/032bd2d4-c0f8-424f-89c8-6ccb4574ac2a-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/125f2636-e1b4-4ccc-a081-05af818d0362-diff.temp
index 3f9444b..e2e776a 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/125f2636-e1b4-4ccc-a081-05af818d0362-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/032bd2d4-c0f8-424f-89c8-6ccb4574ac2a-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B3B68
-       mov       rdx,7FFAAF4C3AE8
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B21A8
-       mov       rdx,7FFAAF4C2128
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1AAFED31E98
-       mov       rax,274C4F31660
        mov       rbx,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,274E4F33020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1AAFED32450
-       mov       r9,274C4F31C18
        mov       r8,[r8]
+       mov       r8,1AAFED23020
-       mov       r8,274E4F33020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2030
-       mov       rdx,7FFAAF4C1FB0
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1AAFED31EA8
-       mov       rax,274C4F31670
        mov       rbp,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,274E4F33020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B1DE8
-       mov       rdx,7FFAAF4C1D68
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2D0570
-       mov       rdx,7FFAAF2F0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1AB0ED215C8
-       mov       rax,274E4F41E00
        mov       rbx,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,274E4F33020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF44A410
-       mov       rdx,7FFAAF456920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1AAFED32190
-       mov       r9,274C4F31958
        mov       r8,[r8]
+       mov       r8,1AAFED23020
-       mov       r8,274E4F33020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF449F40
-       mov       rdx,7FFAAF456450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1AAFED2ED48
-       mov       rax,274E4F3ED40
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0C4000
-       mov       rcx,7FFAAF0E4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b588e2ab-88c0-473f-8d0f-72022f0bf808-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/578bf74a-8cae-49af-a045-b03ebcd8ceb0-diff.temp
index 3f9444b..676048c 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/578bf74a-8cae-49af-a045-b03ebcd8ceb0-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b588e2ab-88c0-473f-8d0f-72022f0bf808-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A3AE8
-       mov       rdx,7FFAAF493B50
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A2128
-       mov       rdx,7FFAAF492190
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,21A95961660
-       mov       rax,1E3549C1E78
        mov       rbx,[rax]
+       mov       rax,21A85963020
-       mov       rax,1E3349C1028
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,21A95961C18
-       mov       r9,1E3549C2430
        mov       r8,[r8]
+       mov       r8,21A85963020
-       mov       r8,1E3349C1028
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A1FB0
-       mov       rdx,7FFAAF492018
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,21A95961670
-       mov       rax,1E3549C1E88
        mov       rbp,[rax]
+       mov       rax,21A85963020
-       mov       rax,1E3349C1028
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4A1D68
-       mov       rdx,7FFAAF491DD0
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2D0570
-       mov       rdx,7FFAAF2C0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,21A85971E00
-       mov       rax,1E3549C15C8
        mov       rbx,[rax]
+       mov       rax,21A85963020
-       mov       rax,1E3349C1028
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4368D8
-       mov       rdx,7FFAAF426920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,21A95961958
-       mov       r9,1E3549C2170
        mov       r8,[r8]
+       mov       r8,21A85963020
-       mov       r8,1E3349C1028
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF436408
-       mov       rdx,7FFAAF426450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,21A8596ED48
-       mov       rax,1E3649CA940
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0C4000
-       mov       rcx,7FFAAF0B4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b53a4617-0851-4d0a-9e39-89d8f8f27b25-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e9c867ce-e9b9-4e98-b6a7-ecfe5e2bc8eb-diff.temp
index 63b0825..14c9673 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e9c867ce-e9b9-4e98-b6a7-ecfe5e2bc8eb-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b53a4617-0851-4d0a-9e39-89d8f8f27b25-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B3B50
-       mov       rdx,7FFAAF493B50
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2190
-       mov       rdx,7FFAAF492190
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1C73EBE1E98
-       mov       rax,1E3549C1E78
        mov       rbx,[rax]
+       mov       rax,1C73EBD3020
-       mov       rax,1E3349C1028
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1C73EBE2450
-       mov       r9,1E3549C2430
        mov       r8,[r8]
+       mov       r8,1C73EBD3020
-       mov       r8,1E3349C1028
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2018
-       mov       rdx,7FFAAF492018
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1C73EBE1EA8
-       mov       rax,1E3549C1E88
        mov       rbp,[rax]
+       mov       rax,1C73EBD3020
-       mov       rax,1E3349C1028
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B1DD0
-       mov       rdx,7FFAAF491DD0
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2E0570
-       mov       rdx,7FFAAF2C0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1C75EBD15C8
-       mov       rax,1E3549C15C8
        mov       rbx,[rax]
+       mov       rax,1C73EBD3020
-       mov       rax,1E3349C1028
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4468D8
-       mov       rdx,7FFAAF426920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1C73EBE2190
-       mov       r9,1E3549C2170
        mov       r8,[r8]
+       mov       r8,1C73EBD3020
-       mov       r8,1E3349C1028
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF446408
-       mov       rdx,7FFAAF426450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1C73EBDED48
-       mov       rax,1E3649CA940
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0D4000
-       mov       rcx,7FFAAF0B4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/8f398611-da32-4c72-b7d2-3641609964ca-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/70e5bf9f-40df-4002-8f8e-2ac9b1d30807-diff.temp
index 63b0825..e2e776a 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/70e5bf9f-40df-4002-8f8e-2ac9b1d30807-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/8f398611-da32-4c72-b7d2-3641609964ca-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B3B68
-       mov       rdx,7FFAAF493B50
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B21A8
-       mov       rdx,7FFAAF492190
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1AAFED31E98
-       mov       rax,1E3549C1E78
        mov       rbx,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,1E3349C1028
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1AAFED32450
-       mov       r9,1E3549C2430
        mov       r8,[r8]
+       mov       r8,1AAFED23020
-       mov       r8,1E3349C1028
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2030
-       mov       rdx,7FFAAF492018
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1AAFED31EA8
-       mov       rax,1E3549C1E88
        mov       rbp,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,1E3349C1028
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B1DE8
-       mov       rdx,7FFAAF491DD0
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2D0570
-       mov       rdx,7FFAAF2C0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1AB0ED215C8
-       mov       rax,1E3549C15C8
        mov       rbx,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,1E3349C1028
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF44A410
-       mov       rdx,7FFAAF426920
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1AAFED32190
-       mov       r9,1E3549C2170
        mov       r8,[r8]
+       mov       r8,1AAFED23020
-       mov       r8,1E3349C1028
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF449F40
-       mov       rdx,7FFAAF426450
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1AAFED2ED48
-       mov       rax,1E3649CA940
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0C4000
-       mov       rcx,7FFAAF0B4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/88929752-7946-4350-a874-ef8a422bcd85-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/18d596d1-1923-4413-97b5-c4cfea330bc2-diff.temp
index 63b0825..676048c 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/18d596d1-1923-4413-97b5-c4cfea330bc2-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/88929752-7946-4350-a874-ef8a422bcd85-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B3B50
-       mov       rdx,7FFAAF4A3AE8
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2190
-       mov       rdx,7FFAAF4A2128
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1C73EBE1E98
-       mov       rax,21A95961660
        mov       rbx,[rax]
+       mov       rax,1C73EBD3020
-       mov       rax,21A85963020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1C73EBE2450
-       mov       r9,21A95961C18
        mov       r8,[r8]
+       mov       r8,1C73EBD3020
-       mov       r8,21A85963020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2018
-       mov       rdx,7FFAAF4A1FB0
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1C73EBE1EA8
-       mov       rax,21A95961670
        mov       rbp,[rax]
+       mov       rax,1C73EBD3020
-       mov       rax,21A85963020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B1DD0
-       mov       rdx,7FFAAF4A1D68
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2E0570
-       mov       rdx,7FFAAF2D0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1C75EBD15C8
-       mov       rax,21A85971E00
        mov       rbx,[rax]
+       mov       rax,1C73EBD3020
-       mov       rax,21A85963020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4468D8
-       mov       rdx,7FFAAF4368D8
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1C73EBE2190
-       mov       r9,21A95961958
        mov       r8,[r8]
+       mov       r8,1C73EBD3020
-       mov       r8,21A85963020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF446408
-       mov       rdx,7FFAAF436408
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1C73EBDED48
-       mov       rax,21A8596ED48
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0D4000
-       mov       rcx,7FFAAF0C4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/62be1262-6007-4d35-abfc-e2b3b77954a5-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2e15ab5a-9ca8-413e-8c19-05fd8f6ab268-diff.temp
index 14c9673..e2e776a 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2e15ab5a-9ca8-413e-8c19-05fd8f6ab268-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/62be1262-6007-4d35-abfc-e2b3b77954a5-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B3B68
-       mov       rdx,7FFAAF4A3AE8
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B21A8
-       mov       rdx,7FFAAF4A2128
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1AAFED31E98
-       mov       rax,21A95961660
        mov       rbx,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,21A85963020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1AAFED32450
-       mov       r9,21A95961C18
        mov       r8,[r8]
+       mov       r8,1AAFED23020
-       mov       r8,21A85963020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2030
-       mov       rdx,7FFAAF4A1FB0
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1AAFED31EA8
-       mov       rax,21A95961670
        mov       rbp,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,21A85963020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B1DE8
-       mov       rdx,7FFAAF4A1D68
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1AB0ED215C8
-       mov       rax,21A85971E00
        mov       rbx,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,21A85963020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF44A410
-       mov       rdx,7FFAAF4368D8
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1AAFED32190
-       mov       r9,21A95961958
        mov       r8,[r8]
+       mov       r8,1AAFED23020
-       mov       r8,21A85963020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF449F40
-       mov       rdx,7FFAAF436408
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1AAFED2ED48
-       mov       rax,21A8596ED48
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
        mov       rcx,7FFAAF0C4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9f841a01-2b33-4c45-9d25-b779042a2800-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/68663495-57bd-442c-9b01-90524271b02c-diff.temp
index 14c9673..676048c 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/68663495-57bd-442c-9b01-90524271b02c-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9f841a01-2b33-4c45-9d25-b779042a2800-diff.temp
```
**Diff for AddRange01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M03_L09:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B3B68
-       mov       rdx,7FFAAF4B3B50
        mov       rcx,rsi
 M03_L08:
        jmp       short M03_L09
        je        short M03_L08
        test      rcx,rcx
        mov       rcx,[rcx+38]
        jle       short M03_L08
        cmp       qword ptr [rcx+8],38
        mov       rcx,rbx
        mov       rbx,[rsi+10]
        je        near ptr M03_L12
        test      ecx,ecx
        movzx     ecx,cl
        setg      cl
        test      eax,eax
        call      DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
        mov       rcx,rdi
        je        near ptr M03_L12
        test      rdi,rdi
        mov       byte ptr [r15+14],0
        call      System.Diagnostics.TraceInternal.WriteLine(System.Object)
        mov       rcx,r14
        mov       [r14+8],al
        call      DotNetTips.Spargine.Extensions.CollectionExtensions.CreateCollectionIfNull[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon> ByRef)
        mov       rdx,rbx
        mov       rcx,rbp
        mov       r14,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.Boolean
 M03_L07:
        mov       rbp,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B21A8
-       mov       rdx,7FFAAF4B2190
        mov       rcx,rsi
 M03_L06:
        jmp       short M03_L07
        je        short M03_L06
        test      rbp,rbp
        mov       rbp,[rcx+30]
        jle       short M03_L06
        cmp       qword ptr [rcx+8],30
        lea       rbx,[r15+8]
        mov       rcx,[rsi+10]
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1AAFED31E98
-       mov       rax,1C73EBE1E98
        mov       rbx,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,1C73EBD3020
        jne       short M03_L05
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rax
        lea       rcx,[r15+8]
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotReadOnly[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.String, System.String)
        mov       rdx,rbx
        mov       r9,[r9]
+       mov       r9,1AAFED32450
-       mov       r9,1C73EBE2450
        mov       r8,[r8]
+       mov       r8,1AAFED23020
-       mov       r8,1C73EBD3020
 M03_L04:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B2030
-       mov       rdx,7FFAAF4B2018
        mov       rcx,rsi
 M03_L03:
        jmp       short M03_L04
        mov       rcx,[r14+20]
        je        short M03_L03
        cmp       qword ptr [r14+20],0
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbp
        mov       rdx,r12
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       r12,[rax]
+       mov       rax,1AAFED31EA8
-       mov       rax,1C73EBE1EA8
        mov       rbp,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,1C73EBD3020
        jne       short M03_L02
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rbx,rbx
        mov       rbx,[r15+8]
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,rbx
        lea       rcx,[r15+8]
        mov       [r15+10],ebp
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
 M03_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4B1DE8
-       mov       rdx,7FFAAF4B1DD0
        mov       rcx,rsi
 M03_L00:
        jmp       short M03_L01
        mov       rcx,[r14+10]
        je        short M03_L00
        cmp       qword ptr [r14+10],0
        mov       r14,[rsi+10]
        mov       ebp,r9d
        mov       rdi,r8
        mov       rbx,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rbp
        push      rsi
        push      rdi
        push      r12
        push      r14
        push      r15
 ; DotNetTips.Spargine.Extensions.CollectionExtensions.AddRange[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.ICollection`1<System.__Canon>, System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 148
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       rdx,rdi
 M02_L02:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF2D0570
-       mov       rdx,7FFAAF2E0570
        mov       rcx,rsi
 M02_L01:
        jmp       short M02_L02
        je        short M02_L01
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdi
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rbp
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rbp,[rax]
+       mov       rax,1AB0ED215C8
-       mov       rax,1C75EBD15C8
        mov       rbx,[rax]
+       mov       rax,1AAFED23020
-       mov       rax,1C73EBD3020
        jne       short M02_L00
        test      eax,eax
        movzx     eax,al
        setne     al
        test      rdi,rdi
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rbx
        push      rbp
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF44A410
-       mov       rdx,7FFAAF4468D8
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1AAFED32190
-       mov       r9,1C73EBE2190
        mov       r8,[r8]
+       mov       r8,1AAFED23020
-       mov       r8,1C73EBD3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF449F40
-       mov       rdx,7FFAAF446408
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 245
        jmp       short M00_L00
        mov       r8,[rax]
+       mov       rax,1AAFED2ED48
-       mov       rax,1C73EBDED48
        call      CORINFO_HELP_CLASSINIT_SHARED_DYNAMICCLASS
        mov       edx,2
+       mov       rcx,7FFAAF0C4000
-       mov       rcx,7FFAAF0D4000
 M00_L02:
        int       3
        call      System.Linq.ThrowHelper.ThrowArgumentNullException(System.Linq.ExceptionArgument)
        mov       ecx,10
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b8394893-d134-41b1-8ec1-31fab6c7da53-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5303dde7-5138-4fbb-8295-a4ce166b6075-diff.temp
index e2e776a..676048c 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5303dde7-5138-4fbb-8295-a4ce166b6075-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b8394893-d134-41b1-8ec1-31fab6c7da53-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3F06B8]
+       mov       r11,7FFAAEE306B8
-       call      qword ptr [7FFAAF3E06B8]
-       mov       r11,7FFAAEE206B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF46CA88
-       mov       rdx,7FFAAF45CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF466430
-       mov       rdx,7FFAAF456430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,188785439C0
-       mov       r9,1A32ED21958
        mov       r8,[r8]
+       mov       r8,18878533020
-       mov       r8,1A34ED23020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF465F60
-       mov       rdx,7FFAAF455F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/72bef15c-91d6-46fc-bba7-cadbf2e1f492-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5c4b62a5-a4cf-4d1d-a987-d86cfbc27e5f-diff.temp
index baec80a..8a1a49e 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5c4b62a5-a4cf-4d1d-a987-d86cfbc27e5f-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/72bef15c-91d6-46fc-bba7-cadbf2e1f492-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3F06B8]
+       mov       r11,7FFAAEE306B8
-       call      qword ptr [7FFAAF3E06B8]
-       mov       r11,7FFAAEE206B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF46CA88
-       mov       rdx,7FFAAF45CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF466430
-       mov       rdx,7FFAAF456430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1EB99422970
-       mov       r9,1A32ED21958
        mov       r8,[r8]
+       mov       r8,1EBB9423020
-       mov       r8,1A34ED23020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF465F60
-       mov       rdx,7FFAAF455F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a82b2bf3-1283-4743-a7ca-5aaddc4f29b2-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/08cfebe0-4930-4873-aaf9-f03db485e5f2-diff.temp
index baec80a..792e544 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/08cfebe0-4930-4873-aaf9-f03db485e5f2-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a82b2bf3-1283-4743-a7ca-5aaddc4f29b2-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3D06B8]
+       mov       r11,7FFAAEE106B8
-       call      qword ptr [7FFAAF3E06B8]
-       mov       r11,7FFAAEE206B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF44CA88
-       mov       rdx,7FFAAF45CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF446430
-       mov       rdx,7FFAAF456430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1B5D7F439C0
-       mov       r9,1A32ED21958
        mov       r8,[r8]
+       mov       r8,1B5D7F33020
-       mov       r8,1A34ED23020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF445F60
-       mov       rdx,7FFAAF455F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/40a802bb-cd0e-4f66-85a1-c3c75a37c6d5-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/02e3b0e3-160f-429d-962c-0c635d2dea99-diff.temp
index baec80a..97b736d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/02e3b0e3-160f-429d-962c-0c635d2dea99-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/40a802bb-cd0e-4f66-85a1-c3c75a37c6d5-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3C06B8]
+       mov       r11,7FFAAEE006B8
-       call      qword ptr [7FFAAF3E06B8]
-       mov       r11,7FFAAEE206B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF43CA88
-       mov       rdx,7FFAAF45CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF436430
-       mov       rdx,7FFAAF456430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,19E93C13188
-       mov       r9,1A32ED21958
        mov       r8,[r8]
+       mov       r8,19E73C13020
-       mov       r8,1A34ED23020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF435F60
-       mov       rdx,7FFAAF455F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1c26888f-d27f-472a-8b6b-2c87c811ea36-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6b61f8f6-708f-41f4-8e23-6f554f3919af-diff.temp
index baec80a..097cc63 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6b61f8f6-708f-41f4-8e23-6f554f3919af-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1c26888f-d27f-472a-8b6b-2c87c811ea36-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3C06B8]
+       mov       r11,7FFAAEE006B8
-       call      qword ptr [7FFAAF3E06B8]
-       mov       r11,7FFAAEE206B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF43CA40
-       mov       rdx,7FFAAF45CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4363E8
-       mov       rdx,7FFAAF456430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,2B7CF012970
-       mov       r9,1A32ED21958
        mov       r8,[r8]
+       mov       r8,2B7EF013020
-       mov       r8,1A34ED23020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF435F18
-       mov       rdx,7FFAAF455F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f7a37388-91f3-414a-840f-1a24ce788d50-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3d7cd639-45e0-43eb-b6cb-391399ea4c8d-diff.temp
index baec80a..4a27768 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3d7cd639-45e0-43eb-b6cb-391399ea4c8d-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f7a37388-91f3-414a-840f-1a24ce788d50-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3F06B8]
+       mov       r11,7FFAAEE306B8
-       call      qword ptr [7FFAAF3E06B8]
-       mov       r11,7FFAAEE206B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF46CFD0
-       mov       rdx,7FFAAF45CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4663E8
-       mov       rdx,7FFAAF456430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,21AC92EA108
-       mov       r9,1A32ED21958
        mov       r8,[r8]
+       mov       r8,21AA92E3020
-       mov       r8,1A34ED23020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF465F18
-       mov       rdx,7FFAAF455F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c9b31ef6-9a8e-453c-81b3-ffea71a95dfa-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/64255651-d686-41ef-8eeb-8958fd252221-diff.temp
index baec80a..764da2c 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/64255651-d686-41ef-8eeb-8958fd252221-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c9b31ef6-9a8e-453c-81b3-ffea71a95dfa-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3C07E0]
+       mov       r11,7FFAAEDF07E0
-       call      qword ptr [7FFAAF3E06B8]
-       mov       r11,7FFAAEE206B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF454FD8
-       mov       rdx,7FFAAF45CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF439F20
-       mov       rdx,7FFAAF456430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,20B27161958
-       mov       r9,1A32ED21958
        mov       r8,[r8]
+       mov       r8,20B47163020
-       mov       r8,1A34ED23020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF439A50
-       mov       rdx,7FFAAF455F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0fd33f5d-d46c-4104-92f7-6b0eeb0ee46f-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/882f9d8e-2743-40bd-b1a4-191ef688d123-diff.temp
index baec80a..aa2a356 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/882f9d8e-2743-40bd-b1a4-191ef688d123-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0fd33f5d-d46c-4104-92f7-6b0eeb0ee46f-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a6d6ece0-84f2-47c9-9eb8-9776c8654155-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/8807ff2d-d392-444e-8d9a-a8ca5e19baa4-diff.temp
index 8a1a49e..792e544 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/8807ff2d-d392-444e-8d9a-a8ca5e19baa4-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a6d6ece0-84f2-47c9-9eb8-9776c8654155-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3D06B8]
+       mov       r11,7FFAAEE106B8
-       call      qword ptr [7FFAAF3F06B8]
-       mov       r11,7FFAAEE306B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF44CA88
-       mov       rdx,7FFAAF46CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF446430
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1B5D7F439C0
-       mov       r9,188785439C0
        mov       r8,[r8]
+       mov       r8,1B5D7F33020
-       mov       r8,18878533020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF445F60
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f3b4d629-ef27-4484-ac54-30ab0aeed144-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0de8ad4d-06d4-4fe8-aa3b-bbab9c048079-diff.temp
index 8a1a49e..97b736d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0de8ad4d-06d4-4fe8-aa3b-bbab9c048079-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f3b4d629-ef27-4484-ac54-30ab0aeed144-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3C06B8]
+       mov       r11,7FFAAEE006B8
-       call      qword ptr [7FFAAF3F06B8]
-       mov       r11,7FFAAEE306B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF43CA88
-       mov       rdx,7FFAAF46CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF436430
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,19E93C13188
-       mov       r9,188785439C0
        mov       r8,[r8]
+       mov       r8,19E73C13020
-       mov       r8,18878533020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF435F60
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0e5eb154-6509-4498-b33f-930273667226-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2b80fdb5-497b-4cd1-b194-158453ccf0cd-diff.temp
index 8a1a49e..097cc63 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2b80fdb5-497b-4cd1-b194-158453ccf0cd-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0e5eb154-6509-4498-b33f-930273667226-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3C06B8]
+       mov       r11,7FFAAEE006B8
-       call      qword ptr [7FFAAF3F06B8]
-       mov       r11,7FFAAEE306B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF43CA40
-       mov       rdx,7FFAAF46CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4363E8
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,2B7CF012970
-       mov       r9,188785439C0
        mov       r8,[r8]
+       mov       r8,2B7EF013020
-       mov       r8,18878533020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF435F18
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/79a487a4-fa74-4928-80b1-d8025c098cd6-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d6d9472d-5acd-4584-b42f-2e02f5d727c5-diff.temp
index 8a1a49e..4a27768 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d6d9472d-5acd-4584-b42f-2e02f5d727c5-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/79a487a4-fa74-4928-80b1-d8025c098cd6-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4663E8
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,21AC92EA108
-       mov       r9,188785439C0
        mov       r8,[r8]
+       mov       r8,21AA92E3020
-       mov       r8,18878533020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF465F18
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/77c84cdc-b231-4483-ab76-19a719e67d96-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a370bae1-b6cd-4600-b474-472ea93b8e21-diff.temp
index 8a1a49e..764da2c 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a370bae1-b6cd-4600-b474-472ea93b8e21-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/77c84cdc-b231-4483-ab76-19a719e67d96-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3C07E0]
+       mov       r11,7FFAAEDF07E0
-       call      qword ptr [7FFAAF3F06B8]
-       mov       r11,7FFAAEE306B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF454FD8
-       mov       rdx,7FFAAF46CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF439F20
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,20B27161958
-       mov       r9,188785439C0
        mov       r8,[r8]
+       mov       r8,20B47163020
-       mov       r8,18878533020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF439A50
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/03e083a9-2fe8-4a9d-8527-44ba5a3ff91b-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7e3fe7e7-330a-4357-b706-fa519a59a463-diff.temp
index 8a1a49e..aa2a356 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7e3fe7e7-330a-4357-b706-fa519a59a463-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/03e083a9-2fe8-4a9d-8527-44ba5a3ff91b-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3D06B8]
+       mov       r11,7FFAAEE106B8
-       call      qword ptr [7FFAAF3F06B8]
-       mov       r11,7FFAAEE306B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF44CA88
-       mov       rdx,7FFAAF46CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF446430
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,1B5D7F439C0
-       mov       r9,1EB99422970
        mov       r8,[r8]
+       mov       r8,1B5D7F33020
-       mov       r8,1EBB9423020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF445F60
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c539ae82-251c-4d3e-b8e6-97da39315b67-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/52c50c77-988e-4f8f-a068-ac9d7b100c5d-diff.temp
index 792e544..97b736d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/52c50c77-988e-4f8f-a068-ac9d7b100c5d-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c539ae82-251c-4d3e-b8e6-97da39315b67-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3C06B8]
+       mov       r11,7FFAAEE006B8
-       call      qword ptr [7FFAAF3F06B8]
-       mov       r11,7FFAAEE306B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF43CA88
-       mov       rdx,7FFAAF46CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF436430
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,19E93C13188
-       mov       r9,1EB99422970
        mov       r8,[r8]
+       mov       r8,19E73C13020
-       mov       r8,1EBB9423020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF435F60
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/cc5ef5a0-dfc8-4498-8aaf-9d031cab0ca2-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0a6241cf-0bf7-4f4f-802f-9bb76aba0356-diff.temp
index 792e544..097cc63 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0a6241cf-0bf7-4f4f-802f-9bb76aba0356-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/cc5ef5a0-dfc8-4498-8aaf-9d031cab0ca2-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3C06B8]
+       mov       r11,7FFAAEE006B8
-       call      qword ptr [7FFAAF3F06B8]
-       mov       r11,7FFAAEE306B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF43CA40
-       mov       rdx,7FFAAF46CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4363E8
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,2B7CF012970
-       mov       r9,1EB99422970
        mov       r8,[r8]
+       mov       r8,2B7EF013020
-       mov       r8,1EBB9423020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF435F18
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d6b0a8a2-1d73-4126-ac11-5e996068e89b-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/20c8432b-b90f-4b5c-a359-4535494f3f76-diff.temp
index 792e544..4a27768 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/20c8432b-b90f-4b5c-a359-4535494f3f76-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d6b0a8a2-1d73-4126-ac11-5e996068e89b-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4663E8
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,21AC92EA108
-       mov       r9,1EB99422970
        mov       r8,[r8]
+       mov       r8,21AA92E3020
-       mov       r8,1EBB9423020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF465F18
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/11fd02a4-72ae-47eb-869b-3868417516cf-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/aa517652-02fc-4395-ba06-30271c019743-diff.temp
index 792e544..764da2c 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/aa517652-02fc-4395-ba06-30271c019743-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/11fd02a4-72ae-47eb-869b-3868417516cf-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3C07E0]
+       mov       r11,7FFAAEDF07E0
-       call      qword ptr [7FFAAF3F06B8]
-       mov       r11,7FFAAEE306B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF454FD8
-       mov       rdx,7FFAAF46CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF439F20
-       mov       rdx,7FFAAF466430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,20B27161958
-       mov       r9,1EB99422970
        mov       r8,[r8]
+       mov       r8,20B47163020
-       mov       r8,1EBB9423020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF439A50
-       mov       rdx,7FFAAF465F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7b0a79c3-33d0-47b8-83f6-a8487e515cfd-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/958b451b-9e3b-4b2f-955f-e4c952949e32-diff.temp
index 792e544..aa2a356 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/958b451b-9e3b-4b2f-955f-e4c952949e32-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7b0a79c3-33d0-47b8-83f6-a8487e515cfd-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3C06B8]
+       mov       r11,7FFAAEE006B8
-       call      qword ptr [7FFAAF3D06B8]
-       mov       r11,7FFAAEE106B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF43CA88
-       mov       rdx,7FFAAF44CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF436430
-       mov       rdx,7FFAAF446430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,19E93C13188
-       mov       r9,1B5D7F439C0
        mov       r8,[r8]
+       mov       r8,19E73C13020
-       mov       r8,1B5D7F33020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF435F60
-       mov       rdx,7FFAAF445F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0cf48195-37f7-4513-8b50-730d4d17aacd-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/983457e4-4ba3-47c8-a0b0-6ea2e9e49cf7-diff.temp
index 97b736d..097cc63 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/983457e4-4ba3-47c8-a0b0-6ea2e9e49cf7-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0cf48195-37f7-4513-8b50-730d4d17aacd-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3C06B8]
+       mov       r11,7FFAAEE006B8
-       call      qword ptr [7FFAAF3D06B8]
-       mov       r11,7FFAAEE106B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF43CA40
-       mov       rdx,7FFAAF44CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4363E8
-       mov       rdx,7FFAAF446430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,2B7CF012970
-       mov       r9,1B5D7F439C0
        mov       r8,[r8]
+       mov       r8,2B7EF013020
-       mov       r8,1B5D7F33020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF435F18
-       mov       rdx,7FFAAF445F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3a73b8bf-8f28-4a0a-8d9e-4e4ea3d8071c-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1717b18f-9161-4181-a73b-04007b116aab-diff.temp
index 97b736d..4a27768 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1717b18f-9161-4181-a73b-04007b116aab-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3a73b8bf-8f28-4a0a-8d9e-4e4ea3d8071c-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3F06B8]
+       mov       r11,7FFAAEE306B8
-       call      qword ptr [7FFAAF3D06B8]
-       mov       r11,7FFAAEE106B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF46CFD0
-       mov       rdx,7FFAAF44CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4663E8
-       mov       rdx,7FFAAF446430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,21AC92EA108
-       mov       r9,1B5D7F439C0
        mov       r8,[r8]
+       mov       r8,21AA92E3020
-       mov       r8,1B5D7F33020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF465F18
-       mov       rdx,7FFAAF445F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9e30d989-d3fe-409a-a476-52b570a2d4fc-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/cda06894-5e21-40d0-a4eb-33547c06649e-diff.temp
index 97b736d..764da2c 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/cda06894-5e21-40d0-a4eb-33547c06649e-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9e30d989-d3fe-409a-a476-52b570a2d4fc-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3C07E0]
+       mov       r11,7FFAAEDF07E0
-       call      qword ptr [7FFAAF3D06B8]
-       mov       r11,7FFAAEE106B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF454FD8
-       mov       rdx,7FFAAF44CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF439F20
-       mov       rdx,7FFAAF446430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,20B27161958
-       mov       r9,1B5D7F439C0
        mov       r8,[r8]
+       mov       r8,20B47163020
-       mov       r8,1B5D7F33020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF439A50
-       mov       rdx,7FFAAF445F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6d351a66-78e6-414c-bff5-bc1d6a5539fa-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0ec94f43-1361-453f-b861-599c94d74393-diff.temp
index 97b736d..aa2a356 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0ec94f43-1361-453f-b861-599c94d74393-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6d351a66-78e6-414c-bff5-bc1d6a5539fa-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4363E8
-       mov       rdx,7FFAAF436430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,2B7CF012970
-       mov       r9,19E93C13188
        mov       r8,[r8]
+       mov       r8,2B7EF013020
-       mov       r8,19E73C13020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF435F18
-       mov       rdx,7FFAAF435F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/88329763-7e86-4c22-9c84-dea16bcea4e8-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4755c2a3-dac3-4c56-b6c6-b305308ef21a-diff.temp
index 097cc63..4a27768 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4755c2a3-dac3-4c56-b6c6-b305308ef21a-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/88329763-7e86-4c22-9c84-dea16bcea4e8-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3F06B8]
+       mov       r11,7FFAAEE306B8
-       call      qword ptr [7FFAAF3C06B8]
-       mov       r11,7FFAAEE006B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF46CFD0
-       mov       rdx,7FFAAF43CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4663E8
-       mov       rdx,7FFAAF436430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,21AC92EA108
-       mov       r9,19E93C13188
        mov       r8,[r8]
+       mov       r8,21AA92E3020
-       mov       r8,19E73C13020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF465F18
-       mov       rdx,7FFAAF435F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/db910d62-f5c1-4318-9024-e2049b1f4da6-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/37baacf3-b15c-4a79-b9e8-15bd69c26b60-diff.temp
index 097cc63..764da2c 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/37baacf3-b15c-4a79-b9e8-15bd69c26b60-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/db910d62-f5c1-4318-9024-e2049b1f4da6-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3C07E0]
+       mov       r11,7FFAAEDF07E0
-       call      qword ptr [7FFAAF3C06B8]
-       mov       r11,7FFAAEE006B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF454FD8
-       mov       rdx,7FFAAF43CA88
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF439F20
-       mov       rdx,7FFAAF436430
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,20B27161958
-       mov       r9,19E93C13188
        mov       r8,[r8]
+       mov       r8,20B47163020
-       mov       r8,19E73C13020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF439A50
-       mov       rdx,7FFAAF435F60
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0e351a03-c4c5-458a-b8c4-bd74ff8b516c-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/11dfacdc-b199-4f19-ade6-7558ccf07d4b-diff.temp
index 097cc63..aa2a356 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/11dfacdc-b199-4f19-ade6-7558ccf07d4b-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0e351a03-c4c5-458a-b8c4-bd74ff8b516c-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3F06B8]
+       mov       r11,7FFAAEE306B8
-       call      qword ptr [7FFAAF3C06B8]
-       mov       r11,7FFAAEE006B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF46CFD0
-       mov       rdx,7FFAAF43CA40
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF4663E8
-       mov       rdx,7FFAAF4363E8
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,21AC92EA108
-       mov       r9,2B7CF012970
        mov       r8,[r8]
+       mov       r8,21AA92E3020
-       mov       r8,2B7EF013020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF465F18
-       mov       rdx,7FFAAF435F18
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0b06a642-e96c-42fa-b5ce-856b217e2be4-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f4e783fb-3832-43ec-86c9-8d4b88a1a7f1-diff.temp
index 4a27768..764da2c 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f4e783fb-3832-43ec-86c9-8d4b88a1a7f1-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0b06a642-e96c-42fa-b5ce-856b217e2be4-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3C07E0]
+       mov       r11,7FFAAEDF07E0
-       call      qword ptr [7FFAAF3C06B8]
-       mov       r11,7FFAAEE006B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF454FD8
-       mov       rdx,7FFAAF43CA40
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF439F20
-       mov       rdx,7FFAAF4363E8
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,20B27161958
-       mov       r9,2B7CF012970
        mov       r8,[r8]
+       mov       r8,20B47163020
-       mov       r8,2B7EF013020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF439A50
-       mov       rdx,7FFAAF435F18
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/13bc82e9-ac36-4b48-886f-1dfa4c4f1051-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4652be5d-d34f-4c29-b87d-82dafb425bc7-diff.temp
index 4a27768..aa2a356 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4652be5d-d34f-4c29-b87d-82dafb425bc7-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/13bc82e9-ac36-4b48-886f-1dfa4c4f1051-diff.temp
```
**Diff for HasItems01 method between:**
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
.NET 6.0.5 (6.0.522.21309), X64 RyuJIT
```diff
jmp       short M02_L02
        jo        short M02_L03
        add       rdi,1
        je        short M02_L04
        test      eax,eax
+       call      qword ptr [7FFAAF3C07E0]
+       mov       r11,7FFAAEDF07E0
-       call      qword ptr [7FFAAF3F06B8]
-       mov       r11,7FFAAEE306B8
        mov       rcx,rsi
 M02_L02:
        mov       [rbp+0FFE0],rsi
        mov       rsi,rax
        call      qword ptr [r11]
        mov       rcx,rsi
 M02_L01:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF454FD8
-       mov       rdx,7FFAAF46CFD0
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      r11,r11
        mov       r11,[rdx+18]
        mov       rdx,[rcx+10]
        xor       edi,edi
        je        short M02_L05
        test      rsi,rsi
        mov       rsi,rdx
        mov       [rbp+0FFE8],rcx
        mov       [rbp+0FFD0],rsp
        lea       rbp,[rsp+50]
        sub       rsp,40
        push      rsi
        push      rdi
        push      rbp
 ; System.Linq.Enumerable.LongCount[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>)
 ; Total bytes of code 138
        jmp       near ptr DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>)
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,30
        mov       rdx,rdi
 M01_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF439F20
-       mov       rdx,7FFAAF4663E8
        mov       rcx,rsi
 M01_L02:
        jmp       short M01_L03
        je        short M01_L02
        test      rcx,rcx
        mov       rcx,[rbx+18]
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentItemsExists[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>, System.String, System.String)
        mov       rdx,rdi
        mov       r9,[r9]
+       mov       r9,20B27161958
-       mov       r9,21AC92EA108
        mov       r8,[r8]
+       mov       r8,20B47163020
-       mov       r8,21AA92E3020
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFAAF439A50
-       mov       rdx,7FFAAF465F18
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rbx+10]
        mov       rbx,[rsi+10]
        mov       rdi,rdx
        mov       rsi,rcx
        mov       [rsp+28],rcx
        sub       rsp,30
        push      rbx
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ListExtensions.ToCollection[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IList`1<System.__Canon>)
 ; Total bytes of code 84
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       [rax+54],dil
        mov       rax,[rsi+20]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/8b7902d9-00ae-40d6-a6da-dd4ddf69df91-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/dd2f96c1-f791-4caf-b365-8d72c28bb3e0-diff.temp
index 764da2c..aa2a356 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/dd2f96c1-f791-4caf-b365-8d72c28bb3e0-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/8b7902d9-00ae-40d6-a6da-dd4ddf69df91-diff.temp
```
