## DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark-20220802-072423
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,22659C29B48
-       mov       rcx,2934A569B48
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e96de805-6d25-4529-8c35-0e5fe751ba8a-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d4770c80-d2a9-4d04-ae13-235502af8ae6-diff.temp
index 772b825..ac04205 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d4770c80-d2a9-4d04-ae13-235502af8ae6-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e96de805-6d25-4529-8c35-0e5fe751ba8a-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,2663F211768
-       mov       rcx,2934A569B48
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c008bac9-5c6a-4838-b839-9a242f789cf2-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0debc53e-a0c5-4830-83df-48dd36ef43f3-diff.temp
index 772b825..0325522 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0debc53e-a0c5-4830-83df-48dd36ef43f3-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c008bac9-5c6a-4838-b839-9a242f789cf2-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/504648ae-8fd1-413c-bee2-8d20ab3a40eb-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/36b789a7-9df6-4abf-961d-839168fb53bf-diff.temp
index 772b825..601261f 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/36b789a7-9df6-4abf-961d-839168fb53bf-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/504648ae-8fd1-413c-bee2-8d20ab3a40eb-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,27177589B48
-       mov       rcx,2934A569B48
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3fafbb88-0e0f-44d1-b26b-85a87ad9122e-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7e792afd-ded8-47de-b809-f3301f859898-diff.temp
index 772b825..daaef5a 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7e792afd-ded8-47de-b809-f3301f859898-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3fafbb88-0e0f-44d1-b26b-85a87ad9122e-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/75efdd49-39f2-494b-b598-9dea99a26e54-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/46d01462-a1ee-4ada-9034-a9664004e2b7-diff.temp
index 772b825..f01b0fd 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/46d01462-a1ee-4ada-9034-a9664004e2b7-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/75efdd49-39f2-494b-b598-9dea99a26e54-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,1C78B4C7B50
-       mov       rcx,2934A569B48
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7a425b62-fbcb-4eff-ab19-07e4c4498bc5-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5a887193-f45a-4314-9909-136124ffd9be-diff.temp
index 772b825..3cc0c64 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5a887193-f45a-4314-9909-136124ffd9be-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7a425b62-fbcb-4eff-ab19-07e4c4498bc5-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e699d44e-1f72-45d5-96e4-edda14886df7-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/439b927a-a578-49bb-8868-3f8208fe9c39-diff.temp
index 772b825..581d3d1 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/439b927a-a578-49bb-8868-3f8208fe9c39-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e699d44e-1f72-45d5-96e4-edda14886df7-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2e776886-77f5-4d0a-8f08-df2aff3740eb-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/edb4aaf7-42e4-40dc-89f0-fc68ac453527-diff.temp
index ac04205..0325522 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/edb4aaf7-42e4-40dc-89f0-fc68ac453527-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2e776886-77f5-4d0a-8f08-df2aff3740eb-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,21EAE147B50
-       mov       rcx,22659C29B48
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d3b3a45e-919d-4f38-8641-bdb6afd4bea5-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/19e73fc4-15fb-4248-8597-179b2874e35b-diff.temp
index ac04205..601261f 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/19e73fc4-15fb-4248-8597-179b2874e35b-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d3b3a45e-919d-4f38-8641-bdb6afd4bea5-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7a03359f-8681-4567-b545-712961df6a94-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9105137c-5adc-4a8b-9ecf-1a4e5d3c1ab3-diff.temp
index ac04205..daaef5a 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9105137c-5adc-4a8b-9ecf-1a4e5d3c1ab3-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7a03359f-8681-4567-b545-712961df6a94-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,1CD7A3D9B48
-       mov       rcx,22659C29B48
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/50f36eab-fed7-4d03-a4d5-03f3dbad38a4-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b2552cef-120c-4335-9ff9-33f79c998408-diff.temp
index ac04205..f01b0fd 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b2552cef-120c-4335-9ff9-33f79c998408-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/50f36eab-fed7-4d03-a4d5-03f3dbad38a4-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,1C78B4C7B50
-       mov       rcx,22659C29B48
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d1eb4836-11b2-4613-a5e0-efa3f7cf8c40-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/305b4b65-76fb-48bb-b3e0-0a81b8930bfc-diff.temp
index ac04205..3cc0c64 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/305b4b65-76fb-48bb-b3e0-0a81b8930bfc-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d1eb4836-11b2-4613-a5e0-efa3f7cf8c40-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,20CBC4B9B48
-       mov       rcx,22659C29B48
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f0022b2f-3b09-45e7-8186-424ef414ca06-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/441112f0-e470-4f08-aeaf-e839f9c8554b-diff.temp
index ac04205..581d3d1 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/441112f0-e470-4f08-aeaf-e839f9c8554b-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f0022b2f-3b09-45e7-8186-424ef414ca06-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,21EAE147B50
-       mov       rcx,2663F211768
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c0fb174f-f364-457c-9a51-2b84cf82f85e-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b8cf9de4-bfa2-484f-94ac-83dd448f0f6f-diff.temp
index 0325522..601261f 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b8cf9de4-bfa2-484f-94ac-83dd448f0f6f-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c0fb174f-f364-457c-9a51-2b84cf82f85e-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2b3d73f8-df7d-4dfc-bef3-d02fd704e905-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/80494bca-44c8-4db8-8469-1809dd7710ea-diff.temp
index 0325522..daaef5a 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/80494bca-44c8-4db8-8469-1809dd7710ea-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2b3d73f8-df7d-4dfc-bef3-d02fd704e905-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,1CD7A3D9B48
-       mov       rcx,2663F211768
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/093777fe-0d20-4631-8814-50de183141c2-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/191d7b5b-252c-45d4-b543-d6a36583621b-diff.temp
index 0325522..f01b0fd 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/191d7b5b-252c-45d4-b543-d6a36583621b-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/093777fe-0d20-4631-8814-50de183141c2-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,1C78B4C7B50
-       mov       rcx,2663F211768
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e499de5a-5ea6-4bb7-b5aa-e979ec42ad47-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c583ce81-8e77-4616-b50f-2fee1e78b6f7-diff.temp
index 0325522..3cc0c64 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c583ce81-8e77-4616-b50f-2fee1e78b6f7-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e499de5a-5ea6-4bb7-b5aa-e979ec42ad47-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,20CBC4B9B48
-       mov       rcx,2663F211768
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9f978cf7-7669-4238-93f1-439031ac2060-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1d57658b-0b05-4147-8a93-9c392f296fe9-diff.temp
index 0325522..581d3d1 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1d57658b-0b05-4147-8a93-9c392f296fe9-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9f978cf7-7669-4238-93f1-439031ac2060-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,27177589B48
-       mov       rcx,21EAE147B50
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b0041e48-109b-44ce-b6a8-ce9a1861bfd2-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/251247eb-29c2-4988-8f4e-debaf52be143-diff.temp
index 601261f..daaef5a 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/251247eb-29c2-4988-8f4e-debaf52be143-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b0041e48-109b-44ce-b6a8-ce9a1861bfd2-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1947cde5-dc5c-4493-8749-24ed8a8d27b3-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b28b1dcb-ce6f-4db9-b0ef-1cc04f4a3c41-diff.temp
index 601261f..f01b0fd 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b28b1dcb-ce6f-4db9-b0ef-1cc04f4a3c41-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1947cde5-dc5c-4493-8749-24ed8a8d27b3-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,1C78B4C7B50
-       mov       rcx,21EAE147B50
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5f9d8746-db34-4aa7-9ba0-beb9a1ff02d4-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/21db4aab-8ca6-4914-96e7-150f25da69fd-diff.temp
index 601261f..3cc0c64 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/21db4aab-8ca6-4914-96e7-150f25da69fd-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5f9d8746-db34-4aa7-9ba0-beb9a1ff02d4-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f07e10a8-8e2d-49f3-8f02-543a413d1288-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1e464a0a-c14a-4762-9426-7a86498469e8-diff.temp
index 601261f..581d3d1 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1e464a0a-c14a-4762-9426-7a86498469e8-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f07e10a8-8e2d-49f3-8f02-543a413d1288-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,1CD7A3D9B48
-       mov       rcx,27177589B48
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/587b487e-7583-467b-803d-734cd7b448ef-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e8588c86-04a1-4e08-b874-6310c3b58132-diff.temp
index daaef5a..f01b0fd 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e8588c86-04a1-4e08-b874-6310c3b58132-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/587b487e-7583-467b-803d-734cd7b448ef-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,1C78B4C7B50
-       mov       rcx,27177589B48
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/43ec3596-5a92-4f32-9048-52d65c49e359-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7b9cb684-4f4c-4e1e-ba19-3619eebbc3fa-diff.temp
index daaef5a..3cc0c64 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7b9cb684-4f4c-4e1e-ba19-3619eebbc3fa-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/43ec3596-5a92-4f32-9048-52d65c49e359-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,20CBC4B9B48
-       mov       rcx,27177589B48
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6cc9c528-a2b7-425c-88d8-c191071cd0e3-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/fed40f2d-b343-429d-a5c9-0b0940745307-diff.temp
index daaef5a..581d3d1 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/fed40f2d-b343-429d-a5c9-0b0940745307-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6cc9c528-a2b7-425c-88d8-c191071cd0e3-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,1C78B4C7B50
-       mov       rcx,1CD7A3D9B48
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/fe1cfc8c-1192-4c3c-9a0d-8c741d392462-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/86f89069-0c91-4b47-8bef-9b8ca247dd00-diff.temp
index f01b0fd..3cc0c64 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/86f89069-0c91-4b47-8bef-9b8ca247dd00-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/fe1cfc8c-1192-4c3c-9a0d-8c741d392462-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/aea73f20-f86f-4e25-945d-2e32e94e09c3-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/23f2b99e-312c-447a-b6e5-607848b3c9d9-diff.temp
index f01b0fd..581d3d1 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/23f2b99e-312c-447a-b6e5-607848b3c9d9-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/aea73f20-f86f-4e25-945d-2e32e94e09c3-diff.temp
```
**Diff for CollectionCreate01 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L03:
        jmp       near ptr M01_L07
        mov       rcx,[rcx]
+       mov       rcx,20CBC4B9B48
-       mov       rcx,1C78B4C7B50
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorNumberIsInvalidBasedOnTheMinMaxValue()
        jne       near ptr M01_L06
        test      edx,edx
 M01_L02:
        jmp       near ptr M01_L06
        mov       esi,1
        jne       short M01_L02
        test      eax,eax
        mov       edx,eax
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/15677d40-c3d5-474e-a52f-52b23e848ae6-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9c6a1967-d9f6-4e1c-a83d-0a49a94b6aa0-diff.temp
index 3cc0c64..581d3d1 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9c6a1967-d9f6-4e1c-a83d-0a49a94b6aa0-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/15677d40-c3d5-474e-a52f-52b23e848ae6-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B478E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B478E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B478E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,2685F531B88
-       mov       rax,20FB9BA1B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B478E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B478E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B478E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,2683F533090
-       mov       rdx,20F99BA3090
        mov       rcx,[rcx]
+       mov       rcx,2685F531688
-       mov       rcx,20FB9BA1688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E507D0]
+       mov       r11,7FFB528807D0
-       call      qword ptr [7FFB52E307D0]
-       mov       r11,7FFB528607D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E507C8]
+       mov       r11,7FFB528807C8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52ECC890
-       mov       rdx,7FFB52EAC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E507C8]
+       mov       r11,7FFB528807C8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52ECC860
-       mov       rdx,7FFB52EAC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52ECC840
-       mov       rdx,7FFB52EAC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52ECC800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52ECCAA0
-       mov       rdx,7FFB52EACAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52ECC800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52ECC800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C8E7E0
-       mov       rdx,7FFB52C6E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C8E7E0
-       mov       rdx,7FFB52C6E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CF33C0
-       mov       rdx,7FFB52CD33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/da5f890a-2147-4d93-a576-64b0126804a1-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/bd7107db-4e51-44b1-bf0a-d9a1d26a8e5d-diff.temp
index 1277a79..4ddf82c 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/bd7107db-4e51-44b1-bf0a-d9a1d26a8e5d-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/da5f890a-2147-4d93-a576-64b0126804a1-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,19E6FE58F88
-       mov       rax,20FB9BA1B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,19E6FE51098
-       mov       rdx,20F99BA3090
        mov       rcx,[rcx]
+       mov       rcx,19E6FE58A88
-       mov       rcx,20FB9BA1688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E407D0]
+       mov       r11,7FFB528707D0
-       call      qword ptr [7FFB52E307D0]
-       mov       r11,7FFB528607D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E407C8]
+       mov       r11,7FFB528707C8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC890
-       mov       rdx,7FFB52EAC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E407C8]
+       mov       r11,7FFB528707C8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC860
-       mov       rdx,7FFB52EAC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC840
-       mov       rdx,7FFB52EAC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBCAA0
-       mov       rdx,7FFB52EACAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C7E7E0
-       mov       rdx,7FFB52C6E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C7E7E0
-       mov       rdx,7FFB52C6E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CE33C0
-       mov       rdx,7FFB52CD33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a8613957-6ac2-4d80-90f6-a69751b07d48-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4320c06c-bd60-414d-ba05-11bcd0157e50-diff.temp
index 1277a79..7e5aef6 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4320c06c-bd60-414d-ba05-11bcd0157e50-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a8613957-6ac2-4d80-90f6-a69751b07d48-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,2324E46B798
-       mov       rax,20FB9BA1B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,2324E463090
-       mov       rdx,20F99BA3090
        mov       rcx,[rcx]
+       mov       rcx,2324E46B298
-       mov       rcx,20FB9BA1688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E407D0]
+       mov       r11,7FFB528707D0
-       call      qword ptr [7FFB52E307D0]
-       mov       r11,7FFB528607D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E407C8]
+       mov       r11,7FFB528707C8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC890
-       mov       rdx,7FFB52EAC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E407C8]
+       mov       r11,7FFB528707C8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC860
-       mov       rdx,7FFB52EAC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC840
-       mov       rdx,7FFB52EAC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBCAA0
-       mov       rdx,7FFB52EACAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C7E7E0
-       mov       rdx,7FFB52C6E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C7E7E0
-       mov       rdx,7FFB52C6E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CE33C0
-       mov       rdx,7FFB52CD33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/764e18b7-2e94-46b6-b6c4-7b1025c06a56-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ccb53fd0-d571-4124-ac8f-4bffb3c99fd2-diff.temp
index 1277a79..2e3095c 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ccb53fd0-d571-4124-ac8f-4bffb3c99fd2-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/764e18b7-2e94-46b6-b6c4-7b1025c06a56-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,2B715831B88
-       mov       rax,20FB9BA1B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,2B725833090
-       mov       rdx,20F99BA3090
        mov       rcx,[rcx]
+       mov       rcx,2B715831688
-       mov       rcx,20FB9BA1688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E407D0]
+       mov       r11,7FFB528707D0
-       call      qword ptr [7FFB52E307D0]
-       mov       r11,7FFB528607D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E407C8]
+       mov       r11,7FFB528707C8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC890
-       mov       rdx,7FFB52EAC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E407C8]
+       mov       r11,7FFB528707C8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC860
-       mov       rdx,7FFB52EAC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC840
-       mov       rdx,7FFB52EAC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBCAA0
-       mov       rdx,7FFB52EACAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C7E7E0
-       mov       rdx,7FFB52C6E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C7E7E0
-       mov       rdx,7FFB52C6E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CE33C0
-       mov       rdx,7FFB52CD33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d04e5294-665b-4da9-910c-66f8f3441274-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3da8f178-abf3-4a1f-b355-bc3cc208116b-diff.temp
index 1277a79..1715111 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3da8f178-abf3-4a1f-b355-bc3cc208116b-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d04e5294-665b-4da9-910c-66f8f3441274-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,2234BDC3090
-       mov       rdx,20F99BA3090
        mov       rcx,[rcx]
+       mov       rcx,2235BDC26A0
-       mov       rcx,20FB9BA1688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
        call      qword ptr [7FFB52E307D0]
        mov       r11,7FFB528607D0
        mov       rcx,rbx
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5170190f-2b28-4ac8-abd4-ac10da0949de-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7cde905e-a87d-466a-ab49-771ebda96a26-diff.temp
index 1277a79..5580b59 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7cde905e-a87d-466a-ab49-771ebda96a26-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5170190f-2b28-4ac8-abd4-ac10da0949de-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,1DE33341B88
-       mov       rax,20FB9BA1B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,1DE43343090
-       mov       rdx,20F99BA3090
        mov       rcx,[rcx]
+       mov       rcx,1DE33341688
-       mov       rcx,20FB9BA1688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E307D0]
-       mov       r11,7FFB528607D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52EAC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5E8
-       mov       rdx,7FFB52EAC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5C8
-       mov       rdx,7FFB52EAC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC828
-       mov       rdx,7FFB52EACAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
        mov       rdx,7FFB52C6E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
        mov       rdx,7FFB52C6E7E0
        mov       ecx,4D
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CD33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/58e18b0a-e190-4412-8e01-18817abfa56c-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/628ab4c6-8b93-4d9a-ba9e-0da1d8a3840b-diff.temp
index 1277a79..3f5b312 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/628ab4c6-8b93-4d9a-ba9e-0da1d8a3840b-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/58e18b0a-e190-4412-8e01-18817abfa56c-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,1F426271B88
-       mov       rax,20FB9BA1B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,1F436273090
-       mov       rdx,20F99BA3090
        mov       rcx,[rcx]
+       mov       rcx,1F426271688
-       mov       rcx,20FB9BA1688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E307D0]
-       mov       r11,7FFB528607D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC648
-       mov       rdx,7FFB52EAC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52EAC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5F8
-       mov       rdx,7FFB52EAC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC858
-       mov       rdx,7FFB52EACAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
        mov       rdx,7FFB52C6E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
        mov       rdx,7FFB52C6E7E0
        mov       ecx,4D
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CD33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/fe606b6a-a060-4c4d-8fe9-fc782f81a1ba-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/da336a4c-a527-4f6f-bffd-d499e6a2b12b-diff.temp
index 1277a79..c901bc9 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/da336a4c-a527-4f6f-bffd-d499e6a2b12b-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/fe606b6a-a060-4c4d-8fe9-fc782f81a1ba-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,19E6FE58F88
-       mov       rax,2685F531B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,19E6FE51098
-       mov       rdx,2683F533090
        mov       rcx,[rcx]
+       mov       rcx,19E6FE58A88
-       mov       rcx,2685F531688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E407D0]
+       mov       r11,7FFB528707D0
-       call      qword ptr [7FFB52E507D0]
-       mov       r11,7FFB528807D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E407C8]
+       mov       r11,7FFB528707C8
-       call      qword ptr [7FFB52E507C8]
-       mov       r11,7FFB528807C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC890
-       mov       rdx,7FFB52ECC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E407C8]
+       mov       r11,7FFB528707C8
-       call      qword ptr [7FFB52E507C8]
-       mov       r11,7FFB528807C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC860
-       mov       rdx,7FFB52ECC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC840
-       mov       rdx,7FFB52ECC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC800
-       mov       rdx,7FFB52ECC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBCAA0
-       mov       rdx,7FFB52ECCAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC800
-       mov       rdx,7FFB52ECC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC800
-       mov       rdx,7FFB52ECC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C7E7E0
-       mov       rdx,7FFB52C8E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C7E7E0
-       mov       rdx,7FFB52C8E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CE33C0
-       mov       rdx,7FFB52CF33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c24ec67e-5ee9-4806-b555-ff630b991787-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1eca6b96-3672-4e13-a3aa-bb447c04bfb4-diff.temp
index 4ddf82c..7e5aef6 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1eca6b96-3672-4e13-a3aa-bb447c04bfb4-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c24ec67e-5ee9-4806-b555-ff630b991787-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,2324E46B798
-       mov       rax,2685F531B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,2324E463090
-       mov       rdx,2683F533090
        mov       rcx,[rcx]
+       mov       rcx,2324E46B298
-       mov       rcx,2685F531688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E407D0]
+       mov       r11,7FFB528707D0
-       call      qword ptr [7FFB52E507D0]
-       mov       r11,7FFB528807D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E407C8]
+       mov       r11,7FFB528707C8
-       call      qword ptr [7FFB52E507C8]
-       mov       r11,7FFB528807C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC890
-       mov       rdx,7FFB52ECC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E407C8]
+       mov       r11,7FFB528707C8
-       call      qword ptr [7FFB52E507C8]
-       mov       r11,7FFB528807C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC860
-       mov       rdx,7FFB52ECC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC840
-       mov       rdx,7FFB52ECC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC800
-       mov       rdx,7FFB52ECC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBCAA0
-       mov       rdx,7FFB52ECCAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC800
-       mov       rdx,7FFB52ECC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC800
-       mov       rdx,7FFB52ECC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C7E7E0
-       mov       rdx,7FFB52C8E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C7E7E0
-       mov       rdx,7FFB52C8E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CE33C0
-       mov       rdx,7FFB52CF33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/42cfd4ad-da8f-44a6-b531-b7d287f39ddb-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/09acb9bf-92d0-4ccf-a41f-a744b7119186-diff.temp
index 4ddf82c..2e3095c 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/09acb9bf-92d0-4ccf-a41f-a744b7119186-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/42cfd4ad-da8f-44a6-b531-b7d287f39ddb-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,2B715831B88
-       mov       rax,2685F531B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B378E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,2B725833090
-       mov       rdx,2683F533090
        mov       rcx,[rcx]
+       mov       rcx,2B715831688
-       mov       rcx,2685F531688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E407D0]
+       mov       r11,7FFB528707D0
-       call      qword ptr [7FFB52E507D0]
-       mov       r11,7FFB528807D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E407C8]
+       mov       r11,7FFB528707C8
-       call      qword ptr [7FFB52E507C8]
-       mov       r11,7FFB528807C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC890
-       mov       rdx,7FFB52ECC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E407C8]
+       mov       r11,7FFB528707C8
-       call      qword ptr [7FFB52E507C8]
-       mov       r11,7FFB528807C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC860
-       mov       rdx,7FFB52ECC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC840
-       mov       rdx,7FFB52ECC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC800
-       mov       rdx,7FFB52ECC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBCAA0
-       mov       rdx,7FFB52ECCAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC800
-       mov       rdx,7FFB52ECC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC800
-       mov       rdx,7FFB52ECC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C7E7E0
-       mov       rdx,7FFB52C8E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C7E7E0
-       mov       rdx,7FFB52C8E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CE33C0
-       mov       rdx,7FFB52CF33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4c0e756b-c8e1-4033-bb07-4c480f090241-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a35d8cad-bc34-4079-86af-b23340e59525-diff.temp
index 4ddf82c..1715111 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a35d8cad-bc34-4079-86af-b23340e59525-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4c0e756b-c8e1-4033-bb07-4c480f090241-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,2235BDC2BA0
-       mov       rax,2685F531B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,2234BDC3090
-       mov       rdx,2683F533090
        mov       rcx,[rcx]
+       mov       rcx,2235BDC26A0
-       mov       rcx,2685F531688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307D0]
+       mov       r11,7FFB528607D0
-       call      qword ptr [7FFB52E507D0]
-       mov       r11,7FFB528807D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307C8]
+       mov       r11,7FFB528607C8
-       call      qword ptr [7FFB52E507C8]
-       mov       r11,7FFB528807C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC890
-       mov       rdx,7FFB52ECC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307C8]
+       mov       r11,7FFB528607C8
-       call      qword ptr [7FFB52E507C8]
-       mov       r11,7FFB528807C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC860
-       mov       rdx,7FFB52ECC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC840
-       mov       rdx,7FFB52ECC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC800
-       mov       rdx,7FFB52ECC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EACAA0
-       mov       rdx,7FFB52ECCAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC800
-       mov       rdx,7FFB52ECC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC800
-       mov       rdx,7FFB52ECC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C8E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C8E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CD33C0
-       mov       rdx,7FFB52CF33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e5dfc2ea-5f4f-4705-84e1-bd2a1ccce6b8-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/82379de7-78fb-4ad8-8298-1d84b60d582d-diff.temp
index 4ddf82c..5580b59 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/82379de7-78fb-4ad8-8298-1d84b60d582d-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e5dfc2ea-5f4f-4705-84e1-bd2a1ccce6b8-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,1DE33341B88
-       mov       rax,2685F531B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,1DE43343090
-       mov       rdx,2683F533090
        mov       rcx,[rcx]
+       mov       rcx,1DE33341688
-       mov       rcx,2685F531688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E507D0]
-       mov       r11,7FFB528807D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E507C8]
-       mov       r11,7FFB528807C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52ECC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E507C8]
-       mov       r11,7FFB528807C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5E8
-       mov       rdx,7FFB52ECC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5C8
-       mov       rdx,7FFB52ECC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52ECC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC828
-       mov       rdx,7FFB52ECCAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52ECC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52ECC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C8E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C8E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CF33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/13d7c07e-4dcf-40f3-9fcc-e5ed9d4ac1c2-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/fbe06107-ce30-47e8-9e99-d974ef968d06-diff.temp
index 4ddf82c..3f5b312 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/fbe06107-ce30-47e8-9e99-d974ef968d06-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/13d7c07e-4dcf-40f3-9fcc-e5ed9d4ac1c2-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,1F426271B88
-       mov       rax,2685F531B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B478E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,1F436273090
-       mov       rdx,2683F533090
        mov       rcx,[rcx]
+       mov       rcx,1F426271688
-       mov       rcx,2685F531688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E507D0]
-       mov       r11,7FFB528807D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E507C8]
-       mov       r11,7FFB528807C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC648
-       mov       rdx,7FFB52ECC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E507C8]
-       mov       r11,7FFB528807C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52ECC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5F8
-       mov       rdx,7FFB52ECC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52ECC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC858
-       mov       rdx,7FFB52ECCAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52ECC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52ECC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C8E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C8E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CF33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c5811b54-0305-4354-ab8c-26656b0adac6-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/59773857-8f24-46d0-a510-bd34d7d2b410-diff.temp
index 4ddf82c..c901bc9 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/59773857-8f24-46d0-a510-bd34d7d2b410-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c5811b54-0305-4354-ab8c-26656b0adac6-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,2324E463090
-       mov       rdx,19E6FE51098
        mov       rcx,[rcx]
+       mov       rcx,2324E46B298
-       mov       rcx,19E6FE58A88
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
        call      qword ptr [7FFB52E407D0]
        mov       r11,7FFB528707D0
        mov       rcx,rbx
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/219bff18-6a4b-4943-9d9a-b120c4f97823-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/359731c7-c437-4c70-a970-61580477309c-diff.temp
index 7e5aef6..2e3095c 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/359731c7-c437-4c70-a970-61580477309c-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/219bff18-6a4b-4943-9d9a-b120c4f97823-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,2B725833090
-       mov       rdx,19E6FE51098
        mov       rcx,[rcx]
+       mov       rcx,2B715831688
-       mov       rcx,19E6FE58A88
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
        call      qword ptr [7FFB52E407D0]
        mov       r11,7FFB528707D0
        mov       rcx,rbx
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4226e650-0adf-4593-a980-07e6a8576404-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5031d306-c740-49e8-9453-0dd729f1e137-diff.temp
index 7e5aef6..1715111 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5031d306-c740-49e8-9453-0dd729f1e137-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4226e650-0adf-4593-a980-07e6a8576404-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,2235BDC2BA0
-       mov       rax,19E6FE58F88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,2234BDC3090
-       mov       rdx,19E6FE51098
        mov       rcx,[rcx]
+       mov       rcx,2235BDC26A0
-       mov       rcx,19E6FE58A88
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307D0]
+       mov       r11,7FFB528607D0
-       call      qword ptr [7FFB52E407D0]
-       mov       r11,7FFB528707D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307C8]
+       mov       r11,7FFB528607C8
-       call      qword ptr [7FFB52E407C8]
-       mov       r11,7FFB528707C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC890
-       mov       rdx,7FFB52EBC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307C8]
+       mov       r11,7FFB528607C8
-       call      qword ptr [7FFB52E407C8]
-       mov       r11,7FFB528707C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC860
-       mov       rdx,7FFB52EBC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC840
-       mov       rdx,7FFB52EBC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC800
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EACAA0
-       mov       rdx,7FFB52EBCAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC800
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC800
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C7E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C7E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CD33C0
-       mov       rdx,7FFB52CE33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2aeb06d1-ddc0-42e2-ae0c-361e6d82b18b-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/19c2f487-b21f-473d-acdc-ca55804da8ab-diff.temp
index 7e5aef6..5580b59 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/19c2f487-b21f-473d-acdc-ca55804da8ab-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2aeb06d1-ddc0-42e2-ae0c-361e6d82b18b-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,1DE33341B88
-       mov       rax,19E6FE58F88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,1DE43343090
-       mov       rdx,19E6FE51098
        mov       rcx,[rcx]
+       mov       rcx,1DE33341688
-       mov       rcx,19E6FE58A88
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E407D0]
-       mov       r11,7FFB528707D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E407C8]
-       mov       r11,7FFB528707C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52EBC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E407C8]
-       mov       r11,7FFB528707C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5E8
-       mov       rdx,7FFB52EBC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5C8
-       mov       rdx,7FFB52EBC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC828
-       mov       rdx,7FFB52EBCAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C7E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C7E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CE33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/32c7ce80-4bab-48f0-9aa1-08d9849e1d85-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7a71c553-5d0e-4d7f-a05e-0f38a1fa73b8-diff.temp
index 7e5aef6..3f5b312 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7a71c553-5d0e-4d7f-a05e-0f38a1fa73b8-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/32c7ce80-4bab-48f0-9aa1-08d9849e1d85-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,1F426271B88
-       mov       rax,19E6FE58F88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,1F436273090
-       mov       rdx,19E6FE51098
        mov       rcx,[rcx]
+       mov       rcx,1F426271688
-       mov       rcx,19E6FE58A88
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E407D0]
-       mov       r11,7FFB528707D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E407C8]
-       mov       r11,7FFB528707C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC648
-       mov       rdx,7FFB52EBC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E407C8]
-       mov       r11,7FFB528707C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52EBC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5F8
-       mov       rdx,7FFB52EBC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC858
-       mov       rdx,7FFB52EBCAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C7E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C7E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CE33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c31da866-22fa-4440-9ce2-4440cfcc1d24-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b13014db-28ad-4d14-bbeb-8794c3dba431-diff.temp
index 7e5aef6..c901bc9 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b13014db-28ad-4d14-bbeb-8794c3dba431-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c31da866-22fa-4440-9ce2-4440cfcc1d24-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,2B725833090
-       mov       rdx,2324E463090
        mov       rcx,[rcx]
+       mov       rcx,2B715831688
-       mov       rcx,2324E46B298
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
        call      qword ptr [7FFB52E407D0]
        mov       r11,7FFB528707D0
        mov       rcx,rbx
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b62a280e-69ff-462a-8f21-09ea176d30a5-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/69a4868c-89cd-4f6b-9186-c84ea94427c0-diff.temp
index 2e3095c..1715111 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/69a4868c-89cd-4f6b-9186-c84ea94427c0-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b62a280e-69ff-462a-8f21-09ea176d30a5-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,2235BDC2BA0
-       mov       rax,2324E46B798
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,2234BDC3090
-       mov       rdx,2324E463090
        mov       rcx,[rcx]
+       mov       rcx,2235BDC26A0
-       mov       rcx,2324E46B298
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307D0]
+       mov       r11,7FFB528607D0
-       call      qword ptr [7FFB52E407D0]
-       mov       r11,7FFB528707D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307C8]
+       mov       r11,7FFB528607C8
-       call      qword ptr [7FFB52E407C8]
-       mov       r11,7FFB528707C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC890
-       mov       rdx,7FFB52EBC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307C8]
+       mov       r11,7FFB528607C8
-       call      qword ptr [7FFB52E407C8]
-       mov       r11,7FFB528707C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC860
-       mov       rdx,7FFB52EBC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC840
-       mov       rdx,7FFB52EBC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC800
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EACAA0
-       mov       rdx,7FFB52EBCAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC800
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC800
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C7E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C7E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CD33C0
-       mov       rdx,7FFB52CE33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/89e84365-3074-4239-aff3-1877bad70f47-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/00fba0af-94bb-4285-bac2-60aa456d18c9-diff.temp
index 2e3095c..5580b59 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/00fba0af-94bb-4285-bac2-60aa456d18c9-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/89e84365-3074-4239-aff3-1877bad70f47-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,1DE33341B88
-       mov       rax,2324E46B798
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,1DE43343090
-       mov       rdx,2324E463090
        mov       rcx,[rcx]
+       mov       rcx,1DE33341688
-       mov       rcx,2324E46B298
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E407D0]
-       mov       r11,7FFB528707D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E407C8]
-       mov       r11,7FFB528707C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52EBC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E407C8]
-       mov       r11,7FFB528707C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5E8
-       mov       rdx,7FFB52EBC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5C8
-       mov       rdx,7FFB52EBC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC828
-       mov       rdx,7FFB52EBCAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C7E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C7E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CE33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/847d6761-01fa-403e-9622-a7150871c6ae-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a09610fb-a32a-4fc0-aa1b-ef6ea0aab050-diff.temp
index 2e3095c..3f5b312 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a09610fb-a32a-4fc0-aa1b-ef6ea0aab050-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/847d6761-01fa-403e-9622-a7150871c6ae-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,1F426271B88
-       mov       rax,2324E46B798
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,1F436273090
-       mov       rdx,2324E463090
        mov       rcx,[rcx]
+       mov       rcx,1F426271688
-       mov       rcx,2324E46B298
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E407D0]
-       mov       r11,7FFB528707D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E407C8]
-       mov       r11,7FFB528707C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC648
-       mov       rdx,7FFB52EBC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E407C8]
-       mov       r11,7FFB528707C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52EBC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5F8
-       mov       rdx,7FFB52EBC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC858
-       mov       rdx,7FFB52EBCAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C7E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C7E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CE33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2fa21236-9a39-4ff7-9b98-667508966d9f-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f2e6ecf4-aa57-4c13-ab7a-cf86c2f8cdb2-diff.temp
index 2e3095c..c901bc9 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f2e6ecf4-aa57-4c13-ab7a-cf86c2f8cdb2-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2fa21236-9a39-4ff7-9b98-667508966d9f-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,2235BDC2BA0
-       mov       rax,2B715831B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,2234BDC3090
-       mov       rdx,2B725833090
        mov       rcx,[rcx]
+       mov       rcx,2235BDC26A0
-       mov       rcx,2B715831688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307D0]
+       mov       r11,7FFB528607D0
-       call      qword ptr [7FFB52E407D0]
-       mov       r11,7FFB528707D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307C8]
+       mov       r11,7FFB528607C8
-       call      qword ptr [7FFB52E407C8]
-       mov       r11,7FFB528707C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC890
-       mov       rdx,7FFB52EBC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307C8]
+       mov       r11,7FFB528607C8
-       call      qword ptr [7FFB52E407C8]
-       mov       r11,7FFB528707C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC860
-       mov       rdx,7FFB52EBC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC840
-       mov       rdx,7FFB52EBC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC800
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EACAA0
-       mov       rdx,7FFB52EBCAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC800
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC800
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C7E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C7E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CD33C0
-       mov       rdx,7FFB52CE33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ce5efd68-4cfe-4e39-8ee2-4339315927ec-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/103fecaa-717d-4d84-98d8-8f124ddc11e1-diff.temp
index 1715111..5580b59 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/103fecaa-717d-4d84-98d8-8f124ddc11e1-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ce5efd68-4cfe-4e39-8ee2-4339315927ec-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,1DE33341B88
-       mov       rax,2B715831B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,1DE43343090
-       mov       rdx,2B725833090
        mov       rcx,[rcx]
+       mov       rcx,1DE33341688
-       mov       rcx,2B715831688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E407D0]
-       mov       r11,7FFB528707D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E407C8]
-       mov       r11,7FFB528707C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52EBC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E407C8]
-       mov       r11,7FFB528707C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5E8
-       mov       rdx,7FFB52EBC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5C8
-       mov       rdx,7FFB52EBC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC828
-       mov       rdx,7FFB52EBCAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C7E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C7E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CE33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f2c0ae75-2bca-4ae6-9f7d-2e3c3c4903e7-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a844664d-db7a-405a-bb3c-20bf048b91ad-diff.temp
index 1715111..3f5b312 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a844664d-db7a-405a-bb3c-20bf048b91ad-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f2c0ae75-2bca-4ae6-9f7d-2e3c3c4903e7-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,1F426271B88
-       mov       rax,2B715831B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B378E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,1F436273090
-       mov       rdx,2B725833090
        mov       rcx,[rcx]
+       mov       rcx,1F426271688
-       mov       rcx,2B715831688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E407D0]
-       mov       r11,7FFB528707D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E407C8]
-       mov       r11,7FFB528707C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC648
-       mov       rdx,7FFB52EBC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E407C8]
-       mov       r11,7FFB528707C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52EBC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5F8
-       mov       rdx,7FFB52EBC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC858
-       mov       rdx,7FFB52EBCAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EBC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C7E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C7E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CE33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/46ac0e33-acc8-4523-9468-81c3f3b3487a-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b0e48d64-6a3e-4fe7-bac9-c227e50ed080-diff.temp
index 1715111..c901bc9 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b0e48d64-6a3e-4fe7-bac9-c227e50ed080-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/46ac0e33-acc8-4523-9468-81c3f3b3487a-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,1DE33341B88
-       mov       rax,2235BDC2BA0
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,1DE43343090
-       mov       rdx,2234BDC3090
        mov       rcx,[rcx]
+       mov       rcx,1DE33341688
-       mov       rcx,2235BDC26A0
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E307D0]
-       mov       r11,7FFB528607D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52EAC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5E8
-       mov       rdx,7FFB52EAC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5C8
-       mov       rdx,7FFB52EAC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC828
-       mov       rdx,7FFB52EACAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
        mov       rdx,7FFB52C6E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
        mov       rdx,7FFB52C6E7E0
        mov       ecx,4D
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CD33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ae3ac433-bf60-408b-bcd8-32501794c8e5-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c2a5c42c-1c1f-47e3-99fc-74fe6cae06b9-diff.temp
index 5580b59..3f5b312 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c2a5c42c-1c1f-47e3-99fc-74fe6cae06b9-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ae3ac433-bf60-408b-bcd8-32501794c8e5-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,1F426271B88
-       mov       rax,2235BDC2BA0
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,1F436273090
-       mov       rdx,2234BDC3090
        mov       rcx,[rcx]
+       mov       rcx,1F426271688
-       mov       rcx,2235BDC26A0
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E307D0]
-       mov       r11,7FFB528607D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC648
-       mov       rdx,7FFB52EAC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52EAC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5F8
-       mov       rdx,7FFB52EAC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC858
-       mov       rdx,7FFB52EACAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
        mov       rdx,7FFB52C6E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
        mov       rdx,7FFB52C6E7E0
        mov       ecx,4D
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CD33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), ensureUnique: Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate03()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/43584c71-7ae5-41fb-aa2f-a914786c759e-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4b3cb548-eac8-41ca-a57f-973714336f71-diff.temp
index 5580b59..c901bc9 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4b3cb548-eac8-41ca-a57f-973714336f71-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/43584c71-7ae5-41fb-aa2f-a914786c759e-diff.temp
```
**Diff for CollectionCreate03 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,1F436273090
-       mov       rdx,1DE43343090
        mov       rcx,[rcx]
+       mov       rcx,1F426271688
-       mov       rcx,1DE33341688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
        call      qword ptr [7FFB52E307E0]
        mov       r11,7FFB528607E0
        mov       rcx,rbx
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC648
-       mov       rdx,7FFB52EBC618
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52EBC5E8
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5F8
-       mov       rdx,7FFB52EBC5C8
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EBC588
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC858
-       mov       rdx,7FFB52EBC828
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EBC588
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EBC588
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
        mov       rdx,7FFB52C6E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
        mov       rdx,7FFB52C6E7E0
        mov       ecx,4D
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1c28702a-0aad-4561-9fe5-9865985638c2-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/88b2cf0e-7c49-4c09-86b4-a322103db802-diff.temp
index 3f5b312..c901bc9 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/88b2cf0e-7c49-4c09-86b4-a322103db802-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1c28702a-0aad-4561-9fe5-9865985638c2-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,207010AA780
-       mov       rax,24A6CF91B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,207010A3090
-       mov       rdx,24A4CF93090
        mov       rcx,[rcx]
+       mov       rcx,207010AA280
-       mov       rcx,24A6CF91688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307D0]
+       mov       r11,7FFB528607D0
-       call      qword ptr [7FFB52E207D0]
-       mov       r11,7FFB528507D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307C8]
+       mov       r11,7FFB528607C8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC890
-       mov       rdx,7FFB52E9C890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307C8]
+       mov       r11,7FFB528607C8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC860
-       mov       rdx,7FFB52E9C860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC840
-       mov       rdx,7FFB52E9C840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC800
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EACAA0
-       mov       rdx,7FFB52E9CAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC800
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EAC800
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CD33C0
-       mov       rdx,7FFB52CC33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7015842e-044d-4fa5-96bb-b3e790968f73-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/89a649c4-6c89-405f-8d4a-a4cfb9f5e3a2-diff.temp
index 7afd461..28ff50e 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/89a649c4-6c89-405f-8d4a-a4cfb9f5e3a2-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7015842e-044d-4fa5-96bb-b3e790968f73-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,1D97AEE3090
-       mov       rdx,24A4CF93090
        mov       rcx,[rcx]
+       mov       rcx,1D97AEEA280
-       mov       rcx,24A6CF91688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
        call      qword ptr [7FFB52E207D0]
        mov       r11,7FFB528507D0
        mov       rcx,rbx
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/738f66ef-9394-4fe8-a4b9-d3a0e9135bf7-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4d985e09-54f6-44fd-8d54-6614f9a507ca-diff.temp
index 7afd461..87cbc58 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4d985e09-54f6-44fd-8d54-6614f9a507ca-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/738f66ef-9394-4fe8-a4b9-d3a0e9135bf7-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B078E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B078E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B078E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,1D132BD2BA0
-       mov       rax,24A6CF91B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B078E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B078E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B078E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,1D142BD3090
-       mov       rdx,24A4CF93090
        mov       rcx,[rcx]
+       mov       rcx,1D132BD26A0
-       mov       rcx,24A6CF91688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E107D0]
+       mov       r11,7FFB528407D0
-       call      qword ptr [7FFB52E207D0]
-       mov       r11,7FFB528507D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E107C8]
+       mov       r11,7FFB528407C8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8C890
-       mov       rdx,7FFB52E9C890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E107C8]
+       mov       r11,7FFB528407C8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8C860
-       mov       rdx,7FFB52E9C860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8C840
-       mov       rdx,7FFB52E9C840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8C800
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8CAA0
-       mov       rdx,7FFB52E9CAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8C800
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8C800
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C4E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C4E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CB33C0
-       mov       rdx,7FFB52CC33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b07e1a65-19eb-40c6-97d0-dfb514c9e2dc-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0aa4a4ae-78e6-4562-b282-370784044e85-diff.temp
index 7afd461..79a48ca 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0aa4a4ae-78e6-4562-b282-370784044e85-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b07e1a65-19eb-40c6-97d0-dfb514c9e2dc-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,219F84F3090
-       mov       rdx,24A4CF93090
        mov       rcx,[rcx]
+       mov       rcx,21A084F1688
-       mov       rcx,24A6CF91688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
        call      qword ptr [7FFB52E207D0]
        mov       r11,7FFB528507D0
        mov       rcx,rbx
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b028e321-77c4-44a1-90a8-8a6d5ea4c61a-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0ecfd081-a95d-4fa0-8be6-7f3747186d83-diff.temp
index 7afd461..819ca71 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0ecfd081-a95d-4fa0-8be6-7f3747186d83-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b028e321-77c4-44a1-90a8-8a6d5ea4c61a-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,26C86083090
-       mov       rdx,24A4CF93090
        mov       rcx,[rcx]
+       mov       rcx,26C66082EB8
-       mov       rcx,24A6CF91688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
        call      qword ptr [7FFB52E207D0]
        mov       r11,7FFB528507D0
        mov       rcx,rbx
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/01ecdce5-7de6-4b51-a864-4b4e94410dff-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3885ccb0-72dd-4b75-bc26-140f922be9a5-diff.temp
index 7afd461..3fb479d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3885ccb0-72dd-4b75-bc26-140f922be9a5-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/01ecdce5-7de6-4b51-a864-4b4e94410dff-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,215B32C2BA0
-       mov       rax,24A6CF91B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,215A32C3090
-       mov       rdx,24A4CF93090
        mov       rcx,[rcx]
+       mov       rcx,215B32C26A0
-       mov       rcx,24A6CF91688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E207D0]
-       mov       r11,7FFB528507D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52E9C890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5E8
-       mov       rdx,7FFB52E9C860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5C8
-       mov       rdx,7FFB52E9C840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC828
-       mov       rdx,7FFB52E9CAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CC33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/76ed941e-46c4-4797-8e4a-b8f86aa71ffb-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ff2fb084-cfeb-41dc-913d-bd4fbc0f02c7-diff.temp
index 7afd461..0685b31 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ff2fb084-cfeb-41dc-913d-bd4fbc0f02c7-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/76ed941e-46c4-4797-8e4a-b8f86aa71ffb-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,16594D29F68
-       mov       rax,24A6CF91B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,16594D23090
-       mov       rdx,24A4CF93090
        mov       rcx,[rcx]
+       mov       rcx,16594D29A68
-       mov       rcx,24A6CF91688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E207D0]
-       mov       r11,7FFB528507D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC648
-       mov       rdx,7FFB52E9C890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52E9C860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5F8
-       mov       rdx,7FFB52E9C840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC858
-       mov       rdx,7FFB52E9CAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CC33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f84c9195-6693-49b5-a5cf-0eb899eb34ed-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/02769998-223f-4581-8191-c20f5d1623f6-diff.temp
index 7afd461..422bca8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/02769998-223f-4581-8191-c20f5d1623f6-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f84c9195-6693-49b5-a5cf-0eb899eb34ed-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,1D97AEEA780
-       mov       rax,207010AA780
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,1D97AEE3090
-       mov       rdx,207010A3090
        mov       rcx,[rcx]
+       mov       rcx,1D97AEEA280
-       mov       rcx,207010AA280
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E207D0]
+       mov       r11,7FFB528507D0
-       call      qword ptr [7FFB52E307D0]
-       mov       r11,7FFB528607D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E207C8]
+       mov       r11,7FFB528507C8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C890
-       mov       rdx,7FFB52EAC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E207C8]
+       mov       r11,7FFB528507C8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C860
-       mov       rdx,7FFB52EAC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C840
-       mov       rdx,7FFB52EAC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9CAA0
-       mov       rdx,7FFB52EACAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C5E7E0
-       mov       rdx,7FFB52C6E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C5E7E0
-       mov       rdx,7FFB52C6E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CC33C0
-       mov       rdx,7FFB52CD33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c73cc6f4-035e-41df-bd55-a717582d2477-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7b6be54b-3bfa-46ae-bb41-b9a0b78e1772-diff.temp
index 28ff50e..87cbc58 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7b6be54b-3bfa-46ae-bb41-b9a0b78e1772-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c73cc6f4-035e-41df-bd55-a717582d2477-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B078E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B078E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B078E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,1D132BD2BA0
-       mov       rax,207010AA780
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B078E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B078E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B078E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,1D142BD3090
-       mov       rdx,207010A3090
        mov       rcx,[rcx]
+       mov       rcx,1D132BD26A0
-       mov       rcx,207010AA280
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E107D0]
+       mov       r11,7FFB528407D0
-       call      qword ptr [7FFB52E307D0]
-       mov       r11,7FFB528607D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E107C8]
+       mov       r11,7FFB528407C8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8C890
-       mov       rdx,7FFB52EAC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E107C8]
+       mov       r11,7FFB528407C8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8C860
-       mov       rdx,7FFB52EAC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8C840
-       mov       rdx,7FFB52EAC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8C800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8CAA0
-       mov       rdx,7FFB52EACAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8C800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8C800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C4E7E0
-       mov       rdx,7FFB52C6E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C4E7E0
-       mov       rdx,7FFB52C6E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CB33C0
-       mov       rdx,7FFB52CD33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4a66236f-b815-4134-b37c-cf012d638273-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/280807d7-8819-4eb0-8d42-a3ef48020aa8-diff.temp
index 28ff50e..79a48ca 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/280807d7-8819-4eb0-8d42-a3ef48020aa8-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4a66236f-b815-4134-b37c-cf012d638273-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,21A084F1B88
-       mov       rax,207010AA780
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,219F84F3090
-       mov       rdx,207010A3090
        mov       rcx,[rcx]
+       mov       rcx,21A084F1688
-       mov       rcx,207010AA280
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E207D0]
+       mov       r11,7FFB528507D0
-       call      qword ptr [7FFB52E307D0]
-       mov       r11,7FFB528607D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E207C8]
+       mov       r11,7FFB528507C8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C890
-       mov       rdx,7FFB52EAC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E207C8]
+       mov       r11,7FFB528507C8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C860
-       mov       rdx,7FFB52EAC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C840
-       mov       rdx,7FFB52EAC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9CAA0
-       mov       rdx,7FFB52EACAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C5E7E0
-       mov       rdx,7FFB52C6E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C5E7E0
-       mov       rdx,7FFB52C6E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CC33C0
-       mov       rdx,7FFB52CD33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f0cc8aae-b4bb-49f0-ae15-542491a49ffa-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f9aa709e-885a-497e-a17e-3fa0d8c75fe1-diff.temp
index 28ff50e..819ca71 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f9aa709e-885a-497e-a17e-3fa0d8c75fe1-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f0cc8aae-b4bb-49f0-ae15-542491a49ffa-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,26C660833B8
-       mov       rax,207010AA780
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B278E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,26C86083090
-       mov       rdx,207010A3090
        mov       rcx,[rcx]
+       mov       rcx,26C66082EB8
-       mov       rcx,207010AA280
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E207D0]
+       mov       r11,7FFB528507D0
-       call      qword ptr [7FFB52E307D0]
-       mov       r11,7FFB528607D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E207C8]
+       mov       r11,7FFB528507C8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C890
-       mov       rdx,7FFB52EAC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E207C8]
+       mov       r11,7FFB528507C8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C860
-       mov       rdx,7FFB52EAC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C840
-       mov       rdx,7FFB52EAC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9CAA0
-       mov       rdx,7FFB52EACAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C800
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C5E7E0
-       mov       rdx,7FFB52C6E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C5E7E0
-       mov       rdx,7FFB52C6E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CC33C0
-       mov       rdx,7FFB52CD33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d44d319b-f9c6-4fb0-b99e-9cd8d22e6fde-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/986e60a0-6c91-47b9-96a7-4052d0230c0f-diff.temp
index 28ff50e..3fb479d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/986e60a0-6c91-47b9-96a7-4052d0230c0f-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d44d319b-f9c6-4fb0-b99e-9cd8d22e6fde-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,215B32C2BA0
-       mov       rax,207010AA780
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,215A32C3090
-       mov       rdx,207010A3090
        mov       rcx,[rcx]
+       mov       rcx,215B32C26A0
-       mov       rcx,207010AA280
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E307D0]
-       mov       r11,7FFB528607D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52EAC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5E8
-       mov       rdx,7FFB52EAC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5C8
-       mov       rdx,7FFB52EAC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC828
-       mov       rdx,7FFB52EACAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
        mov       rdx,7FFB52C6E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
        mov       rdx,7FFB52C6E7E0
        mov       ecx,4D
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CD33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/62155b68-82e8-4c88-9337-c815ecb533a9-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7cecbdb5-f047-4fc0-a561-fa019da70f6d-diff.temp
index 28ff50e..0685b31 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7cecbdb5-f047-4fc0-a561-fa019da70f6d-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/62155b68-82e8-4c88-9337-c815ecb533a9-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,16594D29F68
-       mov       rax,207010AA780
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,16594D23090
-       mov       rdx,207010A3090
        mov       rcx,[rcx]
+       mov       rcx,16594D29A68
-       mov       rcx,207010AA280
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E307D0]
-       mov       r11,7FFB528607D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC648
-       mov       rdx,7FFB52EAC890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E307C8]
-       mov       r11,7FFB528607C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52EAC860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5F8
-       mov       rdx,7FFB52EAC840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC858
-       mov       rdx,7FFB52EACAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EAC800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
        mov       rdx,7FFB52C6E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
        mov       rdx,7FFB52C6E7E0
        mov       ecx,4D
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CD33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b268ce77-13e0-4265-860f-9b43d4b488bb-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e0ac2d67-8f00-4599-a498-e31bc2260f2b-diff.temp
index 28ff50e..422bca8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e0ac2d67-8f00-4599-a498-e31bc2260f2b-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b268ce77-13e0-4265-860f-9b43d4b488bb-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B078E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B078E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B078E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,1D132BD2BA0
-       mov       rax,1D97AEEA780
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B078E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B078E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B078E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,1D142BD3090
-       mov       rdx,1D97AEE3090
        mov       rcx,[rcx]
+       mov       rcx,1D132BD26A0
-       mov       rcx,1D97AEEA280
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E107D0]
+       mov       r11,7FFB528407D0
-       call      qword ptr [7FFB52E207D0]
-       mov       r11,7FFB528507D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E107C8]
+       mov       r11,7FFB528407C8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8C890
-       mov       rdx,7FFB52E9C890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E107C8]
+       mov       r11,7FFB528407C8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8C860
-       mov       rdx,7FFB52E9C860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8C840
-       mov       rdx,7FFB52E9C840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8C800
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8CAA0
-       mov       rdx,7FFB52E9CAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8C800
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E8C800
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C4E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C4E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CB33C0
-       mov       rdx,7FFB52CC33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1f09e574-3094-4798-bbb6-eae748d9a931-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/40ab46db-bef4-4ea2-8fe3-5b3bccb11f54-diff.temp
index 87cbc58..79a48ca 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/40ab46db-bef4-4ea2-8fe3-5b3bccb11f54-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1f09e574-3094-4798-bbb6-eae748d9a931-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,219F84F3090
-       mov       rdx,1D97AEE3090
        mov       rcx,[rcx]
+       mov       rcx,21A084F1688
-       mov       rcx,1D97AEEA280
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
        call      qword ptr [7FFB52E207D0]
        mov       r11,7FFB528507D0
        mov       rcx,rbx
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/46cc9bb8-c14c-474d-8974-7bb3677bb8d8-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c55d3332-63c4-4536-9ec6-dd35ae85fbdb-diff.temp
index 87cbc58..819ca71 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c55d3332-63c4-4536-9ec6-dd35ae85fbdb-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/46cc9bb8-c14c-474d-8974-7bb3677bb8d8-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,26C86083090
-       mov       rdx,1D97AEE3090
        mov       rcx,[rcx]
+       mov       rcx,26C66082EB8
-       mov       rcx,1D97AEEA280
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
        call      qword ptr [7FFB52E207D0]
        mov       r11,7FFB528507D0
        mov       rcx,rbx
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f67034b8-a6a0-4fa9-b74d-099dedebd3ad-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a85f48bb-f631-47e8-97c8-443320d3d419-diff.temp
index 87cbc58..3fb479d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a85f48bb-f631-47e8-97c8-443320d3d419-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f67034b8-a6a0-4fa9-b74d-099dedebd3ad-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,215B32C2BA0
-       mov       rax,1D97AEEA780
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,215A32C3090
-       mov       rdx,1D97AEE3090
        mov       rcx,[rcx]
+       mov       rcx,215B32C26A0
-       mov       rcx,1D97AEEA280
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E207D0]
-       mov       r11,7FFB528507D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52E9C890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5E8
-       mov       rdx,7FFB52E9C860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5C8
-       mov       rdx,7FFB52E9C840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC828
-       mov       rdx,7FFB52E9CAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CC33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b528e8b9-46ef-42f6-82f6-0d79f889d889-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2095fb86-ef67-48f4-a4a8-4021232c7867-diff.temp
index 87cbc58..0685b31 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2095fb86-ef67-48f4-a4a8-4021232c7867-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b528e8b9-46ef-42f6-82f6-0d79f889d889-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,16594D29F68
-       mov       rax,1D97AEEA780
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,16594D23090
-       mov       rdx,1D97AEE3090
        mov       rcx,[rcx]
+       mov       rcx,16594D29A68
-       mov       rcx,1D97AEEA280
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E207D0]
-       mov       r11,7FFB528507D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC648
-       mov       rdx,7FFB52E9C890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52E9C860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5F8
-       mov       rdx,7FFB52E9C840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC858
-       mov       rdx,7FFB52E9CAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CC33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/159ca901-ba46-43e5-99ff-4a36924493fb-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c520afab-6061-4563-b9a1-5dc36a87db69-diff.temp
index 87cbc58..422bca8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c520afab-6061-4563-b9a1-5dc36a87db69-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/159ca901-ba46-43e5-99ff-4a36924493fb-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,21A084F1B88
-       mov       rax,1D132BD2BA0
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,219F84F3090
-       mov       rdx,1D142BD3090
        mov       rcx,[rcx]
+       mov       rcx,21A084F1688
-       mov       rcx,1D132BD26A0
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E207D0]
+       mov       r11,7FFB528507D0
-       call      qword ptr [7FFB52E107D0]
-       mov       r11,7FFB528407D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E207C8]
+       mov       r11,7FFB528507C8
-       call      qword ptr [7FFB52E107C8]
-       mov       r11,7FFB528407C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C890
-       mov       rdx,7FFB52E8C890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E207C8]
+       mov       r11,7FFB528507C8
-       call      qword ptr [7FFB52E107C8]
-       mov       r11,7FFB528407C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C860
-       mov       rdx,7FFB52E8C860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C840
-       mov       rdx,7FFB52E8C840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C800
-       mov       rdx,7FFB52E8C800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9CAA0
-       mov       rdx,7FFB52E8CAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C800
-       mov       rdx,7FFB52E8C800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C800
-       mov       rdx,7FFB52E8C800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C5E7E0
-       mov       rdx,7FFB52C4E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C5E7E0
-       mov       rdx,7FFB52C4E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CC33C0
-       mov       rdx,7FFB52CB33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0cfb0178-92b6-47ec-b68d-1b0a8a0d7f10-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ac49c9b7-62f8-438d-8b99-9c1f318afbcc-diff.temp
index 79a48ca..819ca71 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ac49c9b7-62f8-438d-8b99-9c1f318afbcc-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0cfb0178-92b6-47ec-b68d-1b0a8a0d7f10-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,26C660833B8
-       mov       rax,1D132BD2BA0
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B178E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,26C86083090
-       mov       rdx,1D142BD3090
        mov       rcx,[rcx]
+       mov       rcx,26C66082EB8
-       mov       rcx,1D132BD26A0
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E207D0]
+       mov       r11,7FFB528507D0
-       call      qword ptr [7FFB52E107D0]
-       mov       r11,7FFB528407D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E207C8]
+       mov       r11,7FFB528507C8
-       call      qword ptr [7FFB52E107C8]
-       mov       r11,7FFB528407C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C890
-       mov       rdx,7FFB52E8C890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E207C8]
+       mov       r11,7FFB528507C8
-       call      qword ptr [7FFB52E107C8]
-       mov       r11,7FFB528407C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C860
-       mov       rdx,7FFB52E8C860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C840
-       mov       rdx,7FFB52E8C840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C800
-       mov       rdx,7FFB52E8C800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9CAA0
-       mov       rdx,7FFB52E8CAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C800
-       mov       rdx,7FFB52E8C800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52E9C800
-       mov       rdx,7FFB52E8C800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C5E7E0
-       mov       rdx,7FFB52C4E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C5E7E0
-       mov       rdx,7FFB52C4E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CC33C0
-       mov       rdx,7FFB52CB33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/bd564f38-a387-4d1f-89d1-a637d149bf98-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e6926401-5b4f-40c1-ad30-55425f90df25-diff.temp
index 79a48ca..3fb479d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e6926401-5b4f-40c1-ad30-55425f90df25-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/bd564f38-a387-4d1f-89d1-a637d149bf98-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,215B32C2BA0
-       mov       rax,1D132BD2BA0
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,215A32C3090
-       mov       rdx,1D142BD3090
        mov       rcx,[rcx]
+       mov       rcx,215B32C26A0
-       mov       rcx,1D132BD26A0
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E107D0]
-       mov       r11,7FFB528407D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E107C8]
-       mov       r11,7FFB528407C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52E8C890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E107C8]
-       mov       r11,7FFB528407C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5E8
-       mov       rdx,7FFB52E8C860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5C8
-       mov       rdx,7FFB52E8C840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52E8C800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC828
-       mov       rdx,7FFB52E8CAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52E8C800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52E8C800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C4E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C4E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CB33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a1d4c446-6d96-4d85-b16e-010e54cbf762-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b297e07d-0a4b-417f-bcc5-b571ea94fce5-diff.temp
index 79a48ca..0685b31 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b297e07d-0a4b-417f-bcc5-b571ea94fce5-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a1d4c446-6d96-4d85-b16e-010e54cbf762-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,16594D29F68
-       mov       rax,1D132BD2BA0
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B078E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,16594D23090
-       mov       rdx,1D142BD3090
        mov       rcx,[rcx]
+       mov       rcx,16594D29A68
-       mov       rcx,1D132BD26A0
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E107D0]
-       mov       r11,7FFB528407D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E107C8]
-       mov       r11,7FFB528407C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC648
-       mov       rdx,7FFB52E8C890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E107C8]
-       mov       r11,7FFB528407C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52E8C860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5F8
-       mov       rdx,7FFB52E8C840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52E8C800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC858
-       mov       rdx,7FFB52E8CAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52E8C800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52E8C800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C4E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C4E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CB33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/98ab3515-a7d5-4f22-bc6c-9a79dd5f411b-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/362fdb7d-d65f-4ac9-b4c6-ade19b39f050-diff.temp
index 79a48ca..422bca8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/362fdb7d-d65f-4ac9-b4c6-ade19b39f050-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/98ab3515-a7d5-4f22-bc6c-9a79dd5f411b-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,26C86083090
-       mov       rdx,219F84F3090
        mov       rcx,[rcx]
+       mov       rcx,26C66082EB8
-       mov       rcx,21A084F1688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
        call      qword ptr [7FFB52E207D0]
        mov       r11,7FFB528507D0
        mov       rcx,rbx
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6a827ef6-ecfe-4f43-a213-ab71dfeabbc0-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/745dc944-4849-4346-9531-71fa3646cfbc-diff.temp
index 819ca71..3fb479d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/745dc944-4849-4346-9531-71fa3646cfbc-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6a827ef6-ecfe-4f43-a213-ab71dfeabbc0-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,215B32C2BA0
-       mov       rax,21A084F1B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,215A32C3090
-       mov       rdx,219F84F3090
        mov       rcx,[rcx]
+       mov       rcx,215B32C26A0
-       mov       rcx,21A084F1688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E207D0]
-       mov       r11,7FFB528507D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52E9C890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5E8
-       mov       rdx,7FFB52E9C860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5C8
-       mov       rdx,7FFB52E9C840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC828
-       mov       rdx,7FFB52E9CAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CC33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1dc903f8-454b-4cd9-9ddb-2bceafc419d3-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e73f82c9-f733-4cc1-8692-7aaa2f19ae0a-diff.temp
index 819ca71..0685b31 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e73f82c9-f733-4cc1-8692-7aaa2f19ae0a-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1dc903f8-454b-4cd9-9ddb-2bceafc419d3-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,16594D29F68
-       mov       rax,21A084F1B88
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,16594D23090
-       mov       rdx,219F84F3090
        mov       rcx,[rcx]
+       mov       rcx,16594D29A68
-       mov       rcx,21A084F1688
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E207D0]
-       mov       r11,7FFB528507D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC648
-       mov       rdx,7FFB52E9C890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52E9C860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5F8
-       mov       rdx,7FFB52E9C840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC858
-       mov       rdx,7FFB52E9CAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CC33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d0a33ae1-3eb1-432b-b762-dd8a99b96221-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1fae131a-e12c-4e92-82db-11b9b121e5fc-diff.temp
index 819ca71..422bca8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1fae131a-e12c-4e92-82db-11b9b121e5fc-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d0a33ae1-3eb1-432b-b762-dd8a99b96221-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,215B32C2BA0
-       mov       rax,26C660833B8
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,215A32C3090
-       mov       rdx,26C86083090
        mov       rcx,[rcx]
+       mov       rcx,215B32C26A0
-       mov       rcx,26C66082EB8
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E207D0]
-       mov       r11,7FFB528507D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52E9C890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5E8
-       mov       rdx,7FFB52E9C860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5C8
-       mov       rdx,7FFB52E9C840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC828
-       mov       rdx,7FFB52E9CAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC588
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CC33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3aec4879-ed5d-4fe3-9d2c-0b7f0a83aa6f-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/8954a098-e370-45cf-8346-fe40816bef63-diff.temp
index 3fb479d..0685b31 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/8954a098-e370-45cf-8346-fe40816bef63-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3aec4879-ed5d-4fe3-9d2c-0b7f0a83aa6f-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L28
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L27:
        mov       eax,1
        jmp       short M02_L27
        xor       eax,eax
        je        short M02_L26
        cmp       dword ptr [rcx+8],0
        mov       rcx,[rax]
+       mov       rax,16594D29F68
-       mov       rax,26C660833B8
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorEnumNotDefined()
 M02_L25:
        call      CORINFO_HELP_THROW
        mov       rcx,rdi
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rdi
        mov       rdx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rdi,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rsi,rax
        call      System.String.TrimWhiteSpaceHelper(System.Text.TrimType)
        mov       edx,3
        cmp       [rcx],ecx
        call      CORINFO_HELP_THROW
        mov       rcx,rbx
        call      System.ArgumentNullException..ctor(System.String, System.String)
        mov       rcx,rbx
        mov       rdx,rdi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.ExceptionThrower.DefaultIfNull(System.String, System.String)
        mov       rcx,rsi
        mov       rdx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorArgumentNull()
        mov       rbx,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_System.ArgumentNullException
        mov       rdi,rax
        call      DotNetTips.Spargine.Core.Validator.ArgumentNotNullOrEmpty(System.String, Boolean, System.String, System.String, System.String)
        xor       r8d,r8d
        mov       edx,1
        mov       [rsp+20],rax
        mov       r9,rbx
        mov       rcx,rdi
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rbx,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,9
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52B278E8
-       mov       rdx,7FFB52B178E8
        mov       ecx,3A5
        mov       rsi,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorStringIsNullOrEmpty()
        jne       near ptr M02_L24
        test      eax,eax
        movzx     eax,al
        sete      al
        test      eax,eax
 M02_L23:
        mov       eax,1
        jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,16594D23090
-       mov       rdx,26C86083090
        mov       rcx,[rcx]
+       mov       rcx,16594D29A68
-       mov       rcx,26C66082EB8
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
+       call      qword ptr [7FFB52E307E0]
+       mov       r11,7FFB528607E0
-       call      qword ptr [7FFB52E207D0]
-       mov       r11,7FFB528507D0
        mov       rcx,rbx
 M02_L20:
        jne       near ptr M02_L13
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
 M02_L19:
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]].AddWithResize(System.__Canon)
        mov       rdx,rax
        mov       rcx,r15
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC648
-       mov       rdx,7FFB52E9C890
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L13:
        je        near ptr M02_L20
        test      eax,eax
+       call      qword ptr [7FFB52E307D8]
+       mov       r11,7FFB528607D8
-       call      qword ptr [7FFB52E207C8]
-       mov       r11,7FFB528507C8
        mov       rcx,rbx
        mov       [rbp+0FFB8],rbx
        mov       rbx,rax
        call      qword ptr [r11]
        mov       rcx,rbx
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52E9C860
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5F8
-       mov       rdx,7FFB52E9C840
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC858
-       mov       rdx,7FFB52E9CAA0
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52E9C800
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
+       mov       rdx,7FFB52C6E7E0
-       mov       rdx,7FFB52C5E7E0
        mov       ecx,4D
 M01_L02:
        jmp       near ptr DotNetTips.Spargine.Extensions.ObjectExtensions.FromJson[[System.__Canon, System.Private.CoreLib]](System.String)
        pop       rdi
        pop       rsi
        add       rsp,28
        mov       rdx,rdi
 M01_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_METHOD
+       mov       rdx,7FFB52CDAF70
-       mov       rdx,7FFB52CC33C0
        mov       rcx,rsi
 M01_L00:
        jmp       short M01_L01
        je        short M01_L00
        test      rcx,rcx
        mov       rcx,[rcx+10]
        mov       rcx,[rsi+10]
        mov       rdi,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.ToJson(System.Object)
        mov       rcx,rdx
        je        short M01_L02
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rdx,rdx
        mov       rsi,rcx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
 ; Total bytes of code 79
        ret
        pop       rsi
        add       rsp,20
        nop
        call      CORINFO_HELP_CHECKED_ASSIGN_REF
        mov       rdx,rax
        add       rcx,10
        cmp       [rcx],ecx
        mov       rcx,[rsi+18]
        call      DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
        mov       r8d,0FFFFFFFF
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[DotNetTips.Spargine.Tester.Models.RefTypes.PersonProper, DotNetTips.Spargine.6.Tester]]
        mov       rdx,rax
        call      DotNetTips.Spargine.Extensions.ObjectExtensions.Clone[[System.__Canon, System.Private.CoreLib]](System.Object)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ObjectExtensions.Clone(System.Object)
        mov       rdx,[rsi+268]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			Consumer.Consume(result);
 ; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
 ; 			var result = Collection<PersonProper>.Create(this.GetPersonProperRefArray(), Tristate.True);
 ; DotNetTips.Spargine.Core.BenchmarkTests.Collections.CollectionCollectionBenchmark.CollectionCreate02()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/36a2303b-8010-49f8-a857-52a6f6d9122a-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9f44bffd-9fa3-498d-8f38-29c3fdbf0bfc-diff.temp
index 3fb479d..422bca8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9f44bffd-9fa3-498d-8f38-29c3fdbf0bfc-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/36a2303b-8010-49f8-a857-52a6f6d9122a-diff.temp
```
**Diff for CollectionCreate02 method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
jmp       short M02_L23
        xor       eax,eax
        je        short M02_L22
        cmp       dword ptr [rcx+8],0
        je        short M02_L22
        test      rcx,rcx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,rbx
        mov       rcx,rax
        call      System.String.Concat(System.String, System.String)
        mov       rdx,[rdx]
+       mov       rdx,16594D23090
-       mov       rdx,215A32C3090
        mov       rcx,[rcx]
+       mov       rcx,16594D29A68
-       mov       rcx,215B32C26A0
        mov       rbx,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
 M02_L21:
        ret
        pop       rbp
        pop       r15
        pop       r14
        pop       r13
        pop       r12
        pop       rdi
        pop       rsi
        pop       rbx
        add       rsp,48
        mov       rax,r15
        call      qword ptr [7FFB52E307E0]
        mov       r11,7FFB528607E0
        mov       rcx,rbx
 M02_L15:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC648
-       mov       rdx,7FFB52EBC618
        mov       rcx,rdi
 M02_L14:
        jmp       short M02_L15
        je        short M02_L14
        test      r11,r11
        mov       r11,[r14+30]
 M02_L12:
        mov       r11,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC618
-       mov       rdx,7FFB52EBC5E8
        mov       rcx,rdi
 M02_L11:
        jmp       short M02_L12
        je        short M02_L11
        test      r11,r11
        mov       r11,[r14+28]
        mov       rbx,rax
        call      System.Linq.Enumerable.Where[[System.__Canon, System.Private.CoreLib]](System.Collections.Generic.IEnumerable`1<System.__Canon>, System.Func`2<System.__Canon,Boolean>)
        mov       r8,r12
        mov       rdx,rbx
 M02_L10:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5F8
-       mov       rdx,7FFB52EBC5C8
        mov       rcx,rdi
 M02_L09:
        jmp       short M02_L10
        je        short M02_L09
        test      rcx,rcx
        mov       rcx,[r14+20]
 M02_L07:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EBC588
        mov       rcx,rdi
 M02_L06:
        jmp       short M02_L07
        je        short M02_L06
        test      rcx,rcx
        mov       rcx,[r14+18]
        mov       [r13+18],rcx
        mov       rcx,offset DotNetTips.Spargine.Core.Collections.Generic.Collection`1+<>c[[System.__Canon, System.Private.CoreLib]].<Create>b__8_0(System.__Canon)
        call      CORINFO_HELP_ASSIGN_REF
        mov       rdx,r12
        lea       rcx,[r13+8]
        je        near ptr M02_L29
        test      r12,r12
        mov       r13,rax
        call      CORINFO_HELP_NEWSFAST
 M02_L05:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC858
-       mov       rdx,7FFB52EBC828
        mov       rcx,rdi
 M02_L04:
        jmp       short M02_L05
        je        short M02_L04
        test      rcx,rcx
        mov       rcx,[r14+38]
        mov       r12,[rax]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L03:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EBC588
        mov       rcx,rdi
 M02_L02:
        jmp       short M02_L03
        je        short M02_L02
        test      rcx,rcx
        mov       rcx,[r14+18]
        jne       near ptr M02_L08
        test      r12,r12
        mov       r12,[rax+8]
        call      CORINFO_HELP_GETGENERICS_GCSTATIC_BASE
 M02_L01:
        mov       rcx,rax
        call      CORINFO_HELP_RUNTIMEHANDLE_CLASS
+       mov       rdx,7FFB52EBC5B8
-       mov       rdx,7FFB52EBC588
        mov       rcx,rdi
 M02_L00:
        jmp       short M02_L01
        je        short M02_L00
        test      rcx,rcx
        mov       rcx,[r14+18]
        call      System.Collections.Generic.List`1[[System.__Canon, System.Private.CoreLib]]..ctor()
        mov       rcx,r15
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,rdi
        je        near ptr M02_L25
        test      eax,eax
        call      System.Enum.IsDefined(System.Type, System.Object)
        mov       rdx,r15
        mov       [r15+8],esi
        mov       rcx,rax
        call      CORINFO_HELP_TYPEHANDLE_TO_RUNTIMETYPE
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        mov       r15,rax
        call      CORINFO_HELP_NEWSFAST
        mov       rcx,offset MT_DotNetTips.Spargine.Core.Tristate
        je        near ptr M02_L21
        test      ecx,ecx
        movzx     ecx,cl
        setne     cl
        test      rbx,rbx
        mov       r14,[rcx+8]
        mov       rcx,[rdi+30]
        mov       esi,r8d
        mov       rbx,rdx
        mov       rdi,rcx
        mov       [rbp+0FFC0],rcx
        mov       [rbp+0FFA8],rsp
        lea       rbp,[rsp+80]
        sub       rsp,48
        push      rbx
        push      rsi
        push      rdi
        push      r12
        push      r13
        push      r14
        push      r15
        push      rbp
 ; DotNetTips.Spargine.Core.Collections.Generic.Collection`1[[System.__Canon, System.Private.CoreLib]].Create(System.Collections.Generic.IEnumerable`1<System.__Canon>, DotNetTips.Spargine.Core.Tristate)
 ; Total bytes of code 162
        int       3
        call      DotNetTips.Spargine.Core.ExceptionThrower.ThrowArgumentNullException(System.String)
        mov       rcx,rax
        call      DotNetTips.Spargine.Core.Validator.CreateParamExceptionMessage(System.String, System.String, System.String)
        mov       rdx,rdi
        mov       rcx,rsi
        mov       r8,rax
        call      DotNetTips.Spargine.Core.Properties.Resources.get_ErrorObjectCannotBeNull()
        mov       rdi,rax
        call      CORINFO_HELP_STRCNS
        mov       rdx,7FFB52C6E7E0
        mov       ecx,77B
        mov       rsi,rax
        call      CORINFO_HELP_STRCNS
        mov       rdx,7FFB52C6E7E0
        mov       ecx,4D
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3ad7608f-aa5a-4d37-aeaf-d3afdf6a6c28-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a11badaf-3634-4086-bac7-484e04129c15-diff.temp
index 0685b31..422bca8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a11badaf-3634-4086-bac7-484e04129c15-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3ad7608f-aa5a-4d37-aeaf-d3afdf6a6c28-diff.temp
```
