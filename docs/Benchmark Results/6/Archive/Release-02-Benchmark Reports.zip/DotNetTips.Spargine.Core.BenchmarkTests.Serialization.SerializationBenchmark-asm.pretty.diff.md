## DotNetTips.Spargine.Core.BenchmarkTests.Serialization.SerializationBenchmark-20220802-083506
