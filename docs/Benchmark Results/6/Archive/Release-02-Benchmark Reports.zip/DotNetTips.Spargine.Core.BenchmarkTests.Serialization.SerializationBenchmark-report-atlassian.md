{noformat}

BenchmarkDotNet=v0.13.1, OS=Windows 10.0.19044.1826 (21H2)
Intel Core i7-7660U CPU 2.50GHz (Kaby Lake), 1 CPU, 4 logical and 2 physical cores
.NET SDK=7.0.100-preview.6.22352.1
  [Host]     : .NET 6.0.7 (6.0.722.32202), X64 RyuJIT
  Job-YKIQEX : .NET 6.0.7 (6.0.722.32202), X64 RyuJIT

EvaluateOverhead=True  Runtime=.NET 6.0  Server=True  
Namespace=DotNetTips.Spargine.Core.BenchmarkTests.Serialization  

{noformat}
||                          Method ||        Categories ||     Mean ||    Error ||   StdDev ||   StdErr ||      Min ||       Q1 ||   Median ||       Q3 ||      Max ||     Op/s ||CI99.9% Margin ||Iterations ||Kurtosis ||MValue ||Skewness ||Rank ||LogicalGroup ||Baseline || Gen 0 ||Code Size || Gen 1 ||Allocated ||
| *'Deserialize: JSON-PersonProper'* |      *Serialization* |  *4.543 μs* | *0.2599 μs* | *0.7662 μs* | *0.0766 μs* |  *3.385 μs* |  *3.769 μs* |  *4.660 μs* |  *5.014 μs* |  *6.709 μs* | *220,142.3* |      *0.2599 μs* |     *100.00* |    *2.745* |  *3.419* |   *0.4495* |    *3* |            *** |       *No* | *0.0763* |     *411 B* |      *-* |     *712 B* |
| *'Deserialize: JSON-PersonRecord'* |      *Serialization* | *11.263 μs* | *0.4727 μs* | *1.3787 μs* | *0.1393 μs* |  *9.410 μs* | *10.125 μs* | *10.922 μs* | *12.032 μs* | *14.985 μs* |  *88,786.0* |      *0.4727 μs* |      *98.00* |    *2.822* |  *2.710* |   *0.8664* |    *4* |            *** |       *No* | *0.2747* |     *411 B* |      *-* |   *2,584 B* |
|  *'Deserialize: XML=PersonProper'* |  *XML,Serialization* | *35.072 μs* | *2.4653 μs* | *7.2690 μs* | *0.7269 μs* | *25.401 μs* | *28.752 μs* | *33.753 μs* | *40.444 μs* | *50.770 μs* |  *28,512.6* |      *2.4653 μs* |     *100.00* |    *2.083* |  *3.394* |   *0.5671* |    *8* |            *** |       *No* | *2.0142* |     *795 B* |      *-* |  *18,412 B* |
|  *'Deserialize: XML=PersonRecord'* |  *XML,Serialization* | *25.146 μs* | *1.0528 μs* | *3.1042 μs* | *0.3104 μs* | *20.351 μs* | *22.354 μs* | *24.844 μs* | *27.475 μs* | *32.993 μs* |  *39,767.7* |      *1.0528 μs* |     *100.00* |    *2.257* |  *3.120* |   *0.3634* |    *6* |            *** |       *No* | *1.9531* |     *795 B* |      *-* |  *18,180 B* |
|   *'Serialize: JSON=PersonProper'* | *JSON,Serialization* |  *1.906 μs* | *0.0382 μs* | *0.0930 μs* | *0.0111 μs* |  *1.746 μs* |  *1.848 μs* |  *1.884 μs* |  *1.944 μs* |  *2.194 μs* | *524,709.9* |      *0.0382 μs* |      *70.00* |    *3.604* |  *2.167* |   *0.8964* |    *1* |            *** |       *No* | *0.1221* |     *683 B* |      *-* |   *1,144 B* |
|   *'Serialize: JSON=PersonRecord'* | *JSON,Serialization* |  *4.002 μs* | *0.0771 μs* | *0.1833 μs* | *0.0224 μs* |  *3.721 μs* |  *3.872 μs* |  *3.998 μs* |  *4.081 μs* |  *4.515 μs* | *249,871.5* |      *0.0771 μs* |      *67.00* |    *3.327* |  *2.636* |   *0.7221* |    *2* |            *** |       *No* | *0.2594* |     *683 B* |      *-* |   *2,408 B* |
|    *'Serialize: XML=PersonProper'* |  *XML,Serialization* | *26.652 μs* | *1.3082 μs* | *3.8573 μs* | *0.3857 μs* | *19.491 μs* | *23.570 μs* | *27.082 μs* | *29.466 μs* | *36.524 μs* |  *37,520.8* |      *1.3082 μs* |     *100.00* |    *2.439* |  *2.593* |   *0.2132* |    *7* |            *** |       *No* | *2.3193* |     *869 B* | *0.0305* |  *20,782 B* |
|                *StringToXDocument* |  *XML,Serialization* | *16.259 μs* | *0.8314 μs* | *2.4515 μs* | *0.2452 μs* | *11.725 μs* | *14.483 μs* | *16.391 μs* | *17.681 μs* | *21.512 μs* |  *61,503.4* |      *0.8314 μs* |     *100.00* |    *2.320* |  *2.741* |   *0.1307* |    *5* |            *** |       *No* | *1.7090* |     *342 B* |      *-* |  *15,888 B* |
