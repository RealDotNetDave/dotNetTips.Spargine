## DotNetTips.Spargine.Extensions.BenchmarkTests.ImmutableArrayExtensionsBenchmark-20220802-021616
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6918532a-c76a-4805-851d-eed8c2c2d518-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6ca915a2-335e-412b-aec8-9dfe13a13893-diff.temp
index cd6457d..8faa44d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6ca915a2-335e-412b-aec8-9dfe13a13893-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6918532a-c76a-4805-851d-eed8c2c2d518-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c7f31943-e7d9-4b4f-a631-379287deffaf-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/cc06b0ac-5428-498e-9946-50e56e1fc1c8-diff.temp
index cd6457d..8bdc465 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/cc06b0ac-5428-498e-9946-50e56e1fc1c8-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c7f31943-e7d9-4b4f-a631-379287deffaf-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5d60a38c-c38c-4e0c-a635-fd65e9896010-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b630b2a0-f7af-49ea-a81b-734ea95c44cd-diff.temp
index cd6457d..d95b6ca 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b630b2a0-f7af-49ea-a81b-734ea95c44cd-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5d60a38c-c38c-4e0c-a635-fd65e9896010-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/cfe50c5c-665f-4f70-bf45-4ece66d09ac7-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/fba07de0-7ea4-413c-ac0c-a9add57bd4e5-diff.temp
index cd6457d..9d5828d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/fba07de0-7ea4-413c-ac0c-a9add57bd4e5-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/cfe50c5c-665f-4f70-bf45-4ece66d09ac7-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff

```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/316c54e4-f0ce-4ae9-b500-6a505389148f-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3a2bdd2e-6a4d-4ad5-9bf2-6e6feff61980-diff.temp
index cd6457d..ecb53d0 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3a2bdd2e-6a4d-4ad5-9bf2-6e6feff61980-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/316c54e4-f0ce-4ae9-b500-6a505389148f-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c4604be7-f1c2-4c70-aeb9-d8178f8eb930-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/954f0f83-5df5-42e8-9240-63c75079f6c1-diff.temp
index cd6457d..de23c1b 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/954f0f83-5df5-42e8-9240-63c75079f6c1-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c4604be7-f1c2-4c70-aeb9-d8178f8eb930-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c50e16ee-d829-4bc8-b531-aff6d8eb5b72-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7d1165d9-0bc9-4d73-b392-a0d1a3a536d8-diff.temp
index 8faa44d..8bdc465 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7d1165d9-0bc9-4d73-b392-a0d1a3a536d8-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c50e16ee-d829-4bc8-b531-aff6d8eb5b72-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0a030520-03e9-4805-9f45-c784494a2f5c-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/82ee861a-1e4f-41e2-aa9f-cf6368b833c8-diff.temp
index 8faa44d..d95b6ca 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/82ee861a-1e4f-41e2-aa9f-cf6368b833c8-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0a030520-03e9-4805-9f45-c784494a2f5c-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/28464de2-e5dd-436e-a50d-40684bf92061-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/18f8f374-ea36-4425-9318-15f818d3252a-diff.temp
index 8faa44d..9d5828d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/18f8f374-ea36-4425-9318-15f818d3252a-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/28464de2-e5dd-436e-a50d-40684bf92061-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b08756c5-411a-427e-8cce-838cdf0da92e-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/bcade017-56b4-4495-853b-d2a8bf758f92-diff.temp
index 8faa44d..cd6457d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/bcade017-56b4-4495-853b-d2a8bf758f92-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b08756c5-411a-427e-8cce-838cdf0da92e-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4c711a7b-b238-4fc7-b687-a36c3189f944-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/66047827-a5f2-4c43-98c2-ef4390ae77f3-diff.temp
index 8faa44d..ecb53d0 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/66047827-a5f2-4c43-98c2-ef4390ae77f3-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4c711a7b-b238-4fc7-b687-a36c3189f944-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b001c6df-aadc-4dc5-9b3f-42caa2a537d5-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/354c5192-02c3-4543-a6f5-2247371f71fb-diff.temp
index 8faa44d..de23c1b 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/354c5192-02c3-4543-a6f5-2247371f71fb-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b001c6df-aadc-4dc5-9b3f-42caa2a537d5-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/79c67030-30c7-4da7-870f-0895e7333fd0-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/768ab18f-a462-46a5-9b77-1550b2886210-diff.temp
index 8bdc465..d95b6ca 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/768ab18f-a462-46a5-9b77-1550b2886210-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/79c67030-30c7-4da7-870f-0895e7333fd0-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c4419c9a-71ed-423f-af99-3bc739fdd3b0-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/de962f56-397f-415e-a38f-17d0b8144123-diff.temp
index 8bdc465..9d5828d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/de962f56-397f-415e-a38f-17d0b8144123-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c4419c9a-71ed-423f-af99-3bc739fdd3b0-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3de37bab-7d85-4004-bc67-17283a60402f-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6909fa8b-e28e-4cd8-9694-874f37dc589b-diff.temp
index 8bdc465..cd6457d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6909fa8b-e28e-4cd8-9694-874f37dc589b-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3de37bab-7d85-4004-bc67-17283a60402f-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L02:
        jne       short M01_L01
        test      eax,eax
+       call      qword ptr [7FFB478707E0]
+       mov       r11,7FFB472307E0
-       call      qword ptr [rax]
-       mov       rax,7FFB472507E8
-       mov       r11,7FFB472507E8
        mov       rcx,rdi
        jo        short M01_L03
        add       esi,1
 M01_L01:
        je        short M01_L02
        test      eax,eax
+       call      qword ptr [7FFB478707E0]
+       mov       r11,7FFB472307E0
-       call      qword ptr [rax]
-       mov       rax,7FFB472507E8
-       mov       r11,7FFB472507E8
        mov       rcx,rdi
        mov       rdi,rax
+       call      qword ptr [7FFB478707D8]
+       mov       r11,7FFB472307D8
-       call      qword ptr [rax]
-       mov       rax,7FFB472507E0
-       mov       r11,7FFB472507E0
        xor       esi,esi
 M01_L00:
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        xor       eax,eax
        jne       short M01_L00
        test      rcx,rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
 ; Total bytes of code 99
        ret
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       [rax+54],bpl
        mov       rax,[rsi+18]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9ef678b6-1686-47bc-9f21-4d3fa6eda542-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0021b9dd-9ab1-49e9-9cf9-27c4cf4af521-diff.temp
index 8bdc465..ecb53d0 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0021b9dd-9ab1-49e9-9cf9-27c4cf4af521-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9ef678b6-1686-47bc-9f21-4d3fa6eda542-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
M01_L02:
        jne       short M01_L01
        test      eax,eax
+       call      qword ptr [7FFB478B07E0]
+       mov       r11,7FFB472707E0
-       call      qword ptr [rax]
-       mov       rax,7FFB472507E8
-       mov       r11,7FFB472507E8
        mov       rcx,rdi
        jo        short M01_L03
        add       esi,1
 M01_L01:
        je        short M01_L02
        test      eax,eax
+       call      qword ptr [7FFB478B07E0]
+       mov       r11,7FFB472707E0
-       call      qword ptr [rax]
-       mov       rax,7FFB472507E8
-       mov       r11,7FFB472507E8
        mov       rcx,rdi
        mov       rdi,rax
+       call      qword ptr [7FFB478B07D8]
+       mov       r11,7FFB472707D8
-       call      qword ptr [rax]
-       mov       rax,7FFB472507E0
-       mov       r11,7FFB472507E0
        xor       esi,esi
 M01_L00:
        ret
        pop       rdi
        pop       rsi
        add       rsp,28
        xor       eax,eax
        jne       short M01_L00
        test      rcx,rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.EnumerableExtensions.Count(System.Collections.IEnumerable)
 ; Total bytes of code 99
        ret
        pop       rdi
        pop       rsi
        pop       rbp
        pop       rbx
        add       rsp,28
        mov       [rax+54],bpl
        mov       rax,[rsi+18]
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a68ff778-cdc2-4a3f-9504-436ef58d68ff-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/71758f50-1830-4280-adf9-2c42066bda01-diff.temp
index 8bdc465..de23c1b 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/71758f50-1830-4280-adf9-2c42066bda01-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a68ff778-cdc2-4a3f-9504-436ef58d68ff-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/eb9d4d40-44fd-4dd6-84e2-6f5c157c64c1-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7d6875d3-9bc1-4127-b136-394f77d8393d-diff.temp
index d95b6ca..9d5828d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7d6875d3-9bc1-4127-b136-394f77d8393d-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/eb9d4d40-44fd-4dd6-84e2-6f5c157c64c1-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/47011590-78d7-4934-8725-6e8b3e46a729-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5d7324fb-a4b9-4b02-9583-28866f67f770-diff.temp
index d95b6ca..cd6457d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5d7324fb-a4b9-4b02-9583-28866f67f770-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/47011590-78d7-4934-8725-6e8b3e46a729-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6cbeb200-eb12-4baa-89c7-9586e114aa8e-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/58557c77-27b4-481c-8282-d03c07168fb8-diff.temp
index d95b6ca..ecb53d0 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/58557c77-27b4-481c-8282-d03c07168fb8-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6cbeb200-eb12-4baa-89c7-9586e114aa8e-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c62dc3eb-a00e-4881-b3d0-938e7586d9b3-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4fc0fc9d-2257-4c76-ad69-6de6931f2336-diff.temp
index d95b6ca..de23c1b 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4fc0fc9d-2257-4c76-ad69-6de6931f2336-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c62dc3eb-a00e-4881-b3d0-938e7586d9b3-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1afca881-af16-4437-9c51-884ca20cf573-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6908a4a1-5d47-495f-a72b-1d59a7cd06a4-diff.temp
index 9d5828d..cd6457d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6908a4a1-5d47-495f-a72b-1d59a7cd06a4-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1afca881-af16-4437-9c51-884ca20cf573-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e87e3228-c441-41df-a670-b943f5d2b6ba-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a49ce368-4354-4f8a-96d3-28b3db5e47c8-diff.temp
index 9d5828d..ecb53d0 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a49ce368-4354-4f8a-96d3-28b3db5e47c8-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e87e3228-c441-41df-a670-b943f5d2b6ba-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/aed2c27a-056b-46a7-ae36-a8b1fe9b148a-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3884f3d2-24b2-4805-94fb-85285c69fd88-diff.temp
index 9d5828d..de23c1b 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3884f3d2-24b2-4805-94fb-85285c69fd88-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/aed2c27a-056b-46a7-ae36-a8b1fe9b148a-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a468b83a-9632-4970-8ba4-f9ac600ae9ab-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b31a3c90-afea-44da-baaa-c06d6253a180-diff.temp
index cd6457d..ecb53d0 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b31a3c90-afea-44da-baaa-c06d6253a180-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a468b83a-9632-4970-8ba4-f9ac600ae9ab-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/884c11ea-c8b9-42a7-bb94-e217b04de0de-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5c1ad45b-775a-4b01-8be0-212af405c9e7-diff.temp
index cd6457d..de23c1b 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5c1ad45b-775a-4b01-8be0-212af405c9e7-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/884c11ea-c8b9-42a7-bb94-e217b04de0de-diff.temp
```
**Diff for ImmutableArrayHasItemsWithCount method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/538510bf-b201-4017-8ee6-92f6e35ee399-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5bd3dbab-4e9f-406c-81ec-7f31c46e3c9b-diff.temp
index ecb53d0..de23c1b 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5bd3dbab-4e9f-406c-81ec-7f31c46e3c9b-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/538510bf-b201-4017-8ee6-92f6e35ee399-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d15f0090-0748-4d8b-b699-bd52faf6d6a1-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3f2df5ea-d37d-4cec-b49b-8ace578128ce-diff.temp
index 647828c..d88df59 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3f2df5ea-d37d-4cec-b49b-8ace578128ce-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/d15f0090-0748-4d8b-b699-bd52faf6d6a1-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c4e41e81-43ec-4184-9f34-5fa6b7bab611-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/27dca9b9-33a1-4e05-bc2f-664a80cd9de6-diff.temp
index 647828c..ff64db9 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/27dca9b9-33a1-4e05-bc2f-664a80cd9de6-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c4e41e81-43ec-4184-9f34-5fa6b7bab611-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4250de78-51d8-42c2-ba87-5f7f22c4930b-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1532df06-cce1-4510-b672-3435dcea729a-diff.temp
index 647828c..cb7c1fd 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/1532df06-cce1-4510-b672-3435dcea729a-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4250de78-51d8-42c2-ba87-5f7f22c4930b-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c45fb3c6-b2a3-4d27-aa53-01f8152dda17-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/fdb93afb-7825-4e57-964f-1b20c857013a-diff.temp
index 647828c..f2197f2 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/fdb93afb-7825-4e57-964f-1b20c857013a-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c45fb3c6-b2a3-4d27-aa53-01f8152dda17-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4539aad9-9cad-40be-8863-264b2f2c83ae-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/624cb187-7ea0-4f0a-aa64-7601ee15c285-diff.temp
index 647828c..a4a6af3 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/624cb187-7ea0-4f0a-aa64-7601ee15c285-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4539aad9-9cad-40be-8863-264b2f2c83ae-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f3b7b3cd-68e0-4d09-b833-8651b77ec406-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5fd1969a-c1be-40e5-bc80-deafd1b43f25-diff.temp
index 647828c..5c7b4d8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5fd1969a-c1be-40e5-bc80-deafd1b43f25-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f3b7b3cd-68e0-4d09-b833-8651b77ec406-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a196b47e-c458-4a76-baa8-7f4f30281c15-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ea60a046-39f7-4d40-82ec-91021ae26d53-diff.temp
index 647828c..567b53d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/ea60a046-39f7-4d40-82ec-91021ae26d53-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/a196b47e-c458-4a76-baa8-7f4f30281c15-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/8aaf47af-6280-47bd-a9a2-9dad18b471cd-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c62aa3ed-a0bb-4b32-bfc5-f5911a27f0d1-diff.temp
index d88df59..ff64db9 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c62aa3ed-a0bb-4b32-bfc5-f5911a27f0d1-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/8aaf47af-6280-47bd-a9a2-9dad18b471cd-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/49516fbf-c976-4084-8b76-c2d0e5560dc9-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7b2ea206-a68f-4dc3-989c-edacb22c143b-diff.temp
index d88df59..cb7c1fd 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7b2ea206-a68f-4dc3-989c-edacb22c143b-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/49516fbf-c976-4084-8b76-c2d0e5560dc9-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/84a43026-da32-4c0f-a945-2bc2cd01009a-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3a97acf7-4c34-416a-9303-d5a22477ab9c-diff.temp
index d88df59..f2197f2 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3a97acf7-4c34-416a-9303-d5a22477ab9c-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/84a43026-da32-4c0f-a945-2bc2cd01009a-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6ab242b9-7141-466a-85db-a2accf43fddc-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e03f34f8-3623-47c1-bc80-4813bb55ccae-diff.temp
index d88df59..a4a6af3 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e03f34f8-3623-47c1-bc80-4813bb55ccae-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6ab242b9-7141-466a-85db-a2accf43fddc-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
ret
        pop       rdi
        pop       rsi
        add       rsp,28
        xor       eax,eax
        jne       short M01_L00
        cmp       dword ptr [rsi+8],0
        mov       rdx,[rax+10]
        mov       rax,[rcx+10]
        mov       rsi,rdx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ImmutableArrayExtensions.HasItems[[System.__Canon, System.Private.CoreLib]](System.Collections.Immutable.ImmutableArray`1<System.__Canon>)
 ; Total bytes of code 43
-; 			^^^^^^^^^^^^^^^^^^^^^^^^^
-; 			Consumer.Consume(result);
-; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-; 			var result = this._people.HasItems();
        ret
        pop       rsi
        add       rsp,20
        mov       [rdx+54],al
        mov       rdx,[rsi+18]
        call      DotNetTips.Spargine.Extensions.ImmutableArrayExtensions.HasItems[[System.__Canon, System.Private.CoreLib]](System.Collections.Immutable.ImmutableArray`1<System.__Canon>)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ImmutableArrayExtensions.HasItems(System.Collections.Immutable.ImmutableArray`1<!!0>)
        mov       rdx,[rsi+2B0]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
+; 			^^^^^^^^^^^^^^^^^^^^^^^^^
+; 			Consumer.Consume(result);
+; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
+; 			var result = this._people.HasItems();
 ; DotNetTips.Spargine.Extensions.BenchmarkTests.ImmutableArrayExtensionsBenchmark.ImmutableArrayHasItems()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/168c05b7-2c5b-4de2-affe-314ee8455ac6-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/8f95f3ae-c7fa-4a0b-8cb2-a7ec8cb3db9c-diff.temp
index d88df59..5c7b4d8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/8f95f3ae-c7fa-4a0b-8cb2-a7ec8cb3db9c-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/168c05b7-2c5b-4de2-affe-314ee8455ac6-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
ret
        pop       rdi
        pop       rsi
        add       rsp,28
        xor       eax,eax
        jne       short M01_L00
        cmp       dword ptr [rsi+8],0
        mov       rdx,[rax+10]
        mov       rax,[rcx+10]
        mov       rsi,rdx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ImmutableArrayExtensions.HasItems[[System.__Canon, System.Private.CoreLib]](System.Collections.Immutable.ImmutableArray`1<System.__Canon>)
 ; Total bytes of code 43
-; 			^^^^^^^^^^^^^^^^^^^^^^^^^
-; 			Consumer.Consume(result);
-; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-; 			var result = this._people.HasItems();
        ret
        pop       rsi
        add       rsp,20
        mov       [rdx+54],al
        mov       rdx,[rsi+18]
        call      DotNetTips.Spargine.Extensions.ImmutableArrayExtensions.HasItems[[System.__Canon, System.Private.CoreLib]](System.Collections.Immutable.ImmutableArray`1<System.__Canon>)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ImmutableArrayExtensions.HasItems(System.Collections.Immutable.ImmutableArray`1<!!0>)
        mov       rdx,[rsi+2B0]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
+; 			^^^^^^^^^^^^^^^^^^^^^^^^^
+; 			Consumer.Consume(result);
+; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
+; 			var result = this._people.HasItems();
 ; DotNetTips.Spargine.Extensions.BenchmarkTests.ImmutableArrayExtensionsBenchmark.ImmutableArrayHasItems()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f20e0bb8-7b11-47cd-9413-a5cef8ddd2d0-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/803eed0e-234d-4356-9855-70828f9e6a60-diff.temp
index d88df59..567b53d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/803eed0e-234d-4356-9855-70828f9e6a60-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/f20e0bb8-7b11-47cd-9413-a5cef8ddd2d0-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7a54235b-baa1-4bd2-b149-967a8e20bd1a-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6c87bfcc-de8e-4144-b23e-decf97238c47-diff.temp
index ff64db9..cb7c1fd 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6c87bfcc-de8e-4144-b23e-decf97238c47-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/7a54235b-baa1-4bd2-b149-967a8e20bd1a-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/761d8341-8480-422c-a05b-bba8f39e5fa6-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/dfc19655-1dee-41fd-9b6e-e5d6e52967de-diff.temp
index ff64db9..f2197f2 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/dfc19655-1dee-41fd-9b6e-e5d6e52967de-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/761d8341-8480-422c-a05b-bba8f39e5fa6-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2b79ab59-1092-414b-85b5-a93d0bf9124d-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c5ecabee-53e0-430b-9b45-2906e6742ba5-diff.temp
index ff64db9..a4a6af3 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c5ecabee-53e0-430b-9b45-2906e6742ba5-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2b79ab59-1092-414b-85b5-a93d0bf9124d-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0e41d30c-e03e-4ea2-8baa-9d93d988a610-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/52bfd91e-f4de-4c13-af2a-301d78574683-diff.temp
index ff64db9..5c7b4d8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/52bfd91e-f4de-4c13-af2a-301d78574683-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/0e41d30c-e03e-4ea2-8baa-9d93d988a610-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3eb1f3fc-0d08-44d6-929c-6f72470d78ca-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/04a07a64-4b42-40e4-b210-58af74a10a9d-diff.temp
index ff64db9..567b53d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/04a07a64-4b42-40e4-b210-58af74a10a9d-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/3eb1f3fc-0d08-44d6-929c-6f72470d78ca-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/714a393c-1ca3-498a-b6d7-0af2715e94df-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b7eb2958-41af-4dae-8b26-c2084534c033-diff.temp
index cb7c1fd..f2197f2 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/b7eb2958-41af-4dae-8b26-c2084534c033-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/714a393c-1ca3-498a-b6d7-0af2715e94df-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c84c44fd-1aa9-48a8-ab6a-0296a2bd8d10-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2ebcc183-f92c-42b4-9637-8eaac80e7bcc-diff.temp
index cb7c1fd..a4a6af3 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2ebcc183-f92c-42b4-9637-8eaac80e7bcc-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c84c44fd-1aa9-48a8-ab6a-0296a2bd8d10-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/917a7c29-be65-403a-9193-2ea83b2c4d45-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e670dfac-fff6-4e62-8759-4fc974a53c6e-diff.temp
index cb7c1fd..5c7b4d8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/e670dfac-fff6-4e62-8759-4fc974a53c6e-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/917a7c29-be65-403a-9193-2ea83b2c4d45-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9025f8a3-bc56-49f8-996b-ea1952dca59a-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6ec1480e-4305-4bcb-91a1-5142f2792761-diff.temp
index cb7c1fd..567b53d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/6ec1480e-4305-4bcb-91a1-5142f2792761-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9025f8a3-bc56-49f8-996b-ea1952dca59a-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2b5197a3-3297-4f4e-be47-cc0c9f36c3a4-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4a4f1616-5007-4725-a15e-f38317ff521a-diff.temp
index f2197f2..a4a6af3 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/4a4f1616-5007-4725-a15e-f38317ff521a-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/2b5197a3-3297-4f4e-be47-cc0c9f36c3a4-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
ret
        pop       rdi
        pop       rsi
        add       rsp,28
        xor       eax,eax
        jne       short M01_L00
        cmp       dword ptr [rsi+8],0
        mov       rdx,[rax+10]
        mov       rax,[rcx+10]
        mov       rsi,rdx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ImmutableArrayExtensions.HasItems[[System.__Canon, System.Private.CoreLib]](System.Collections.Immutable.ImmutableArray`1<System.__Canon>)
 ; Total bytes of code 43
-; 			^^^^^^^^^^^^^^^^^^^^^^^^^
-; 			Consumer.Consume(result);
-; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-; 			var result = this._people.HasItems();
        ret
        pop       rsi
        add       rsp,20
        mov       [rdx+54],al
        mov       rdx,[rsi+18]
        call      DotNetTips.Spargine.Extensions.ImmutableArrayExtensions.HasItems[[System.__Canon, System.Private.CoreLib]](System.Collections.Immutable.ImmutableArray`1<System.__Canon>)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ImmutableArrayExtensions.HasItems(System.Collections.Immutable.ImmutableArray`1<!!0>)
        mov       rdx,[rsi+2B0]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
+; 			^^^^^^^^^^^^^^^^^^^^^^^^^
+; 			Consumer.Consume(result);
+; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
+; 			var result = this._people.HasItems();
 ; DotNetTips.Spargine.Extensions.BenchmarkTests.ImmutableArrayExtensionsBenchmark.ImmutableArrayHasItems()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/82518953-276d-411a-9471-4b13c4365527-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5d325f1a-273a-43f1-ada8-e07f7512abef-diff.temp
index f2197f2..5c7b4d8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/5d325f1a-273a-43f1-ada8-e07f7512abef-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/82518953-276d-411a-9471-4b13c4365527-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
ret
        pop       rdi
        pop       rsi
        add       rsp,28
        xor       eax,eax
        jne       short M01_L00
        cmp       dword ptr [rsi+8],0
        mov       rdx,[rax+10]
        mov       rax,[rcx+10]
        mov       rsi,rdx
        mov       [rsp+20],rcx
        sub       rsp,28
        push      rsi
        push      rdi
 ; DotNetTips.Spargine.Extensions.ImmutableArrayExtensions.HasItems[[System.__Canon, System.Private.CoreLib]](System.Collections.Immutable.ImmutableArray`1<System.__Canon>)
 ; Total bytes of code 43
-; 			^^^^^^^^^^^^^^^^^^^^^^^^^
-; 			Consumer.Consume(result);
-; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-; 			var result = this._people.HasItems();
        ret
        pop       rsi
        add       rsp,20
        mov       [rdx+54],al
        mov       rdx,[rsi+18]
        call      DotNetTips.Spargine.Extensions.ImmutableArrayExtensions.HasItems[[System.__Canon, System.Private.CoreLib]](System.Collections.Immutable.ImmutableArray`1<System.__Canon>)
        mov       rcx,offset MD_DotNetTips.Spargine.Extensions.ImmutableArrayExtensions.HasItems(System.Collections.Immutable.ImmutableArray`1<!!0>)
        mov       rdx,[rsi+2B0]
        mov       rsi,rcx
        sub       rsp,20
        push      rsi
+; 			^^^^^^^^^^^^^^^^^^^^^^^^^
+; 			Consumer.Consume(result);
+; 			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
+; 			var result = this._people.HasItems();
 ; DotNetTips.Spargine.Extensions.BenchmarkTests.ImmutableArrayExtensionsBenchmark.ImmutableArrayHasItems()
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c1350402-6a5e-40a2-a4b6-90b21af63210-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/dba41133-490b-4370-8e6f-efe3f9f90fc9-diff.temp
index f2197f2..567b53d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/dba41133-490b-4370-8e6f-efe3f9f90fc9-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/c1350402-6a5e-40a2-a4b6-90b21af63210-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/39904bda-0628-41fb-877a-55cf1bc8b2ad-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9396cec2-b28c-4f22-8f30-b7756e336be3-diff.temp
index a4a6af3..5c7b4d8 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/9396cec2-b28c-4f22-8f30-b7756e336be3-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/39904bda-0628-41fb-877a-55cf1bc8b2ad-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/245b1bdb-bf5e-4d58-b1e5-6b23e1ae4645-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/acec33d6-4fde-4331-96e8-c1948eeae4e7-diff.temp
index a4a6af3..567b53d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/acec33d6-4fde-4331-96e8-c1948eeae4e7-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/245b1bdb-bf5e-4d58-b1e5-6b23e1ae4645-diff.temp
```
**Diff for ImmutableArrayHasItems method between:**
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
.NET 6.0.7 (6.0.722.32202), X64 RyuJIT
```diff
+++ b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/85d0ef60-097a-4b8d-89fe-8a4f08406ba7-diff.temp
--- a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/00d46a73-6635-42fc-bb40-bb93240de124-diff.temp
index 5c7b4d8..567b53d 100644
diff --git a/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/00d46a73-6635-42fc-bb40-bb93240de124-diff.temp b/C:/src/GitHub/dotNetTips.Spargine/source/6/appbin/net6.0/BenchmarkDotNet.Artifacts/results/85d0ef60-097a-4b8d-89fe-8a4f08406ba7-diff.temp
```
